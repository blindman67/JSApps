"use strict";
const spriteList = (()=>{
    const INDENT = 8;
    var groupId = 0;
   // var listPannel;
    const id = UID ++;
    var debounceUpdateHandle;
    var lastUpdateFrame = 0;
    var keepOpenButton = localStorage[APPNAME + "_lastLoadedSprites"] !== undefined;
    var selectedCallback, editingNameListItem, editingName, listElement, tabElement, flasher, index = 0;
    const foldTypes = {
        group : 1,
        collection: 2,
        topLevel: 3,
    };
    const updateFlags = {
        hasSelected: false,
        canOpen: false,
        canUncollect: false,
        clear() { 
            updateFlags.canOpen = false;
            updateFlags.hasSelected = false;
            updateFlags.canUncollect = false;
        },
    };    
    function mouseInOut(event) {
        var highlight;
        var target = event.target.item;
        if (target && target.item) {
            highlight = event.type === "mouseover";
            if (target.item.isGroup) {
                if (target.item.sprite) {
                    if(target.item.sprite.isCollection){
                        if (sprites.selectingSprite) { target.item.sprite.each(spr=>spr.highlightSelecting = highlight) }
                        else { target.item.sprite.each(spr=>spr.highlight = highlight) }
                    }else{
                        if (sprites.selectingSprite) { target.item.sprite.highlightSelecting = highlight }
                        else { target.item.sprite.highlight = highlight }
                    }
                }
            } else {
                if (sprites.selectingSprite) { target.item.highlightSelecting = highlight }
                else { target.item.highlight = highlight }
            }
        }
    }    
    const buttonMap = new Map();
    var topGroup;
    const allItems = Object.assign(new Map(), {
        clearSelect() {
            for(const listItem of this.values()) {
                listItem.select !== undefined && (listItem.select = false);
            }
        },
        
        
        
    });

    const items = [];
    const collections = Object.assign([],{
        clearSelected(){
            for(const col of this) { col.unselect() }
        },
        hasId(id) {
            for(const col of this) { 
                if(col.ids.has(id)) { return col }
            }
        },
        eachWithId(cb, id) {
            for(const col of this) { 
                if(col.ids.has(id)) { cb(col) }
            }
        },
        removeById(item){
            this.eachWithId(col => {
                col.remove(item);
            }, item.guid);
        },
        remove(col) {
             for(var i = 0; i < this.length; i++) {
                if (this[i] === col) { 
                    topGroup.remove(this[i]);
                    this.splice(i--,1) 
                }
             }                
        },
            
    });
    function Collection() {
        this.items = [];
        this.ids = new Set();
        this.name = "Collection";
        this.selected = false;
        this.isCollection = true;
        this.guid = getUID();
        this.type = {open: false};
        this.fold = undefined
        
        collections.push(this);
    }
    Collection.prototype = {
        toString() { return this.name },
        fromSelected() {
            const sel = selection.asArray();
            const cols = [];
            var topParent;
            var topCol;
            sel.forEach(spr => {

                collections.eachWithId(col => {
                    if(allItems.has(col.guid)) {
                        const p = allItems.get(col.guid).item;
                        log("parent " + p.toString());
                        if(topParent === undefined) {
                            topParent = p;
                            topCol = p.sprite;
                            log("as top")
                        } else {
                            if(!p.isChildOf(topParent)){
                                topParent = p;
                                topCol = p.sprite;
                                log("as top")
                            }
                        }
                    }                    
                    if(!cols.includes(col)){
                        if(col.items.every(spr => spr.selected)) {
                            cols.push(col);
                        }
                    }
                }, spr.guid);
            });
            cols.forEach(col => {
                col.each(spr => {
                    if(sel.includes(spr)) {
                        sel.splice(sel.findIndex(s => s.guid === spr.guid), 1);
                    }
                })
            });   

            //[...cols].forEach(col => topCol !== col && collections.remove(col));
            //if(topCol) { sel.forEach(spr=> {topCol.remove(spr) }) }
            [...cols, ...sel].forEach(spr => {
                if(!this.ids.has(spr.guid)) { 
                    this.items.push(spr);
                    this.ids.add(spr.guid);
                    
                }
            });
            this.childOf = topParent ? topParent : topGroup;
        },
        hasSelected() {
            return this.items.some(spr => spr.selected);
        },
        select() {
            this.selected = true;
            this.each(spr => selection.add(spr));
        },
        unselect() {
            this.selected = false;
            this.each(spr => selection.remove(spr));
        },
        each(cb){
            for(const item of this.items) { cb(item) }
        },
        remove(item){
            this.ids.delete(item.guid);
            const idx = this.items.indexOf(item);
            if(idx !== undefined) {
                this.items.splice(idx,1);
            }
        }
        
    };
    
    

    function createGroup(parent, name, type, sprite){
        var indent;
        var open = false;
        var guid;
        if (parent === undefined) { 
            indent = 0;
            open = true;
            guid = getUID();
        } else if(sprite.isCollection) {
            indent = parent.indent + INDENT;
            guid = sprite.guid;
        } else if(sprite) {
            open = sprite.type.groupOpen;
            indent = parent.indent + INDENT;
            guid = getUID();
        } else {
            indent = parent.indent + INDENT;
            guid = getUID();
            
        }
        const group = {
            type,
            parent,
            indent,
            isGroup : true,
            isChildOf(group) {
                var p = this;
                while(!p.isTop && p.guid !== group.guid){
                    p = this.parent;                    
                }
                return p.guid === group.guid;
            },
            get isOpen() { return open },
            open() { 
                this.allListItems(listItem => { 
                    if((listItem.parent && listItem.parent.isOpen) || (listItem.item.parent && listItem.item.parent.isOpen) ){
                        listItem.element.classList.remove("hideItem");
                    } else {
                        listItem.element.classList.add("hideItem");
                    }
                });
                
            },
            close() { this.allListItems(listItem => { listItem.element.classList.add("hideItem") }) },
            toggleOpen() { 
                if (!open) {
                    open = true;
                    this.open();
                } else {
                    open = false;
                    this.close();
                }
                this.element.textContent = this.toString();
            },
            get name() { return name },
            set name(str) { name = str },
            guid,
            items : [],
            order() {
                const oldList = [];
                this.items.forEach(item => oldList.push(item.item.isGroup ? item.item.sprite : item.item));
                this.clear();
                oldList.sort((a, b)=> a.index - b.index);
                oldList.forEach(item => this.add(item));
            },            
            clear() {
                if (this.items.length) { flasher("newItem") }
                this.items.forEach(listItem => {
                    this.list.remove(listItem.item.isGroup ? listItem.item.list : listItem.element);
                    if(listItem.item.isCollection) {
                        listItem.item.fold = null;
                    }
                    allItems.delete(listItem.guid);
                });
                this.items.length = 0;
            },          
            add(addItem) {
                var item;
                if((addItem.type && !addItem.type.shadow) || !addItem.type) {
                    if(this.isTop && addItem.guid) {
                        const inCollection = collections.hasId(addItem.guid);
                        if (inCollection) {
                            collections.eachWithId(col => col.add(addItem), addItem.guid);
                            return;
                        }
                    }
                    if(addItem.isCollection) {
                        if(addItem.items.length) {
                            const col = createGroup(this, addItem.name, foldTypes.collection,addItem);
                            addItem.fold = col;
                            addItem.each(spr => col.add(spr)); 
                            if(addItem.childOf && addItem.childOf.guid === this.guid){
                                addItem.each(spr => this.removeOutOfCollection(spr)); 
                            }                                
                        } else {
                            //collections.remove(addItem);
                        }
                        
                    } else if(addItem.type.group) {
                        const grp = createGroup(this, addItem.name, foldTypes.group,addItem);
                        addItem.group.each(spr => grp.add(spr));
                    }else{
                        this.items.push(item = { item : addItem, select: false, guid: getUID(), parent: this, element : this.list.addItem(commands.spritesItem, addItem.toString()),});
                        allItems.set(item.guid, item);
                        item.element.style.textIndent = this.indent+"px";
                        item.element.title = null;
                        item.element.item = item;
                        if (open) {item.element.classList.remove("hideItem") }
                        else { item.element.classList.add("hideItem") }
                            
                    }
                    flasher("newItem");
                }
                return item;            
            },
            removeOutOfCollection( item) {
               // if(this.isTop) {
                    for(var i = 0; i < this.items.length; i++){
                        const listItem = this.items[i];
                        if (listItem.item.isGroup) {
                           /* if(listItem.item.sprite.isCollection && listItem.item.guid === item.guid){
                                this.list.remove(listItem.item.element);
                                allItems.delete(listItem.item.guid);
                                this.items.splice(i--,1)                                  
                            }*/
                        } else if(listItem.item.guid === item.guid){
                            this.list.remove(listItem.element);
                            allItems.delete(listItem.guid);
                            this.items.splice(i--,1)                             
                        }
                    }
               // }
            },
            remove(removeItem){
                for(var i = 0; i < this.items.length; i++){
                    const listItem = this.items[i];
                    if (listItem.item.isGroup) {
                        if (listItem.item.sprite && listItem.item.sprite.guid === removeItem.guid) {
                            this.list.remove(listItem.item.list);
                            allItems.delete(listItem.guid);
                            this.items.splice(i--,1);
                        } else {
                            listItem.item.remove(removeItem);
                            if (listItem.item.items.length === 0) {
                                listItem.item.parent.remove(listItem.item.sprite);
                                //this.items.splice(i--,1);
                                
                            }
                        }
                    } else if(listItem.item.guid === removeItem.guid) { 
                        this.list.remove(listItem.element);
                        this.items.splice(i--,1) 
                        allItems.delete(listItem.guid);
                        collections.removeById(removeItem);
                    }
                }
            },
            
            get index() {
                var max = -1;
                for(const item of this.items){
                    var ind = item.item.index;
                    if(ind > max){  max = ind }
                }
                return ind;
            },
            eachItem(cb) {
                for (const listItem of this.items) {
                    if (listItem.isGroup) { listItem.eachItem(cb) }
                    else { cb(listItem.item) }
                }
            },            
            allListItems(cb) {
                for (const listItem of this.items) {
                    cb(listItem);
                    if(listItem.item.isGroup) {
                        listItem.item.allListItems(cb);
                    }
                }
            },            
            each(cb, i = 0) {
                var index = i;
                for(const listItem of this.items){ 
                    if(listItem.item.isGroup) {
                        if(listItem.item.guid !== this.guid) {
                            if( cb(listItem, index++) === true ) { return --index } 
                            listItem.item.each(cb);
                        }
                    }else if( cb(listItem, index++) === true ) { return --index } 
                }            
            },
            get selected() { return this.items.some(item => item.item.selected === true) },
            toString() { return ((open ? textIcons.triangleDown : textIcons.triangleRight) + " " + (this.sprite ? this.sprite.toString() : name) + " " + (this.sprite && this.sprite.isCollection ? this.sprite.items.length : this.items.length) + " items") },
            commandId: commands.spritesItem,
        };
        group.element = parent === undefined ? listElement.addFoldItem(group) : parent.list.addFoldItem(group);
        group.item = group;
        group.element.item = group;
        group.element.textContent = group.toString();
        if(sprite) { group.sprite = sprite }
        if(parent) { 
            const item = {item:group,select:false, element: group.element};
            parent.items.push(item);
            allItems.set(group.guid, item);
            
            group.element.style.textIndent = parent.indent+"px";
            
            if (parent.isOpen) { group.element.classList.remove("hideItem") }
            else { group.element.classList.add("hideItem") }
        }
        return group;
    }
    
    function updateItem(listItem, index = listItem.element.listPosition) {
        var item = listItem.item;
        const element = listItem.element;
        const parent = listItem.parent ? listItem.parent : listItem.item.parent;
        const sprPar = parent.sprite;
        var text;
       if(item.isGroup) {
           
            text = item.toString();
            if(!item.sprite) { return }
            item = item.sprite;
            if (item.isCollection) {
                item.selected = item.hasSelected();

                if(item.selected) {
                    updateFlags.canUncollect = true;
                    updateFlags.hasSelected = true;
                }

            } else {        
                if(item.shadowedBy && (sprPar && sprPar.type.openGroup)) {
                    item = item.shadowedBy;
                }            
                if(item.selected && item.type.group && !item.type.openGroup) {
                    updateFlags.canOpen = true;
                }
                if(item.type.openGroup) {
                    element.classList.add("foldItemSpriteGroupOpen");
                }else{
                    element.classList.remove("foldItemSpriteGroupOpen");
                }
                if(sprPar && sprPar.type.openGroup) {
                    element.classList.add("foldSpriteInGroupOpen");                
                }else {
                    element.classList.remove("foldSpriteInGroupOpen");                
                }
            }
        } else {
            if(item.shadowedBy  && (sprPar && sprPar.type.openGroup)) {
                item = item.shadowedBy;
            }            
            text = item.toString();


            if (sprPar && sprPar.type.openGroup && item.shadow) {
                element.classList.add("itemSpriteInGroupOpen");
            }else{
                element.classList.remove("itemSpriteInGroupOpen");
            }            
        }

        
        element.listPosition = index;
        var icons = " " + (item.locks && item.locks.UI ? textIcons.locked : "");
    
        element.textContent = text + icons;        
        if(item.helpString){ element.title = item.helpString() }
        else { element.title = "" }
        if (item.selected) { 
        //if (listItem.select) { 
            updateFlags.hasSelected = true;
            element.classList.add("itemSelected") 
        } else { element.classList.remove("itemSelected") }
        if(item.attachedTo && item.attachedTo.selected) { element.classList.add("itemAttachedSelected") }
        else{ element.classList.remove("itemAttachedSelected") }
        
        var lSelected = false;
        if(item.locates) {
            for(const l of item.locates) { if(l.selected) { lSelected = true; break }}
        }
        if(lSelected) { element.classList.add("itemLocatesSelected") }
        else{ element.classList.remove("itemLocatesSelected") }
        if(item.type && item.type.flagged) { element.classList.add("itemFlagged") }
        else{ element.classList.remove("itemFlagged") }        

        //if(listItem.isGroup){ listItem.update() }
    }
    const API = {
        updateItemNameComplete(status) { 
            const sprite = editingNameListItem.isGroup ? editingNameListItem.sprite : editingNameListItem.item;
            if(status === "rejected") {
                sprite.name = editingName;
                updateItem(editingNameListItem, editingNameListItem.element.listPosition);  
            }else if(editingNameListItem.item.name.trim() === ""){
                sprite.name = editingName;
                updateItem(editingNameListItem, editingNameListItem.element.listPosition);  
                setTimeout(()=>log.warn("Blank name rejected."), 100);
            }
            if(sprite.type && sprite.type.functionLink) {
                sprite.name = textIcons.strToMath(sprite.name.trim());
            }else{
                sprite.name = sprite.name.trim(); 
            }
            updateItem(editingNameListItem, editingNameListItem.element.listPosition);              
            editingNameListItem.element.classList.remove("itemEditingText");
            editingNameListItem = undefined;
        },
        updateItemName() {
            const sprite = editingNameListItem.isGroup ? editingNameListItem.sprite : editingNameListItem.item;
            sprite.name = commandLine();
            updateItem(editingNameListItem, editingNameListItem.element.listPosition);  
            editingNameListItem.element.classList.add("itemEditingText");
        },
        each(cb, i = 0){ topGroup.each(cb, i) },
        findItems(cb, list, ifOpen = false) {
            for(const item of items){ 
                if(item.isGroup) {
                    
                } else if(list.includes(item.item)) {
                    if(cb(item) === true) { break }
                }
            }
        },            
        eachOpen(cb){
            var idx = 0;
            for(const item of items){ 
                if(item.isGroup) {
                    cb(item, idx++);
                     if(item.isOpen) {
                        item.eachOpen(cb, idx);
                    }                   
                }else { cb(item, idx++) } 
            }
        },
        add(addItem) { return topGroup.add(addItem) },
        remove(removeItem) { return topGroup.remove(removeItem) },
        order(){ topGroup.order() },
        clear(){ topGroup.clear() },
        getButton(commandId) { return buttonMap.get(commandId) },        
        ready(pannel) {
            tabElement = pannel.titleElement;
            flasher = elementFlasher(tabElement, {newItem : "tabFlashNew"});
            listElement = buttonMap.get(commands.sprites).element;
            topGroup = createGroup(undefined, "Top group", foldTypes.topLevel);
            topGroup.element.style.height = "0px";
            topGroup.element.textContent = null;
            topGroup.indent = 0;
            topGroup.isTop = true;
            ["mouseover","mouseout"].forEach(name => buttonMap.get(commands.sprites).element.addEventListener(name,mouseInOut,{passive:true}))   
            setTimeout(API.update,100);
        },
        selectionCallback(cb) { selectedCallback = cb },
        command(commandId,button,event) {
            const rightClicked = (mouse.oldButton & 4) === 4;
            var updateList = false;
            var updateMenu = false;
            
            if(commandId === commands.spritesSaveAll) {
                 if (sprites.length > 0) {
                    if (sprites.hasDirtyImage()) {
                        log.warn("Sprites use 1 or more unsaved images.");
                    } else {
                        animation.time = animation.startTime;                        
                        if (mouse.ctrl) {
                            storage.saveJSON( sprites.serialize(), "p3SpritesLoc", "sprites");
                            log.info("Sprites saving in local storage.");
                        } else {
                            const name = storage.saveJSON( sprites.serialize(), sprites.sceneName, "sprites");
                            log.info("Downloading scene as '" + name + "'");
                        }
                        keepOpenButton = true;
                    }
                } else {
                    log.info("No sprites selected");
                }               
            
            }else  if(commandId === commands.spritesGroup){
                issueCommand(commands.edSprGroupSelected);
                updateList = true;
            }else  if(commandId === commands.spritesUngroup){
                issueCommand(commands.edSprUngroupSelected);
                updateList = true;
            }else  if(commandId === commands.spritesCollect){
                const col = new Collection();
                const addTo = col.fromSelected();
                
                if(col.childOf && !col.childOf.isTop) {
                    log("parent " + col.childOf.toString());
                    col.childOf.parent.add(col);
                }else{
                    API.add(col);
                }
                updateList = true;
            }else  if(commandId === commands.spritesUncollect){
                //const 
                //selection.each(spr => {
                //    const col = collections.hasId(spr.guid);
                    
                for(let i = 0; i < collections.length; i++) {
                    if(collections[i].selected) {
                        collections.remove(collections[i]);
                    }                    
                }
                updateList = true;
            }else  if(commandId === commands.spritesRecall){
                log.info("Currently not working")
                /*
                sprites.recall();
                */
                //spriteList.update();
                //editSprites.update();

            }else  if(commandId === commands.spritesRemember){
                log.info("Currently not working")
                /*
                const name = "spriteMem" + getGUID();
                sprites.remember(name);
                spriteList.update();*/
            }else  if(commandId === commands.spritesSaveSelected){
                if (rightClicked) {
                    if(mouse.ctrl) {
                        if (localStorage.p3SpritesLoc) {
                            storage.loadJSON("p3SpritesLoc");
                            log.info("Loaded local storage");
                        } else {
                            log.info("No sprites found in local storage");
                        }
                    } else {
                        if (localStorage[APPNAME + "_lastLoadedSprites"] !== undefined) {                        
                            storage.loadJSON(localStorage[APPNAME + "_lastLoadedSprites"]);
                        } else {
                            log.info("There is no last sprite file name saved.");
                        }
                    }
                    
                } else {
                    if (selection.length > 0) {
                        if (selection.hasDirtyImage()) {
                            log.warn("Selected sprites contain 1 or more unsaved images.");
                        } else {
                            animation.time = animation.startTime;                        
                            if (mouse.ctrl) {
                                storage.saveJSON( selection.serialize(), "p3SpritesLoc", "sprites");
                                log.info("Selected sprites saving in local storage.");
                                
                            } else {
                                if(selection.length === sprites.length) {
                                    const name = storage.saveJSON( selection.serialize(), sprites.sceneName, "sprites");
                                    log.info("Downloading scene as '" + name + "'");
                                } else {
                                    const name = storage.saveJSON( selection.serialize(), "p3Sprites", "sprites");
                                    log.info("Downloading selected sprites as '" + name + "'");
                                }
                            }
                            keepOpenButton = true;
                        }
                    } else {
                        log.info("No sprites selected");
                    }
                }
            }else  if(commandId === commands.spritesItem){
                let listItem = event.target.item, item = listItem;
                const parent = listItem.parent;
                if(listItem.isGroup) {
                    if(event.offsetX < listItem.indent + 16) {
                        if(!listItem.isTop) {
                            listItem.toggleOpen();
                        }
                        return;
                    }
                    item = listItem.sprite;

                }else {
                    item = listItem.item;
                }
                item = item.shadowedBy ? item.shadowedBy : item;
                if(mouse.shift && (mouse.oldButton & 1) === 1 && item.isGroup) {

                    item.toggleOpen();

                } else if(mouse.ctrl && (mouse.oldButton & 1) === 1) {
                    editingNameListItem = event.target.item;
                    editingName = item.name;
                    commandLine(API.updateItemName, API.updateItemNameComplete);
                    commandLine(item.name, false, true);         
                    log.command("Click for text modifer help","text ?" );
                }else{
                    if(sprites.selectingSprite) { //selectedCallback){
                        selection.silent = true;
                        selection.clear()
                        if(item.isGroup){ item.each(listItem => selection.add(listItem)) }
                        else { selection.add(item) }
                        selection.silent = false;
                        widget.specialSelectionSelect(false);
                        return;
                    }
                    if ((mouse.oldButton & 4) === 4){
                        if(item.isCollection) {
                            if(listItem.select) {
                                item.unselect();
                            }else {
                                item.select();
                            }
                        } else if(parent.isTop || parent.sprite.type.openGroup || parent.sprite.isCollection){
                            if (listItem.select) {
                                selection.remove(item);
                                listItem.select = false;
                                
                            } else {
                                selection.add(item);
                                listItem.select = true;
                            }
                            updateList = true;
                        }
                    } else {
                        
                        if (!listItem.select) {
                            selection.clear(true);
                            allItems.clearSelect();
                            collections.clearSelected();
                            if(item.type.flagged) {
                                if(item.flag) {
                                    log.info("Sprite flagged "+textIcons.flag+ " with message...");
                                    log.info(item.flag);
                                }
                                item.type.flagged = false;
                                item.flag = "";
                            }
                            if(item.isCollection) {
                                item.select();
                                listItem.select = true;
                            } else if(parent.isTop || parent.sprite.type.openGroup || parent.sprite.isCollection){
                                selection.add(item);
                                updateList = true;
                                listItem.select = true;
                            }
                        } else {
                            if(item.isCollection) {
                                item.unselect();
                                listItem.select = false;
                            }  else {                            
                                selection.remove(item);
                                listItem.select = false;
                            }
                            
                        }
                        updateList = true;
                    }
                }
                //spriteList.update();
                //editSprites.update();

            }else  if(commandId === commands.spritesToDrawable){
                selection.each(spr => {
                   if(spr.type.image){
                       if(!spr.image.isDrawable){
                           var mItem = mediaList.getMediaItem(spr.image);
                           var newM = media.toDrawable(spr.image);
                           sprites.each(s => {
                               if (s.type.image && s.image === mItem.media) { s.image = newM }
                           });
                           mItem.media = newM;
                           mItem.element.textContent = mItem.media.desc.toString();
                           //API.update();
                       }
                   }
                });
                updateMenu = true;
            }else  if(commandId === commands.spritesSelectAll){
                selection.add(sprites.map(spr=>spr));
            }else  if(commandId === commands.spritesSelectInvert){
                const inv = sprites.filter(spr => !spr.selected);
                selection.clear();
                selection.add(inv);
            }
            
            
            if(updateMenu){
                editSprites.update();
            }else if(updateList) {
                API.update();
            }
        },
        
        updateInfo(){
            clearTimeout(debounceUpdateHandle);
            debounceUpdateHandle = setTimeout(()=>API.update(),50);
        },                    
        update() {
            if(lastUpdateFrame === frameCount) {
                API.updateInfo();
                return;
            }
            lastUpdateFrame = frameCount;
            clearTimeout(debounceUpdateHandle);
            updateFlags.clear();
            API.each(updateItem);
            if(updateFlags.hasSelected) {
                buttonMap.get(commands.spritesToDrawable).enable();
                buttonMap.get(commands.spritesToDrawOn).enable();
                buttonMap.get(commands.spritesGroup).enable();
                buttonMap.get(commands.spritesCollect).enable();
                if(updateFlags.canUncollect) { 
                    buttonMap.get(commands.spritesUncollect).enable();
                } else {
                    buttonMap.get(commands.spritesUncollect).disable();
                }                    
                if(updateFlags.canOpen) {
                    buttonMap.get(commands.spritesUngroup).enable();
                } else {
                    buttonMap.get(commands.spritesUngroup).disable();
                }
                buttonMap.get(commands.spritesSaveSelected).enable();
            } else {
                buttonMap.get(commands.spritesCollect).disable();
                buttonMap.get(commands.spritesUncollect).disable();
                buttonMap.get(commands.spritesToDrawable).disable();
                buttonMap.get(commands.spritesToDrawOn).disable();
                buttonMap.get(commands.spritesGroup).disable();
                buttonMap.get(commands.spritesUngroup).disable();
                if(keepOpenButton) {
                    buttonMap.get(commands.spritesSaveSelected).enable();                
                }else{
                    buttonMap.get(commands.spritesSaveSelected).disable();                
                }
            }
           // buttonMap.get(commands.spritesRemember).enable();                
            if(sprites.hasMemory()) {
          //      buttonMap.get(commands.spritesRecall).enable();                                
            }else{ 
         //       buttonMap.get(commands.spritesRecall).disable();                            
            }
            
            mediaList.update();
        },
        setButtons(buttons) {
            for (const but of buttons) { buttonMap.set(but.command, but) }
            return buttons;
        }
    };
    
    return API;
})();