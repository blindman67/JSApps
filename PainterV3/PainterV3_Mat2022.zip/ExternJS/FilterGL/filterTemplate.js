/*
if (typeof filterGL !== "undefined") {
    (function () {
        var filter; // to access common properties for associated filters
        filterGL.filters.register(
            "template", filter = {
                name : "template",
                description : "This filter is a source code template that can be used to create new filters ",
                webGLFilters : null,
                shader : null,
                callback() {
                    if (this.webGLFilters === null) {
                        throw new ReferenceError("Filter '" + this.name + "' is not ready to be used. Use registerFilter to activate the filter")
                    }
                    var glF = this.webGLFilters;
                    if (this.shader === null) {
                        this.shader = glF.Shader(null, null).useLinker();
                        this.shader.setFragmentSource(`
                            uniform sampler2D texture;
                            varying vec2 texCoord;
                            void main() {                                        
                                gl_FragColor = texture2D(texture, texCoord);
                            }
                        `);
                    }
                    var uniformObj = {};
                    glF.filter(this.shader, uniformObj);
                    return glF; // Not a must but allows users to chain filters
                },
                arguments : [], // not required. These are to provide UI interfaces a way to create filter specific UI elements
                presets : { // preset names are capitalised as they are meant to be human readable options.
                    Defaults : {args : [], description : "Default and does nothing."},
                },
                utilities : {}
            }
        );
    }());
}
*/
/*

Bare bones filter setup



filterGL.filters.register(
    "template", filter = {
        name : "template",
        webGLFilters : null,
        shader : null,
        callback() {
            if (this.shader === null) {
                this.shader = this.webGLFilters.Shader(null, null);
                this.shader.setFragmentSource(`
                    uniform sampler2D texture;
                    varying vec2 texCoord;
                    void main() {                                        
                        gl_FragColor = texture2D(texture, texCoord);
                    }
                `);
            }
            this.webGLFilters.filter(this.shader, {});
            return this.webGLFilters; // to chain filters
        },
    }
);


*/
