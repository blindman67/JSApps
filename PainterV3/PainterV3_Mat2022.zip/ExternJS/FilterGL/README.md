##FilterGL

FilterGL.js is an image filtering interface that uses WebGL to provide high performance and high quality image filtering.

Uses a modular filter system allowing easy addition of new filters.

This project is in development and is changing rapidly.

##Groover Animator

Users of Groover Animator can use these filters. 
Download FilterGl and put it in the script directory including the Filters directory.
Copy the file FilterGLInterface.js to the script directory.
Navigate to Mainpage and drag and drop the file filterList.js onto the page to install.
The new filters will appear in the existing filters menu under FilterGL.
Please note that WebGl filters are currently only for the main thread. If you apply them to large images or many images they will block the UI until complete (but they are fast 20-30ms turnaround). Nor will they show progress bars and can not be cancelled and no feedback is shown until all images are complete. 

Currently the interface will not do live streams, Camera, Video files, Canvas Capture, or Gifs, and will only process the frame that was displayed at the time you selected the filter. A quick workaround is to attach a controller to the image, set it to read the image time and output the same, then link the image to the controller. This will force an update.

Currently the batch system can only re apply a filter. It does not have access to the filter arguments. Using `applyFilter 'FilterGL filtername  argument1 argument2'` will cause the filter menu to appear and the arguments ignored. I will add a fix as time permits. For now you can use `command filterRepeat` to repeat the last filter or `set filter = comSpriteObj.usedFilters[indexOfFilter]` then `applyFilter + "filter"` to use previously used filters as they have the arguments stored using the filter string as a reference. 


###Additional

FilterGL was inspired by https://github.com/evanw/webgl-filter 