It is not clear what you need in regard to circles and some point (eg the mouse).

The lack of information iin your question concerns the facts 
- that many circles can be under the point (eg mouse) at the same time. 
- and that more than one circle can move from under to out or out to under per frame. 
- the wording of the question suggest you are after just one circle which conflicts with the above 2 concerns.


This answer uses a method that alows for many properties of a circle and its relationship with a point (eg mouse) to be kept and queried without adding a too much additional CPU load (As you have indicated that you aim to have many circles)

The example below (I dropped the images as they are not relevant) draws many animated random circles on the canvas.

The circles are stored in an array that has had its properties extended called `circles` the function `circles.updateDraw(point)` updates and draws all the circles. The argument `point` is a point to check the circle against. It defaults to the `mouse`.

All circles are drawn with an outline. Circles under the point (eg mouse) are filled with green, Circles just moved to under the point (eg onMouseOver) are filled with yellow, circle that have just move out from under are filled with red.
There are 3 arrays as properties of circles that contain circles as define...
- `circles.under`  All circles under the point
- `circles.outFromUnder` All circles just out from under the point
- `circles.newUnder` All circles new to under the point

These array are populated by the function `circles.updateDraw(point)`   
Circles also have 3 functions that refer to the above arrays as `set` the default set is `circles.under`. The functions are..
- `circles.firstInSet(set)` Returns the first circle (The visual bottom most) in `set` or undefined
- `circles.lastInSet(set)` Returns the last circle (The visual top most) in `set` or undefined
- `circles.closestInSet(set)` Returns the closest circle to the point in `set` or undefined

For example to get the visual top most circle just under the mouse you would call `circles.lastInSet(circles.newUnder)` or to get the circle closest to the mouse from all circles under the mouse you would call `circles.closestInSet(circles.newUnder)` (or as it defaults to set `under` call `circles.closestInSet()` )

##Running Demo



var mouse = { x: 0, y: 0 };

addEventListener('mousemove', event => {
    mouse.x = event.clientX;
    mouse.y = event.clientY;
});

Math.TAU = Math.PI * 2;
Math.rand = (min, max) => Math.random() * (max - min) + min;
const CIRCLE_RADIUS = 50;
const UNDER_STYLE = "#0A0";
const NEW_UNDER_STYLE = "#FF0";
const OUT_STYLE = "#F00";
const CIRCLE_STYLE = "#000";
const CIRCLE_LINE_WIDTH = 3;
const CIRCLE_COUNT = 100;
var canvas = document.querySelector('canvas');
var c = canvas.getContext('2d');
canvas.width = innerWidth;
canvas.height = innerHeight;
requestAnimationFrame(() => {
    var i = CIRCLE_COUNT;
    while (i--) { 
        const r = Math.rand(CIRCLE_RADIUS / 3, CIRCLE_RADIUS);
        circles.push(new Circle(
            Math.rand(r, canvas.width - r),
            Math.rand(r, canvas.height - r),
            Math.rand(-1, 1),
            Math.rand(-1, 1),
            r
        ));
    }
    animate()
});
    
        





function Circle( x, y, dx = 0, dy = 0, radius = CIRCLE_RADIUS) {
    this.x = x + radius;
    this.y = y + radius;
    this.dx = dx;
    this.dy = dy;
    this.radius = radius;
    this.rSqr = radius * radius; // radius squared
    this.underCount = 0; // counts frames under point
}
Circle.prototype = {
    draw() { ctx.arc(this.x, this.y, this.radius, 0, Math.TAU) },
    update() {
        this.x += this.dx;
        this.y += this.dy;
        if (this.x >= canvas.width - this.radius) {
            this.x += (canvas.width - this.radius) - this.x;
            this.dx = -Math.abs(this.dx);
        } else if (this.x < this.radius) {
            this.x += radius - this.x;
            this.dx = Math.abs(this.dx);
        }
        if (this.y >= canvas.height - this.radius) {
            this.y += (canvas.height - this.radius) - this.y;
            this.dy = -Math.abs(this.dx);
        } else if (this.y < this.radius) {
            this.y += radius - this.y;
            this.dy = Math.abs(this.dy);
        }
    },
    isUnder(point = mouse) {
        this.distSqr = (this.x - point.x) ** 2 + (this.y - point.y) ** 2;  // distance squared
        return this.distSqr < this.rSqr;
    }

};
const circles = Object.assign([], {
    under:  [],
    outFromUnder:  [],
    newUnder: [],
    firstInSet(set = this.under) { return set[0] },
    lastInSet(set = this.under) { return set[set.length - 1] },
    closestInSet(set = this.under) {
        var minDist = Infinity, closest;
        if (set.length <= 1) { return set[0] }
        for (const circle of set) {
            if (circle.distSqr < minDist) {
                minDist = (closest = circle).distSqr;
            }
        }
        return closest;
    },
    updateDraw(point) {
        this.under.length = this.newUnder.length = this.outFromUnder = 0;
        ctx.strokeStyle = CIRCLE_STYLE;
        ctx.lineWidth = CIRCLE_LINE_WIDTH;
        ctx.beginPath();
        for(const circle of this) {
            circle.update();
            if (circle.isUnder(point)) {
                circle.underCount++ === 0 && this.newUnder.push(circle);
                this.under.push(circle);
            } else if (circle.underCount) {
                circle.underCount = 0;
                this.outFromUnder.push(circle);
            } 
            
            circle.draw();
        }
        ctx.stroke();
        ctx.beginPath();
        ctx.fillStyle = UNDER_STYLE;
        for (const circle of this.under) {
            if (circle.underCount > 1) { circle.draw() }
        }
        ctx.fill();

        ctx.beginPath();
        ctx.fillStyle = OUT_STYLE;
        for (const circle of this.outFromUnder) { circle.draw() }
        ctx.fill();

        ctx.beginPath();
        ctx.fillStyle = NEW_UNDER_STYLE;
        for (const circle of this.newUnder) { circle.draw() }
        ctx.fill();
    }
});
function animate() {
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    circles.updateDraw();
    requestAnimationFrame(animate);
}

