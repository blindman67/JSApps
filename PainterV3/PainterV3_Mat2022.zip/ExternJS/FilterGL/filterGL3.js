
const filterGL2 = (() => {

	function cleanSource(gl,name, source, type) {
		var show = false;
		name = name.replace(/fragment|vertex/gi,"").trim() + " " + (type === gl.VERTEX_SHADER ? "Vertex" : "Fragment") + " Shader";
		source = source.replace(/^(\s*)#NAME;.*?\n/m, "$1/* " + name[0].toUpperCase() + name.slice(1) + " */\n");
		source = source.replace(/\t/g, "    ")
			.replace(/^    /gm, "")
			.replace(/\s*$/gm, "");
		if(/^\s*#SHOW_IN_CONSOLE;.*?\n/m.test(source)) {
			source = source.replace(/^\s*#SHOW_IN_CONSOLE;.*?\n/m, "");
			show = true;
		}
		return [source, show];
	}
	const glUtils = {
		showSrc: false,
		showSrcOnError: true,   
		showErrorLine(errors, source) { 
			errors = errors.split("\n");
			var lines = "";
			for (const error of errors) {
				const  dat = error.split(":");
				if (typeof dat[2] === "string") {
					const line = dat[2].trim();
					const column = dat[1].trim();
					if (!isNaN(line) && !isNaN(column)) {
						lines += "\n" + source.split("\n") [Number(line) -1] + "\n";
						lines += "^".padStart(Number(column), " ") + " " + error;
						console.warn(line);
						lines += "\n";
					}
				}
			}
			return lines;
		},
		compileShader(gl, name, source, type) { 
			var show;
			[source, show] = cleanSource(gl, name, source, type);
			if (show || glUtils.showSrc){ console.log(("\n\n// " + name + " ").padEnd(100,"=") + "\n" + source) }
			const shader = gl.createShader(type);
			gl.shaderSource(shader, source);
			gl.compileShader(shader);
			if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
				if (glUtils.showSrcOnError && (!glUtils.showSrc && !show)) { console.log(source) }
				const error = gl.getShaderInfoLog(shader);
				throw new Error(name + " shader:\n" + glUtils.showErrorLine(error, source));
			}	
			return shader;
		},  
		linkProgram(gl, name, program) {
			gl.linkProgram(program);
			if (!gl.getProgramParameter(program, gl.LINK_STATUS)) { throw new Error(name + " link error: " + gl.getProgramInfoLog(program)) }	
		},
		createProgram(gl, vSrc, fSrc, name = "") {
			const program = gl.createProgram();
			gl.attachShader(program, glUtils.compileShader(gl, name + " vertex", vSrc, gl.VERTEX_SHADER));
			gl.attachShader(program, glUtils.compileShader(gl, name + " fragment", fSrc, gl.FRAGMENT_SHADER));
			glUtils.linkProgram(gl, name, program);	
			return program;
		},
		attBuf(type, data, use, name) { return {type, data, use, name, isBuf: true} },
		attArrayPtr(name, length, type, normalized = false, stride, divisor = 1) { return {name, length, type, normalized, stride, divisor, isArr: true, isPtr: true} },
		attArray(name, length, type = "FLOAT", normalized = false) { return {name, length, type, normalized, isArr: true} },
		setupAttributes(gl, attributes, program, stride, buffers){
			const sizes = {
				[gl.FLOAT]: 4, [gl.INT]: 4, [gl.UNSIGNED_INT]: 4,
				[gl.BYTE]: 1, [gl.UNSIGNED_BYTE]: 1,
				[gl.SHORT]: 2, [gl.UNSIGNED_SHORT]: 2,
			};			
			var offset = 0;
			const named = {};
			for (const att of attributes) {
				if (att.isArr) {
					if (att.type && typeof att.type === "string" && gl[att.type]) { att.type = gl[att.type] }
					named[att.name] = att;
					const loc = att.location = gl.getAttribLocation(program, att.name);
					gl.enableVertexAttribArray(loc);
					if (att.isPtr) {
						att.offset = offset;
						att.stride = att.stride ? att.stride : stride;
						if (att.type === gl.FLOAT || att.normalized) {
							gl.vertexAttribPointer(loc, att.length, att.type, att.normalized, att.stride, offset);
						} else {
							gl.vertexAttribIPointer(loc, att.length, att.type, att.stride, offset);
						}
						gl.vertexAttribDivisor(loc, att.divisor);
						offset += att.length * sizes[att.type];
					} else {
						gl.vertexAttribPointer(loc, att.length, att.type, att.normalized, 0, 0);
					}
				} else if (att.isBuf) {
					if (att.name) {gl.bindBuffer(att.type, buffers[att.name] = gl.createBuffer()) }
					else { gl.bindBuffer(att.type,  gl.createBuffer()) }
					gl.bufferData(att.type, att.data, att.use);		
				}				
			}
			return named;
		},	
		getLocations(gl, program, locations, ...names) {
			for(const name of names) { 
				locations[name] = gl.getUniformLocation(program, name);
				if (locations[name] === null) { console.warn("Failed to locate uniform `" + name + "`") }
			}	
			return locations;
		},
	};


    var showSourceOnShaderError = true; 
    var gl;
    var canvas;   		
    var basicShader;  	
    var flipShader;   	
    var filterCanvas; 	
    var shown = false; 	
    function isWebGLAvaliable() {
        canvas = new OffscreenCanvas(8,8);
        try {
			gl = canvas.getContext("webgl2", {premultipliedAlpha: false, antialias: false, alpha: true});
        } catch (e) {
            return false;
        }
        return true;
    }
    if (! isWebGLAvaliable() ) {
        console.warn("filterGL did not detect any webGL2 support and did not initialise");
        return undefined;
    }

    const shaderSource = {
		v3ES: "#version 300 es",
		texSize0: "vec2(textureSize(tex0, 0))",
		texSize1: "vec2(textureSize(tex1, 0))",
		texSize2: "vec2(textureSize(tex2, 0))",
		texSize3: "vec2(textureSize(tex3, 0))",
		PI: "" + Math.PI.toFixed(6),
		flipShader : 
`##v3ES##
precision mediump float;
uniform sampler2D tex0;
in vec2 coord;
out vec4 pixel;
void main() { 
	pixel = texture(tex0, vec2(coord.x, 1.0 - coord.y)); 
}
		`,
		defaultVertex: 
`##v3ES##
in vec2 verts;
uniform sampler2D tex0;
uniform vec4 clipped; // left, top, width, height in pixels
out vec2 coord;
void main() {
	vec2 p = verts * vec2(0.5, 0.5) + 0.5;
	p = p * (clipped.zw + clipped.xy) / vec2(textureSize(tex0, 0));
	coord = p;
	gl_Position = vec4((p - 0.5) * vec2(2,-2), 0.0, 1.0);
}
		`,		
		defaultFragment : 
`##v3ES##
precision mediump float;
uniform sampler2D tex0;
in vec2 coord;
out vec4 pixel;
void main() { 
	pixel = texture(tex0, coord); 
}
		`,
    }
    const Shader = (function() {

		function removeComments(source) { return source.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\/\/.*?$/gm, "\n") }
        function linkSource(source, useLinker) {
			if(useLinker) {
				source = removeComments(source);
				var len;
				while (len !== source.length) {
					len = source.length;
					Object.keys(shaderSource).forEach((name) => {
						if (typeof shaderSource[name] === "string") { 
							source = source.replace(new RegExp("##"+name+"##", "g"), shaderSource[name]);
						}
					});
				}
			}
            return source;
        }


        function Shader(vertexSource, fragmentSource) {
            var vertexAttribute = null;
            var texCoordAttribute = null;
            var program = null, vertexBuffer, namedUniforms = [];
            vertexSource = vertexSource || shaderSource.defaultVertex;
            fragmentSource = fragmentSource || shaderSource.defaultFragment;
			function compileProgram() {
				program = gl.createProgram();
				gl.attachShader(program, glUtils.compileShader(gl, "vertex", linkSource(vertexSource, useLinker), gl.VERTEX_SHADER));
				gl.attachShader(program, glUtils.compileShader(gl, "fragment", linkSource(fragmentSource, useLinker), gl.FRAGMENT_SHADER));
				glUtils.linkProgram(gl, "Program", program);				
				
				return program;
			}

			var locations = {};
            var dirty = true;
            var useLinker = false;
			var clip = new Float32Array([0, 0, 1, 1]);

            const shader = {
                setVertextSource(source) {
                    if (vertexSource !== source) {
                        vertexSource = source;
                        dirty = true;
                    }
                    return this;
                },
                setFragmentSource(source) {
                    if (fragmentSource !== source) {
                        fragmentSource = source;
                        dirty = true;
                    }
                    return this;
                },
				setUniformNames(...names) {
					namedUniforms.length = 0;
					namedUniforms = [...names];
					return this;
				},
                useLinker() { useLinker = true; return this },
                dontUseLinker() { useLinker = false; return this },
                getLinkedInUniforms(name, data) {     // some linked shader source code requires uniforms to be set
                    var func = shaderSource[name + "JS"];  
                    if (typeof func === "function") {  return func(...data) } 
                    else { throw new ReferenceError("Linked in uniform function '"+name+"JS' does not exist.") }
                },
                use(vertext, fragment) {
                    if (typeof vertext === "string") { this.setVertextSource(vertext) }
                    if (typeof fragment === "string") { this.setFragmentSource(fragment) }
                    if (dirty) {
                        if (program !== null) { this.destroy() }
                        program = compileProgram(vertexSource, fragmentSource);
						gl.bindVertexArray(vertexBuffer = gl.createVertexArray());
						glUtils.setupAttributes(gl, [
								glUtils.attBuf(gl.ELEMENT_ARRAY_BUFFER, new Uint8Array([0, 1, 2, 0, 2, 3]), gl.STATIC_DRAW),
								glUtils.attBuf(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, 1, 1, -1, 1]), gl.STATIC_DRAW),
								glUtils.attArray("verts",  2, gl.FLOAT, false),
							], program, 0, {}
						);
						locations = glUtils.getLocations(gl, program, locations,  "tex0", "clipped", ...namedUniforms);  
						namedUniforms.length = 0;
                        dirty = false;
                    }
                    gl.useProgram(program);
					gl.bindVertexArray(vertexBuffer);					
                    return this;
                },
                destroy() {
                    gl.deleteProgram(program);
					namedUniforms.length = 0;
                    vertexBuffer = program = null;
					locations = {};
                    dirty = true;
                    return this;
                },
				clip(x, y, w, h) {
					clip[0] = x;
					clip[1] = y;
					clip[2] = w;
					clip[3] = h;
				},
                uniforms(uniforms) {
                    this.use();
					gl.uniform4fv(locations.clipped, clip);
					var location;
                    if (!uniforms) { return this}
                    for (const name of Object.keys(uniforms)) {
						location = !locations[name] ? locations[name] = gl.getUniformLocation(program, name) : locations[name];

                        if (location !== null) {
                            var value = uniforms[name];
                            if (Array.isArray(value)) {
                                switch (value.length) {
                                    case 1: gl.uniform1fv(location, new Float32Array(value)); break;
                                    case 2: gl.uniform2fv(location, value); break;
                                    case 3: gl.uniform3fv(location, value); break;
                                    case 4: gl.uniform4fv(location, value); break;
                                    case 9: gl.uniformMatrix3fv(location, false, value); break;
                                    case 16: gl.uniformMatrix4fv(location, false, value); break;
                                    default:
                                        throw new Error('Can not load uniform array "' + name + '" of length ' + value.length +'. Use typed value {type : "uniform4fv", value : [array]} to define the type of array.');
                                }
                            } else if (!isNaN(value)) { gl.uniform1f(location, value) }
                            else if (typeof value === "object" ) {
                                if (value.type && gl[value.type]) {
                                    if (value.type[value.type.length -1] !== "v") {  gl[value.type](location, value.value) }
                                    else { gl[value.type](location, new Float32Array(value.value)) }
                                } else {  throw new ReferenceError('Attempted to set uniform "' + name + '" to unknown uniform type ' + value.type ) }
                            }
                        }
                    }
                    return this;
                },
                draw() {
                    this.use();
					gl.drawElements(gl.TRIANGLES, 6, gl.UNSIGNED_BYTE, 0);	
                    return this;
                },
            }
            return shader;
        }
        return Shader;
    } ());
    const Texture = (function() {
        const textureOptions = {
            linearClamped(id) {
                gl.bindTexture(gl.TEXTURE_2D, id);
                gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
                gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
                gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
                gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
            },
            nearestClamped(id) {
                gl.bindTexture(gl.TEXTURE_2D, id);
                gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
                gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
                gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
                gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
            },
        };
        function draw(texture) { // this call is unsafe (shader may not be defined)
            texture.use();
            basicShader.draw();
        }
        function Texture() {
            var type = gl.UNSIGNED_BYTE;
            var format = gl.RGBA;
            var id = gl.createTexture();
            textureOptions.linearClamped(id);
            var dirty = true;
            var width;
            var height;
            const texture = {
                width : null,
                height : null,
                isGlTexture : true,
                isDirty () { return dirty; },
                info () {  return {type, format, dirty, width, height} },
                quality (quality = "standard") {
                    if (quality.toLowerCase() === "high" && canUseFloats) {
                        if (ttype !== gl.FLOAT) {
                            type = gl.FLOAT;
                            dirty = true;
                        }
                    } else {
                        if (type !== gl.UNSIGNED_BYTE) {
                            type = gl.UNSIGNED_BYTE;
                            dirty = true;
                        }
                    }
                },
                fromData (data, width, height) {
                    this.height = height;
                    this.width = width;
                    gl.bindTexture(gl.TEXTURE_2D, id);
                    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, data);
                    dirty = true;
                },
                fromCanvas (canvas) {
                    height = this.height = canvas.height;
                    width = this.width = canvas.width;
                    this.quality("standard");
                    gl.bindTexture(gl.TEXTURE_2D, id);
                    gl.texImage2D(gl.TEXTURE_2D, 0, format, format, gl.UNSIGNED_BYTE, canvas);
                    dirty = true;
                },
                getPixelData (array) {
                    this.clean();
                    if (basicShader === undefined) { throw ReferenceError("Can not get pixel data as system has not yet properly initialised.") }
                    if (array === undefined) { array = new Uint8Array(width * height * 4) }
                    basicShader.draw();
                    gl.readPixels(0, 0, width, height, gl.RGBA, gl.UNSIGNED_BYTE, array);
                    return array;
                },
                clone (texture) {  // if texture an instance of Texture clone to it
                    if (basicShader === undefined) { throw ReferenceError("Can not clone texture as system has not yet properly initialised.") }
                    if (texture && texture.isGlTexture) { texture.asFrameBuffer() }
                    else {
                        texture = Texture();
                        texture.asFrameBuffer();
                    }
                    draw(this);
                    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
                    return texture;
                },
                asFrameBuffer () {
                    this.clean();
                    gl.framebuffer = gl.framebuffer || gl.createFramebuffer();
                    gl.bindFramebuffer(gl.FRAMEBUFFER, gl.framebuffer);
                    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, id, 0);
                    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) { throw new Error('Can not render filter, incomplete framebuffer') }
                    gl.viewport(0, 0, this.width, this.height);
                },
                destroy () {
                    gl.deleteTexture(id);
                    id = null;
                    dirty = true;
                    height = width = null;
                },
                isDestroied () { return id === null },
                bind (unit = 0) {
                    this.clean();
                    gl.activeTexture(gl.TEXTURE0 + unit);
                    gl.bindTexture(gl.TEXTURE_2D, id);
                },
                unbind (unit) {
                    gl.activeTexture(gl.TEXTURE0 + unit);
                    gl.bindTexture(gl.TEXTURE_2D, null);
                },
                clean () {
                    if (dirty || width !== this.width || height !== this.height) {
                        width = this.width;
                        height = this.height;
                        dirty = false;
                    }
                },
            }
            return texture;
        }
        return Texture;
    } ());
    const filters = {
        filterDetails : [],
        filters : {},
        availableFilters () { return this.filterDetails.map(filter => filter.name) },
        getPresetDetails (name, includeDescription) {
            const filter = this.getFilter(name);
            if (filter) {
                if (!filter.presets) { return ["Filter '"+name+"' has no presets defined."] }
                return Object.keys(filter.presets).map(pname => {
                    if (includeDescription) {
                        var desc = filter.presets[pname].description ? filter.presets[pname].description : " No description.";
                        return pname + " : " + desc;
                    }
                    return pname;
                });
            }
            return ["Could not find filter named '"+name+"'"];
        },
        getFilter (name) {
            var filterDetails = this.filterDetails.find(filter => filter.name === name);
            if (filterDetails) { return filterDetails.filter }
        },
        getFilterDefaultsArguments(name) {
            const filter = this.getFilter(name);
			return filter ? filter.arguments.map(arg => arg.range ? arg.range.def : undefined) : [];
        },   
        register (name, filter) {
            if (this.filters[name] !== undefined) { throw new ReferenceError("Filter already exists, can not add filter '"+name+"'") }
            if (!filter.callback) { throw new ReferenceError("Filter '"+name+"' is missing the required render callback ") }
			if (typeof filter.setup === "function") { filter.setup(filter) }
            this.filters[name] = filter.callback;
            if (filter.presets && !filter.presets.Defaults && ! !filter.presets.defaults) {
                console.warn("Filter '"+name+"' requires a defaults preset to allow access to presets.");
                filter.presets = undefined;
            }
            this.filterDetails.push({name, filter});
            filter.webGLFilters = filterCanvas;
        }
    }
    /* helper functions */
    function getObjectTypeString(object) {return object.toString().replace(/\[object |\]/g, "") }
    function isObject(object) {return !(Array.isArray(object) || typeof object !== "object" || object.isGlTexture) }
    function isImage(object) {return isObject(object) && getObjectTypeString(object) === "HTMLImageElement"}
    function isCanvas(object) { return isObject(object) && (getObjectTypeString(object) === "HTMLCanvasElement" || object instanceof OffscreenCanvas) }
    function is2DContext(object) {return isObject(object) && getObjectTypeString(object) === "CanvasRenderingContext2D"}
    const createBasicShader = () => Shader();
    function attachFilters() {
        filters.availableFilters().forEach(name => {
            var filter = filters.getFilter(name);
            filterCanvas[name] = filters.filters[name].bind(filter);
            if (filter.presets) {
                filterCanvas[name + "Preset"] = (function (presetName) {
                    var preset = this.presets[presetName].args;
                    if (preset === undefined) { preset = this.presets.defaults.args }
                    return this.callback(...preset);
                }).bind(filter);
            }
        });
    }
    const glCanvas = {
        frameBufs : [],
        sourceTexture : null,
        nextBuffer : 0,
        iterations : 0,
        Shader : Shader,
        filters : filters,
        clearNext : false,
		getContext() { return gl },
		addShaderLinkables(linkables) {
			for(const name of Object.keys(linkables)) {  shaderSource[name] = linkables[name] }
		},
        hex2RGB(hexColor, RGBOut = []) {
			if(Array.isArray(hexColor)) {
				RGBOut[0] = hexColor[0];  /* range 0 - 255 */
				RGBOut[1] = hexColor[1];
				RGBOut[2] = hexColor[2];				
			} else {
				RGBOut[0] = parseInt(hexColor.substr(1, 2), 16);
				RGBOut[1] = parseInt(hexColor.substr(3, 2), 16);
				RGBOut[2] = parseInt(hexColor.substr(5, 2), 16);
			}
            return RGBOut;
        },
        isSourceTextureSet() { return this.sourceTexture !== null && this.sourceTexture !== undefined && this.sourceTexture.isGlTexture },
        clearSource() {
            if (this.isSourceTextureSet()) {
                if (this.sourceTexture.isDestroied) {
                    this.sourceTexture = null;
                    return;
                }
                console.warn("Source image will need to be deleted");
                this.sourceTexture = null;
            }
        },
        getSource(image) {
            if (this.sourceTexture) {
                if (typeof image === "string") {
                    if (image.toLowerCase() === "texture") { return this.sourceTexture }
                    else if (image.toLowerCase() === "texture copy") { return this.sourceTexture.clone() }
                    else if (image.toLowerCase() === "canvas") {
                        this.sourceTexture.bind();
                        flipShader.draw();
                        var can = document.createElement("canvas");
                        can.width = this.width;
                        can.height = this.height;
                        var ctx = can.getContext("2d");
                        ctx.drawImage(this.canvas, 0, 0);
                        return canvas;
                    } else  if (image.toLowerCase() === "pixeldata") {
                        this.sourceTexture.bind();
                        return this.sourceTexture.getPixelData();
                    }
                    return undefined;
                } else if (image.isGlTexture) { return this.sourceTexture.clone(image) }
                else if (isImage(image)) {
                    console.warn("Unsupported request for source image. Images as data URLs are intended for safe transport over networks, not for use within a system. If you wish to display the image on the DOM use a canvas.");
                    return image;
                } else if (isCanvas(image) || is2DContext(image)) {
                    var ctx = image;
                    if (isCanvas(image)) { ctx = image.getContext("2d") }
                    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
                    this.sourceTexture.bind();
                    flipShader.draw();
                    if (ctx.globalAlpha != 1 || ctx.globalCompositeOperation !== "source-over") {
                        console.warn("getSource canvas provided may not be in the default state. Result may not be as expected");
                    }
                    ctx.save();
                    ctx.setTransform(1, 0, 0, 1, 0, 0);
                    ctx.drawImage(this.canvas, 0, 0, ctx.canvas.width, ctx.canvas.height);
                    ctx.restore();
                    return image;
                } else if (Array.isArray(image)) {
                    if (image.length !== this.sourceTexture.width * this.sourceTexture.height * 4) {
                        throw new RangeError("getSource can not use the provided array as the size does not match the source image.");
                    }
                    this.sourceTexture.bind();
                    return this.sourceTexture.getPixelData(image);
                }
            } else { throw new RefernceError("The source image has not been set and thus not available to get.") }
            console.warn("The call to getSource could not determine the format or the return image and returned undefined.");
        },
        setSource(image) { return this.draw(image) },
        draw(image) {
            if (!basicShader) {
                basicShader = Shader().useLinker();
                flipShader = Shader().setFragmentSource(shaderSource.flipShader).useLinker();
            }
            if (image) {
                if (!image.isGlTexture) { this.sourceTexture.fromCanvas(image) }
                else {
                    if (this.sourceTexture && this.sourceTexture.isGlTexture) { this.sourceTexture.destroy() }
                    this.sourceTexture = image;
                }
            }
            if (!this.isSourceTextureSet()) { throw new ReferenceError("Can not set source as the sourceTexture is missing or invalid.") }
            this.width = this.canvas.width = this.sourceTexture.width;
            this.height = this.canvas.height = this.sourceTexture.height;
            if (this.frameBufs[0].width !== this.width || this.frameBufs[0].height !== this.height) {
                this.frameBufs[0].fromCanvas(this.canvas)
                this.frameBufs[1].fromCanvas(this.canvas)
            }
            gl.viewport(0, 0, this.width, this.height);
            this.sourceTexture.bind();
            basicShader.draw();
            shown = true;
            this.iterations = 0;
            return this;
        },
        clearBufferBeforDraw() { this.clearNext = true },
        filter(shader, uniforms, destination, sources) {
			var directToGLCanvas = false
            if (shader === undefined || shader === null) { throw new ReferenceError("Filter requires a shader.") }
            this.iterations = shown ? 0 : this.iterations + 1;
            if (destination && destination.isGlTexture) { destination.asFrameBuffer() }
            else {
				if (this.iterations === 0) {
					gl.bindFramebuffer(gl.FRAMEBUFFER, null);
					directToGLCanvas = true;
				} else {
					this.nextBuffer = (this.nextBuffer + 1) % 2;
					this.frameBufs[this.nextBuffer].asFrameBuffer();
				}
            }
            shader.uniforms(uniforms);
            if (sources) {
                if (Array.isArray(sources)) {
                    sources.forEach((source, i) => { if (source.isGlTexture) { source.bind(i + 1) } });
                } else if (sources.isGlTexture) { sources.bind(1) }
            }
            if (this.clearNext) {
                gl.clear(gl.COLOR_BUFFER_BIT);
                gl.clearColor(0.0, 0.0, 0.0, 0.0);
                this.clearNext = false;
            }
            shader.draw();
			if (!directToGLCanvas){
				gl.bindFramebuffer(gl.FRAMEBUFFER, null);
				this.frameBufs[this.nextBuffer].bind();
			}
            shown = false;
        },
        fromSource() {
            this.nextBuffer = 0;  
            gl.bindFramebuffer(gl.FRAMEBUFFER, null);  // remove any frame buffer binding that may still be active
            this.sourceTexture.bind();
            return this; 
        },
        copyBufferTo(texture) {  // draws the last rendered to frame buffer to texture
            gl.bindFramebuffer(gl.FRAMEBUFFER, null); // remove any frame buffer binding that may still be active
            this.frameBufs[this.nextBuffer].bind();
            texture.asFrameBuffer();
            basicShader.draw();
            gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        },
        show() {
            flipShader.draw();
            this.nextBuffer = 0;
            this.sourceTexture.bind();
            shown = true;
            return this;
        },
        completed() {
            if (!shown) {
                flipShader.draw();
                shown = true;
            }
            this.draw(this.canvas);
            this.sourceTexture.bind();
            return this;
        },
		createTexture() { return Texture() },			
        create() {
            this.canvas = canvas;
            attachFilters();
            this.frameBufs[0] = this.createTexture(canvas);
            this.frameBufs[1] = this.createTexture(canvas);
            return this;
        }
    }
    filterCanvas = glCanvas.create();
    glCanvas.create = undefined; // only used once so remove it

    return {
		addShaderLinkables(linkables) { glCanvas.addShaderLinkables(linkables) },
        filters : filters,
        create() {
            attachFilters();
            return filterCanvas;
        }
    };
}) ();