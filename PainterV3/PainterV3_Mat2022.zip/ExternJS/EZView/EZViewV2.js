"use strict"; /*## if not MODULE remove line #*/
/*## if TARGETS.includes("IE") BUILD_ERROR file " does not support IE" #*/
/*## if RENDER_WEBGL use alternative "../webGL/EZViewV3.js" #*/
/*## if RENDER_WEBGL2 use alternative "../webGL2/EZViewV3.js" #*/
/*## if MODULE
export {ezView};
#*/
/*## if TARGETS.includes("fireFox") SUPPORT_OFFSCREEN = false #*/
/*## if BUILD_DETAILS insert comments(BUILD_DETAILS.toString()) #*/
/*## lint pass(alias compoundLine) warn(let unhoisted slowLoops this semicolon) #*/
function ezView(settings = {}) {
    var dirty = true;
    var rotate = 0;
    var scale = 1;
    var ctx;
    const V2 = (x = 0, y = 0) => ({x, y});
    const pinch = {
        dist: 0,
        scale: 1,
        angle: 0,
        startAngle: 0,
        origin: V2(),
        originWorld: V2(),
    };
    const matrix = [1, 0, 0, 1, 0, 0];
    const invMatrix = [1, 0, 0, 1, 0, 0];
    const m  = matrix;    // alias
    const im = invMatrix; // alias
    const views = [];
    const pos = V2();
    const bounds = {top: 0, left: 0, right: 200, bottom: 200};
    const workPoint1 = V2();
    const workPoint2 = V2();
    const wp1 = workPoint1; // alias
    const wp2 = workPoint2; // alias
    const tweenStart = {
        pos: V2(),
        scale: 1,
        rotate: 0,
    }
    const tweenEnd = {
        pos: V2(),
        scale: 1,
        rotate: 0,
    }
    const bExtent = {
        p1: V2(),  // top left and then around clockwise
        p2: V2(),
        p3: V2(),
        p4: V2(),
        ...bounds,
    };
    const boundRot = {...bExtent};
    function toWorld(p) {
        p.x -= m[4];
        p.y -= m[5];
        wp2.x = p.x * im[0] + p.y * im[2];
        wp2.y = p.x * im[1] + p.y * im[3];
    }
    function toScreen(p) {
        wp2.x = p.x * m[0] + p.y * m[2] + m[4];
        wp2.y = p.x * m[1] + p.y * m[3] + m[5];
    }
    function boundExtent(bounds) {
        var tx, ty, lx, ly, rx, ry;
        const b = bExtent;
        b.p1.x   = (tx = bounds.top * m[0]) + (lx = bounds.left * m[2]) + m[4];
        b.p1.y   = (ty = bounds.top * m[1]) + (ly = bounds.left * m[3]) + m[5];
        b.p2.x   = tx + (rx = bounds.right * m[2]) + m[4];
        b.p2.y   = ty + (ry = bounds.right * m[3]) + m[5];
        b.p3.x   = (tx = bounds.bottom * m[0]) + rx + m[4];
        b.p3.y   = (ty = bounds.bottom * m[1]) + ry + m[5];
        b.p4.x   = tx + lx + m[4];
        b.p4.y   = ty + ly + m[5];
        b.left   = Math.min(b.p1.x, b.p2.x, b.p3.x, b.p4.x);
        b.top    = Math.min(b.p1.y, b.p2.y, b.p3.y, b.p4.y);
        b.right  = Math.max(b.p1.x, b.p2.x, b.p3.x, b.p4.x);
        b.bottom = Math.max(b.p1.y, b.p2.y, b.p3.y, b.p4.y);
        return b;
    }
    function rotateBoundsExtent(bounds) {
        var tx, ty, lx, ly, rx, ry;
        const xdx = Math.cos(rotate);
        const xdy = Math.sin(rotate);
        const b = boundRot;
        b.p1.x   = (tx = bounds.top * xdx) - (lx = bounds.left * xdy);
        b.p1.y   = (ty = bounds.top * xdy) + (ly = bounds.left * xdx);
        b.p2.x   = tx - (rx = bounds.right * xdy);
        b.p2.y   = ty + (ry = bounds.right * xdx);
        b.p3.x   = (tx = bounds.bottom * xdx) - rx;
        b.p3.y   = (ty = bounds.bottom * xdy) + ry;
        b.p4.x   = tx - lx;
        b.p4.y   = ty + ly;
        b.left   = Math.min(b.p1.x, b.p2.x, b.p3.x, b.p4.x);
        b.top    = Math.min(b.p1.y, b.p2.y, b.p3.y, b.p4.y);
        b.right  = Math.max(b.p1.x, b.p2.x, b.p3.x, b.p4.x);
        b.bottom = Math.max(b.p1.y, b.p2.y, b.p3.y, b.p4.y);
        return b;
    }
    const API = Object.freeze({
        applyIdent(_ctx = ctx) { _ctx.setTransform(1, 0, 0, 1, 0, 0) },
        apply(_ctx = ctx) {
            if (dirty) { API.update() }
            _ctx.setTransform(m[0], m[1], m[2], m[3], m[4], m[5]);
        },
        get matrix() { if (dirty) { API.update() } return [...matrix] },
        get invMatrix() { if (dirty) { API.update() } return [...invMatrix] },
        get matrixRef() { return matrix },
        get invMatrixRef() { return invMatrix },
        get scale() { return scale },
        get invScale() { return 1 / scale },
        get rotation() { return rotate },
        get position() { return {x : pos.x, y : pos.y} },
        get x() { return pos.x },
        get y() { return pos.y },
        get context() { return ctx },
        get width() { return ctx.canvas.width },
        get height() { return ctx.canvas.height },
        get viewWidth() { return ctx.canvas.width / scale },
        get viewHeight() { return ctx.canvas.height / scale },
        /*## if SUPPORT_OFFSCREEN remove to MARK_OFFSCREEN #*/
        set context (context) {
            if (context instanceof CanvasRenderingContext2D) {
                ctx = context;
                dirty = true;
            } else { throw new ReferenceError("EZViewV2.context Argument is not an instance of CanvasRenderingContext2D") }
        }, /*## MARK_OFFSCREEN #*/
        /*## if SUPPORT_OFFSCREEN
        set context (context) {
            if (context instanceof CanvasRenderingContext2D || context instanceof OffscreenCanvas) {
                ctx = context;
                dirty = true;
            } else { throw new ReferenceError("EZViewV2.context Argument is not an instance of CanvasRenderingContext2D or OffscreenCanvas") }
        },
        #*/
        set widget(wig) {
            rotate = Math.atan2(wig.key.im[1], wig.key.im[0]);
            scale = Math.min(ctx.canvas.width / (wig.w * wig.sx), ctx.canvas.height / (wig.h * wig.sy));
            pos.x = ctx.canvas.width / 2  - (wig.x * Math.cos(rotate) * scale - wig.y * Math.sin(rotate) * scale );
            pos.y = ctx.canvas.height / 2 - (wig.x * Math.sin(rotate) * scale + wig.y * Math.cos(rotate) * scale );
            dirty = true;
        },
        set position(point) {  pos.x = point.x; pos.y = point.y; dirty = true },
        set scale(_scale) { scale = _scale; dirty = true },
        set rotate(_rot) { rotate = _rot; dirty = true },
        getPosition(point = V2()) { point.x = pos.x; point.y = pos.y; return point },
        isDirty: () => dirty,  /*## if not LEGACY remove line #*/
        update() {
            dirty = false;
            const xdx = Math.cos(rotate) * scale;
            const xdy = Math.sin(rotate) * scale;
            m[3] = m[0] = xdx;
            m[2] = -(m[1] = xdy);
            m[4] = pos.x;
            m[5] = pos.y;
            const cross = xdx * xdx + xdy * xdy;
            im[3] = im[0] = xdx / cross;
            im[1] = -(im[2] = xdy / cross);
        },
        save(name) {
            var savedView = views[name];
            if (dirty) { API.update() }
            if (savedView === undefined) { views[name] = savedView = {rotate, scale, pos: V2(pos.x, pos.y)} }
            else {
                savedView.rotate = rotate;
                savedView.scale = scale;
                savedView.pos.x = pos.x;
                savedView.pos.y = pos.y;
            }
            return savedView;
        },
        restore(name) {
            const savedView = views[name];
            if (savedView) {
                rotate = savedView.rotate;
                scale = savedView.scale;
                pos.x = savedView.pos.x;
                pos.y = savedView.pos.y;
                API.update();
                return true;
            }
            return false;
        },
        transition(amount) {
            amount = amount < 0 ? 0 : amount > 1 ? 1 : amount;
            pos.x = (tweenEnd.pos.x - tweenStart.pos.x) * amount + tweenStart.pos.x;
            pos.y = (tweenEnd.pos.y - tweenStart.pos.y) * amount + tweenStart.pos.y;
            pos.scale = (tweenEnd.scale - tweenStart.scale) * amount + tweenStart.scale;
            pos.rotate = (tweenEnd.rotate - tweenStart.rotate) * amount + tweenStart.rotate;
        },
        createTransition(start, end) {
            if (start) {
                if (views[start] !== undefined) {
                    Object.assign(tweenStart,views[start]);
                } else {
                    if (dirty) { API.update() }
                    tweenStart.pos.x = pos.x;
                    tweenStart.pos.y = pos.y;
                    tweenStart.scale = scale;
                    tweenStart.rotate = rotate;
                }
            }
            if (end) {
                if (views[end] !== undefined) {
                    Object.assign(tweenEnd,views[end]);
                } else {
                    if (dirty) { API.update() }
                    tweenEnd.pos.x = pos.x;
                    tweenEnd.pos.y = pos.y;
                    tweenEnd.scale = scale;
                    tweenEnd.rotate = rotate;
                }
            }
        },
        worldCorners(result = []) {
            if (ctx === undefined) { throw new ReferenceError("EZViewV2.worldCorners. Requiers a 2D context") }
            if (dirty) { API.update() }
            result[0] = API.toWorld(0, 0, result[0]);
            result[1] = API.toWorld(ctx.canvas.width, 0, result[1]);
            result[2] = API.toWorld(ctx.canvas.width, ctx.canvas.height, result[2]);
            result[3] = API.toWorld(0, ctx.canvas.height, result[3]);
            return result;
        },
        toWorld(x, y, point = {}) {
            if (dirty) { API.update() }
            const xx = x - m[4];
            const yy = y - m[5];
            point.x = xx * im[0] + yy * im[2];
            point.y = xx * im[1] + yy * im[3];
            return point;
        },
        toScreen(x, y, point = {}) {
            if (dirty) { API.update() }
            point.x = x * m[0] + y * m[2] + m[4];
            point.y = x * m[1] + y * m[3] + m[5];
            return point;
        },
        centerOn(x, y) {
            if (dirty) { API.update() }
            pos.x = ctx.canvas.width / 2  - (x * m[0] + y * m[2]);
            pos.y = ctx.canvas.height / 2 - (x * m[1] + y * m[3]);
            dirty = true;
        },
        rotateBy(angle) { rotate += angle; dirty = true },
        rotateAt(x, y, angle) {
            API.toWorld(x, y, wp1);
            rotate += angle;
            API.update();
            pos.x = x - wp1.x * m[0] - wp1.y * m[2];
            pos.y = y - wp1.x * m[1] - wp1.y * m[3];
            dirty = true;
        },
        movePos(x, y) { pos.x += x; pos.y += y; dirty = true },
        setPos(x, y) { pos.x = x; pos.y = y; dirty = true },
        scaleTo(scaleType = "fit") {
            if ((scaleType = scaleType.toLowerCase()) === "fit") {
                scale = Math.min(
                    ctx.canvas.width / (bounds.right - bounds.left) ,
                    ctx.canvas.height / (bounds.bottom - bounds.top)
                 );
            } else if (scaleType === "fill") {
                scale =  Math.max(
                    ctx.canvas.width / (bounds.right - bounds.left) ,
                    ctx.canvas.height / (bounds.bottom - bounds.top)
                );
            }
            else { scale = 1 }
            dirty = true;
        },
        scaleAt(x, y, sc) {
            if (dirty) { API.update() }
            //sc = (scale * sc) / scale;
            scale *= sc;
            pos.x = x - (x - pos.x) * sc;
            pos.y = y - (y - pos.y) * sc;
            dirty = true;
        },
        setPinchStart(p1, p2) {
            if (dirty) { API.update() }
            pinch.origin.x = p1.x;
            pinch.origin.y = p1.y;
            const x = (p2.x - pinch.origin.x);
            const y = (p2.y - pinch.origin.y);
            pinch.dist = Math.sqrt(x * x + y * y);
            pinch.startAngle = Math.atan2(y, x);
            pinch.scale = scale;
            pinch.angle = rotate;
            API.toWorld(pinch.origin, pinch.originWorld);
        },
        movePinch(p1, p2, dontRotate) {
            if (dirty) { API.update() }
            const x = p2.x - p1.x;
            const y = p2.y - p1.y;
            const pDist = Math.sqrt(x * x + y * y);
            scale = pinch.scale * (pDist / pinch.dist);
            if (!dontRotate) { rotate = pinch.angle + (Math.atan2(y, x) - pinch.startAngle) }
            API.update();
            pos.x = p1.x - pinch.originWorld.x * m[0] - pinch.originWorld.y * m[2];
            pos.y = p1.y - pinch.originWorld.x * m[1] - pinch.originWorld.y * m[3];
            dirty = true;
        },
        setBounds (top, left, right, bottom) {
            if (left === undefined) {
                bounds.top = top.top;
                bounds.left = top.left;
                bounds.right = top.right;
                bounds.bottom = top.bottom;
            }else{
                bounds.top = top;
                bounds.left = left;
                bounds.right = right;
                bounds.bottom = bottom;
            }
        },
        /*## if not PAINTERV3 remove to MARK_PAINTERV3 #*/   // painter does not support JS_BUILDER so function must be default
        fitImage(image, fitType = "fill") {  /* This function is not part of EZView */
            console.warn("fitImage is not part of EZViewV2. Do not use.");
            if ((fitType = fitType.toLowerCase()) === "fit") { scale = Math.min(width / image.width, height / image.height) }
            else if (fitType === "fill") { scale = Math.max(width / image.width, height / image.height) }
            else { scale = 1 }
            pos.x = width / 2;
            pos.y = height / 2;
            dirty = true;
        }
        /*## MARK_PAINTERV3 #*/
    });
    if (settings.ctx) { API.context = settings.ctx }
    else if (settings.context) { API.context = settings.context }
    if (settings.bounds) { API.setBounds(settings.bounds) }
    return API;
};