EZView 

Canvas transform utility.

For panning, zooming, rotating a view, via code, mouse, and or touch.

See CodePen example 