# CanvasGroover

THIS IS A WORK IN PROGRESS 

## Why write CanvasGroover?

I do a lot of canvas work for teaching, tutorials, demos, and more and I find my self writing the same code over and over. The canvas 2D api is great but lacks some functionality in regard to basic rendering options.

For example to draw a circle is a painfull

```Javascript
    ctx.beginPath();
    ctx.strokeStyle = "red";
    ctx.strokeWidth = 3;
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.stroke();
```
    
5 lines to draw a circle!!    
 
or a line 
    
```Javascript
    ctx.beginPath();
    ctx.strokeStyle = "red";
    ctx.strokeWidth = 3;
    ctx.moveTo(x, y);
    ctx.lineTo(x1, y1);
    ctx.stroke();
```

6 lines to draw a line!!

So I wrote CanvasGroover that adds additional functionality to the canvas 2D context. Now these types of basic rendering functions are just one liners

```Javascript
    // A circle
    ctx.strokeCircle(cx, cy, radius, "red", 3);
    
    //A line 
    ctx.strokeLine(x1, y1, x2, y2, "red", 3);
```
    


# #What does CanvasGroover do?

CanvasGroover adds a veriaty of rendering functions to a context. From basic shapes, markers, paths, and more. Matching closely the function and nameing protocals of the existing functionality. 

## Using CanvasGroover

Add the Javascript file to the page, or use the module version in import.

Add the extentions to the context as needed.

Let CanvasGroover do all the set up.

```Javascript
    const {canvas, ctx} = CanvasGroover("#canvas")
```

Or part of the work    

```Javascript
    const canvas = document.querySelector("#canvas");
    const ctx = CanvasGroover(canvas); // adds all extensions returning the context
    // or
    const ctx = CanvasGroover(canvas, {shapes : true, markers : true}); // add only shapes and markers extentions returning the context
    
    
    const canvas = document.querySelector("#canvas");
    const ctx = canvas.getContext("2d");
    CanvasGroover(ctx); // add all canvasShape extensions
    // or
    CanvasGroover(ctx, {shapes : true, markers : true}); // add only shapes and markers extentions
```
    
Once the extentions have been added they are ready to use.

## Avialible extensions

To keep the global prototypes clean the CanvasRenderingContext2D prototype is not modiffied, and rather than add extentions to the context.prototype I add them directly to the context object.

There are currently 4, oh been busy make that extension that you can add to the context. 

1. Shapes. A variaty of lines paths, circles, polygons, etc
2. Markers. Single point and array of point markers in a veriaty of styles. Including custome marks.
3. Arrow. Lines with arrow heads and tails in a veriaty of styles
4. Gradients. A gradient creation function that simplifies the process of creating gradients
5. PixelArt. For drawing without anti-aliasing.
6. Images. For variouse image rendering operations.  
7. Styles. For creating and managing rendering styles.
8. Text. For better text control, text to fit, text along line, an more to come
9. Fill. What the can realy is missing, flood fills. Flood fill with full style control, variable tollerance levels, antialied edges, selectable edge only fills and diagonal (fill along lines where pixels only touch at the corners)
10. Plot. This one is still cooking in the development oven, but will be used to render data sets.

You can activate the extentions with the following settings

```Javascript
    const settings = {
        shapes    : true,
        markers   : true,
        arrows    : true,
        gradients : true,
        pixelArt  : true,
        images    : true,
    }
    CanvasGroover(context, settings);
```

## Performance matters.

There is unfortunatly a small performance penalty when using CanvasGroover. Every effort has been made to keep performance as high as possible and rely on some assuptions.

1. Resposibility of correct arguments is up to you. Though there is a small amount of vetting, passing bad arguments will ethier be ignored or will throw errors from the native 2D API.
2. There are three style setups. None, native, and smart. None provides the best performance but leaves the style settings to you, native uses the native 2D API style names and settings, and Smart uses CanvasGroover styles settings.

## Naming and arguments.

Function naming is the same as the standard API with the basic shape and no stroke, or fill.

```Javascript
    ctx.circle(x, y, radius);
```

And then with fill and stroke options

```Javascript
    ctx.strokeCircle(x, y, radius);
    ctx.fillCircle(x, y, radius);
```
    
 Not all shapes can be filled such as a line so it only has the two options
 
```Javascript
    ctx.line(x1, y1, x2, y2);
    ctx.strokeLine(x1, y1, x2, y2);
```
    
Most functions that render the fill or stroke also take an optional last argument: style which is an object containing the style settings.


```Javascript
    ctx.strokeLine(x1, y1, x2, y2, {color : "red", lineWidth : 3});
    ctx.fillCircle(x1, y1, radius, {color : "blue", alpha : 0.1});
```
    
## Style in CanvasGroover

The many context settings like lineWidth, globalAlpha, etc are all grouped under the banner Style. 

There are 3 ways to define a style in CanvasGroover

1. As a text string, eg "red" sets the context style to the colour red
2. Style object. A adhock object containing named style values. eg {color : "red"}
3. CanvasGrooverStyle object. An optimised form of the above style object attached to the context as a named style.

You can set a style with the functoin `ctx.setStyle(style)` or add the style to the shape function `ctx.fillCircle(x,y,r,style)`

Styles are only avalible for functions that render.
    
    
### Style properties    

I find that the standard naming of context properties somewhat clumbersum so have mad some minor modifictions.

CanvasGroover Style argument properties

```Javascript
        color :     // set ctx.fillStyle or ctx.strokeStyle properties depending on the render type fill of stroke
        fillStyle : // sets ctx.fillStyle if color and fillStyle are pressent fillStyle is used
        strokeStyle:// sets ctx.strokeStyle if color and strokeStyle are pressent strokeStyle is used
        alpha :     // uses ctx.globalAlpha to set the alpha
        cap :       // sets ctx.lineCap  
        join :      // sets ctx.lineJoin
        composite : // sets ctx.globalCompositeOperation
        comp :      // shorthand for composite
        filter :    // sets ctx.filter
        smooth :    // sets ctx.imageSmoothingEnabled
        font :      // sets ctx.font
        fontSize :  // keeps current font but changes the size
        baseline :  // sets ctx.textBaseline.
        align :     // sets ctx.textAlign 
        size :      // sets custom property ctx.featureSize
        aspect :    // sets custom property ctx.featureAspect
```
        
Special style properties

    size : number 
    
        Sets the featureSize property of the context. `featureSize` is a custom property added by CanvasGroover and controls the size of features like arrow heads, and marks. 
        
        The range is unbound, any value is valid, whether it is practical I leave to you.

        The default is 10


    aspect : number

        Sets the featureAspect property of the context. `featureAspect` is a custom property added by CanvasGroover and controls the aspect of 2D features like arrows. 
        
        The range is unbound, any value is valid, whether it is practical I leave to you.
        The default is 1
     


    fontSize : number
    
         CanvasGroover only uses pixel units. Font size sets the font size without the need to set the font family

    fillRule : string one of "nonzero","evenodd"
    
        Sets the fill rule used by fill renders

    restore : boolean

        When set the current context style settings are restored after the shape function is complete
                
    shadow :    // sets up ctx.shadowColor, ctx.shadowOffsetX, ctx.shadowOffsetY, and ctx.shadowBlur
    
        Shortcut text setting for shaddow eg style.shadow = "black 5 6 2"; setup a shadow color "black" x,y offsets as [5,6] and blur 2
 
Creating a named style.

For the best performance it is recogmened that you use the CanvasGrooverStyle (named style). You must have the styles extension added.

To create a named style

```Javascript
    const myStyle = ctx.addStyle("myStyle", style); // returns the new style object
```
    
You can use the style directly

```Javascript
    ctx.fillCircle(x,y,r, myStyle);
```
    
Or retrevie it from the context

  ```Javascript
  ctx.fillCircle(x,y,r, ctx.styles.myStyle);
```
    
    
    

 
Variouse shapes have selectable named settings. The names are case sensitive.
    
    
Markers are shapes drawn at points. The following predefined marks can be selected with
    
    ctx.markType(markName);
    
markName is one of the following
- x
- dimond
- triangle
- cross
- box
- circle

Arrows are lines with optional arrows at the start and end of the line. You set the types with

```Javascript
    ctx.setArrowStart(arrowName)  // set arrow type at start of line
    ctx.setArrowEnd(arrowName)    // set arrow type at end of line
    ctx.setArrowStart(arrowName)  // set arrow type at both ends
```

arrowName  is one of the following   
- none 
- open 
- closed 
- closedInset
- flat
- cross
- boxOver
- box
- sharp
- blunt
            

The following extensions are not optional

- setStyle(style)            
- setDefault() // restores canvas state to the default

## Markers 

Marker extensions. Use settings option `settings.markers = true` to use.

- markType(name)
- customMark(name, markFunction)
- mark(x, y, size)
- strokeMark(x, y, size, style)
- marks(points, size)   
- strokeMarks(points, size, style)
    
## Arrows 
    
Arrows extensions. Use settings option `settings.arrows = true` to use.

- setArrowStart(name)
- setArrowEnd(name)
- setArrowEnds(name)
- arrowLine(x1, y1, x2, y2, width, length)
- strokeArrowLine(x1, y1, x2, y2, width, length, style)
- fillArrowLine(x1, y1, x2, y2, width, length, style)

 
## Shapes
 
Shape extensions. Use settings option `settings.shapes = true` to use.


- clear()
- fillAll(style)

### Basic paths

- line(x1, y1, x2, y2)
- path(points)
- hub(cx, cy, radius1, radius2, start, end)
- pie(cx, cy, radius, from, width)
- circle(cx, cy, radius)
- star(cx, cy, radius1, radius2, points, start = 0)
- pill(x1, y1, x2, y2, radius)
- roundedRect(x, y, w, h, radius)
- polygon(cx, cy, radius, sides, start = 0, forced = false)
- roundedPath(points, radius)

### Stroke variants

- strokeLine(x1, y1, x2, y2, style)
- strokeRectangle(x, y, w, h, style);
- strokePath(points, style)
- strokeHub(cx, cy, radius1, radius2, start, end, style)
- strokePie(cx, cy, radius, from, width, style)
- strokeCircle(cx, cy, radius, style)
- strokeStar(cx, cy, radius1, radius2, points, start, style)
- strokePolygon(cx, cy, radius, sides, start, style, forced = false)
- strokeRoundedRect(x, y, w, h, radius, style)
- strokeRoundedPath(points, radius, style)
- strokePill(x1, y1, x2, y2, radius, style)

### Fill variants

- fillRectangle(x, y, w, h, style);
- fillHub(cx, cy, radius1, radius2, start, end, style)
- fillPie(cx, cy, radius, from, width, style)
- fillCircle(cx, cy, radius, style)
- fillStar(cx, cy, radius1, radius2, points, start, style)
- fillPolygon(cx, cy, radius, sides, start, style, forced = false)
- fillRoundedRect(x, y, w, h, radius, style)
- fillRoundedPath(points, radius, style)
- fillPill(x1, y1, x2, y2, radius, style)

## Gradients
 
Gradient extensions. Use settings option `settings.gradients = true` to use.

- createGradient(type, coords, colors)
- createHSLGradient(type, coords, dist, colors)

## Styles

Styles extensions. Use settings option `settings.styles = true` to use.

- addStyle(name, style)

## Text

Text extensions. Use settings option `settings.text = true` to use.

- fillTextRect(text, x, y, width, height, style);
- strokeTextRect(text, x, y, width, height, style);
- fillTextLine(text, x1, y1, x2, y2, style);
- strokeTextLine(text, x1, y1, x2, y2, style);


## FloodFill

FloodFill extentions. Use settings option `settings.fill = true` to use.

- edgeFill(x, y, tolerance, diagonal, edgeSelect, style);
- floodFill(x, y, tolerance, diagonal, aliasEdge, style);
- floodFillMask(x, y, tolerance, diagonal, aliasEdge, style);            
- edgeFill(x, y, tolerance, diagonal, edgeSelect, style);              
- floodFillMaskInfo(result);  

edgeFill like a normal fill but only fills pixels at the edge of the fill area. `edgeSelect` has 8 flags that indicate which edges to fill. From bit 0 one bit represent the 4 edges and 4 coners of each edge pixel found. top, right, bottom, left, topLeft, topRight, bottomRigh, bottomLeft.

To fill only edge pixels that have an outside pixel to the left, topLeft, and top set the corrsponding bits `edgeSelect = 0b11001` And yes I know that for many binary is another language and there is a note in the source to address this problem with some semantic style rules.
            






