/*_# func Math.rand(range) _# return random double (+) 0 <= return < range or (-) range < return <= 0 */
/*_# func Math.randI(range) _# return random int32 (+) 0 <= return < range (-) range < return <= 0 _# note range must be inside int32 range */
/*_# func Math.rand(min, max) 
  _# sig (min, max) _# return random double (+) min <= return < max or (-) max < return <= min
  _# sig (range) _# return random double (+) 0 <= return < range or (-) range < return <= 0
  _# sig () _# return random double (+) 0 <= return < 1 */
/*_# func Math.randI(min, max) 
  _# sig (min, max) _# return random int32 (+) min <= return < max (-) max < return <= min _# note min and max must be inside int32 range
  _# sig (range) _# return random int32 (+) 0 <= return < range (-) range < return <= 0 _# note range must be inside int32 range 
  _# sig () _# return random value 0, or 1  */
/*_# func Math.inceptY(x1, y1, x2, y2, x) _# return y at x of line x1, y1, x2, y2 _# note if x1 == x2 the return is (+ or -) Infinity */
/*_# func Math.inceptX(x1, y1, x2, y2, y) _# return x at y of line x1, y1, x2, y2 _# note if y1 == y2 the return is (+ or -) Infinity */
/*_# group Cosine rule as applied to triangles with side lengths a, b, c and angles A, B, C oppisite the corrisponding side.
/*_# func Math.triCosC(a, b, c) _# return the cosine of the angle between sides a and b of triangle with side lengths a, b, c*/
/*_# func Math.triLenC(a, b, C) _# return the length of side c given the length of two sides a ,b and the angle C */
/*_# func Math.triLenC2(a, b, C) _# return the length squared of side c given the length of two sides a ,b and the angle C */
/*_# endGroup */


String.prototype.has = function(str){ // return true if string contains sub string str str may be a regexp
    if(str.test && typeof str.test === 'function'){
        return str.test(this);
    }
    if(typeof str !== "object"){
        return this.indexOf(str)===-1?false:true;
    }
    return false;
}

String.prototype.like = function(item, ignore = /^ *| *$/g) {
    return item.toString().toLowerCase().replace(ignore, "") === this.toLowerCase().replace(ignore, "");
}
String.prototype.anyLike = function(...items) {
    return items.some(item => this.like(item));
}
String.prototype.anyOf = function(...items) { 
    return items.some(item => item == this);  // Delibarate ==
}
String.prototype.has = function(item) {
    return this.includes(item);
}
String.prototype.hasLike = function(item) {
    return this.toLowerCase().trim().includes(item.toString().trim().toLowerCase());
}
String.prototype.hasAnyLike = function(...items) {
    const str = this.toLowerCase().trim();
    return items.some(item => str.includes(item.toString().trim().toLowerCase());
}


String.prototype.isTrueLike = function() {
    if (isNaN(this)) { return this.anyLike("yes","true","ok","accept","confirmed") }
    return this == true; // Delibarate ==
}
String.prototype.isFalseLike = function() {
    if (isNaN(this)) { return !this.anyLike("no","false","cancel","regect","denied") }
    return !(this == false); // Delibarate ==
}

  

Math.PI2 = Math.PI * 2;
Math.PI90D = Math.PI * 0.5;
Math.PI45D = Math.PI * 0.25;
Math.PI1D = Math.PI / 180;
Math.modR = (val, div) => ((val % div) + div) % div; 
Math.dotRad = (radA, radB) => Math.cos(radA) * Math.cos(radB) + Math.sin(radA) * Math.sin(radB);
Math.radBten = (radA, radB) => Math.acos(Math.cos(radA) * Math.sin(radB) - Math.sin(radA) * Math.cos(radB));
Math.radBtenVecs = (x1, y1, x2, y2) => Math.angleBetween(Math.atan2(y1, x1), Math.atan2(y2, x2));
Math.inceptY = (x1, y1, x2, y2, x) => ((y2 - y1) / (x2 - x1)) * (x - x1) + x1;
Math.inceptX = (x1, y1, x2, y2, y) => ((x2 - x1) / (y2 - y1)) * (y - y1) + y1;
Math.lineLen = (x1, y1, x2, y2) = x2 -= x1, y2 -= y1, (x2 * x2 + y2 * y2) ** 0.5;
Math.randI = range => Math.random() * range | 0;
Math.rand  = range => Math.random() * range;
Math.randRI = (min = 2, max = min + (min = 0)) => (Math.random() * (max - min) + min) | 0;
Math.randR  = (min = 1, max = min + (min = 0)) => Math.random() * (max - min) + min;
Math.triCosPh = (a, b, c) => (c * c - (a * a + b * b)) / (-2 * a * b);
Math.triLenC = (a, b, C) => (a * a + b * b - 2 * a * b * Math.cos(C)) ** 0.5;
Math.triLenC2 = (a, b, C) => a * a + b * b - 2 * a * b * Math.cos(C);


