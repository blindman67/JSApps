"use strict";
const pens = (()=>{
    const workPointA = utils.point;
    const workPointB = utils.point;
    const workPointC = utils.point;
    const mouseDownAt = utils.point;
    const colorRange  = utils.colorRange;
    const wColor1 = utils.rgba;
    const wColor2 = utils.rgba;
    const BRUSH_MAX_SIZE = 256;
    const wCanvas1 = utils.canvas(BRUSH_MAX_SIZE,BRUSH_MAX_SIZE);
    const wCanvas2 = utils.canvas(BRUSH_MAX_SIZE,BRUSH_MAX_SIZE);
    var useSpeed,sizeBlend,sizeBlendAmount,dontGetPixelColor,imgCopyFade, useDirection,sprayMin, sprayMax, sprayRange, firstDown,brushStep, curveStep, gradientAlpha,dirty,cancelStroke,randomColor, useShadow, filter, alias, mainColor, secondColor, mainDrawMode, secondDrawMode, nextDrawMode, brushMax, brushMin, brushRange, alpha, buttonUsed;
    sizeBlend = false;
    useSpeed = false;
    cancelStroke = false;
    gradientAlpha = false;
    dontGetPixelColor = false;
    dirty = false;
    function setPaintState(){
        if(curves.lineAlpha.name === "flat"){
            const pow = curves.lineAlpha.power;
            gradientAlpha = (pow <= 0 || pow >= 1) && ! curves.lineAlpha.inverted;
        }else {
            gradientAlpha = true;
        }
        sizeBlend = paint.sizeBlend;
        sizeBlendAmount = curves.curves.B.value;
        filter = paint.buildFilter();
        randomColor = paint.randColor;
        useShadow = paint.filterShadow;
        useSpeed = paint.useSpeed;
        brushMin = paint.sliders.brush.min;
        brushMax = paint.sliders.brush.max;
        brushRange = brushMax - brushMin;
        curveStep = paint.sliders.curveStep;
        brushStep = paint.sliders.brush.step;
        imgCopyFade = 1-paint.sliders.lengthFade / 60;
        sprayMin = paint.sliders.lengthFade;
        sprayMax = paint.sliders.widthFade;
        sprayRange = sprayMax - sprayMin;
        useDirection = paint.useDirection;
        alpha = colours.alpha;
        alias = ! paint.antiAlias;
        var dontCaptureColor = false;
        if(!dontGetPixelColor && paint.palletFrom === commands.paintColImage){
            dontCaptureColor = true;
            if(randomColor && !API.inFeedback){
                getRandomColorSet(colorRange,true);
            }else{
                getPixelColour(true);
            }
        }
        buttonUsed = (mouse.button & 1) ? 1 : (mouse.button & 4) ? 2 : 0;
        if(buttonUsed === 2){
            if(!dontGetPixelColor && paint.palletFrom === commands.paintColImage && wColor1.a > 0){ colours.setColor(wColor1.r,wColor1.g,wColor1.b,true) }
            secondColor = colours.mainColor.css;
            mainColor = colours.secondColor.css;
            colorRange.init(colours.secondColor,colours.mainColor);
            secondDrawMode  = colours.getDrawMode(colours.mainDrawMode);
            mainDrawMode = colours.getDrawMode(colours.secondDrawMode);
        }else{
            if( !dontGetPixelColor && paint.palletFrom === commands.paintColImage && wColor1.a > 0){ colours.setColor(wColor1.r,wColor1.g,wColor1.b) }
            else if (!dontCaptureColor && buttonUsed === 1 && colours.pending) {  colours.pendingColorUsed() }
            mainColor = colours.mainColor.css;
            secondColor = colours.secondColor.css;
            colorRange.init(colours.mainColor,colours.secondColor);
            mainDrawMode = colours.getDrawMode(colours.mainDrawMode);
            secondDrawMode = colours.getDrawMode(colours.secondDrawMode);
        }
    }
    function updatePaintState(){
    }
    function setupContext(spr, seperateStrokeAndFill = false){
        const ctx = spr.image.ctx;
        if(API.inFeedback){
            if(paint.drawType === commands.paintSpray && randomColor && paint.palletFrom === commands.paintColImage){
                ctx.globalAlpha = 0.5;
                ctx.strokeStyle = "red";
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.arc(spr.key.lx, spr.key.ly,curves.curves.C.value * 100, 0, Math.PI2);
                ctx.stroke();
            }
        }
        ctx.imageSmoothingQuality = "high";
        if(randomColor){
            if(buttonUsed === 2){
                mainColor = colours.colorRange[1 - curves.brushColor(Math.random()) * 255 | 0];
            }else{
                mainColor = colours.colorRange[curves.brushColor(Math.random()) * 255 | 0];
            }
        }
        if (seperateStrokeAndFill) {
            ctx.strokeStyle = mainColor;
            ctx.fillStyle = secondColor;
        } else {
            ctx.fillStyle = ctx.strokeStyle = mainColor;
        }
        ctx.globalAlpha = alpha;
        ctx.filter = filter;
        paint.shadow(ctx,true);
        ctx.globalCompositeOperation = mainDrawMode;
    }
    function pointFeedback(spr){
        if (!spr.image.restored) { spr.image.restore() }
        setupContext(spr)
        spr.image.ctx.fillRect(spr.key.lx | 0,spr.key.ly  | 0, 1, 1);
    }
    /* ================================================== RENDER and PAINTING functions Start here ========================================= */
    const aliasRects = [[0,1], [0,1],[-1,2],[-1.5,3],[-2,4],[-2.5,5],];
    const renderFunctions = (()=>{
        const API = {
            mark(ctx,x,y,size,col){
                ctx.strokeStyle = col;
                ctx.beginPath();
                ctx.moveTo(x-size,y)
                ctx.lineTo(x+size,y)
                ctx.moveTo(x,y - size)
                ctx.lineTo(x,y + size)
                ctx.stroke();
            },
            line(ctx,l,col){
                ctx.strokeStyle = col;
                ctx.beginPath();
                ctx.moveTo(l.p1.x,l.p1.y)
                ctx.lineTo(l.p2.x,l.p2.y)
                ctx.stroke();
            },
            interpolate : {
                desc : {
                    x : 0,
                    y : 0,
                    dx : 0,
                    dy : 0,
                    step : 0,
                    start : 0,
                    count : 0,
                    empty : true,
                    onSpriteSingle(spr){
                        const k = spr.key;
                        this.x = k._lx;
                        this.y = k._ly;
                        this.empty = false;
                        var dx = this.dx = k.lx - k._lx;
                        var dy = this.dy = k.ly - k._ly;
                        var len = Math.sqrt(dx * dx + dy * dy) + 0.00001;
                        this.count = 1 ;
                        this.start = 0;
                        if(paint.drawType === commands.paintSpray){
                            this.dx = 0;
                            this.dy = 0;
                            this.x += dx * 0.5;
                            this.y += dy * 0.5;
                            this.step = 1 / (brushStep/4);
                        }else{
                            if(brushStep > 0){
                                this.step = 0.5
                            }else{
                                this.step = 0.5;
                                if(curveStep > 0){
                                    this.step *= curveStep;
                                    this.count += this.step/2
                                    if (!firstDown){
                                        this.start += this.step;
                                    }
                                }
                            }
                        }
                        k._lx = k.lx;
                        k._ly = k.ly;
                    },
                    onSprite(spr){
                        var dx,dy;
                        var lx,ly
                        const k = spr.key;
                        this.x = k._lx;
                        this.y = k._ly;
                        this.empty = false;
                        lx = k.lx;
                        ly
const pens = (()=>{
    const workPointA = utils.point;
    const workPointB = utils.point;
    const workPointC = utils.point;
    const mouseDownAt = utils.point;
    const colorRange  = utils.colorRange;
    const wColor1 = utils.rgba;
    const wColor2 = utils.rgba;
    const BRUSH_MAX_SIZE = 256;
    const wCanvas1 = utils.canvas(BRUSH_MAX_SIZE,BRUSH_MAX_SIZE);
    const wCanvas2 = utils.canvas(BRUSH_MAX_SIZE,BRUSH_MAX_SIZE);
    var useSpeed,sizeBlend,sizeBlendAmount,dontGetPixelColor,imgCopyFade, useDirection,sprayMin, sprayMax, sprayRange, firstDown,brushStep, curveStep, gradientAlpha,dirty,cancelStroke,randomColor, useShadow, filter, alias, mainColor, secondColor, mainDrawMode, secondDrawMode, nextDrawMode, brushMax, brushMin, brushRange, alpha, buttonUsed;
    sizeBlend = false;
    useSpeed = false;
    cancelStroke = false;
    gradientAlpha = false;
    dontGetPixelColor = false;
    dirty = false;
    function setPaintState(){
        if(curves.lineAlpha.name === "flat"){
            const pow = curves.lineAlpha.power;
            gradientAlpha = (pow <= 0 || pow >= 1) && ! curves.lineAlpha.inverted;
        }else {
            gradientAlpha = true;
        }
        sizeBlend = paint.sizeBlend;
        sizeBlendAmount = curves.curves.B.value;
        filter = paint.buildFilter();
        randomColor = paint.randColor;
        useShadow = paint.filterShadow;
        useSpeed = paint.useSpeed;
        brushMin = paint.sliders.brush.min;
        brushMax = paint.sliders.brush.max;
        brushRange = brushMax - brushMin;
        curveStep = paint.sliders.curveStep;
        brushStep = paint.sliders.brush.step;
        imgCopyFade = 1-paint.sliders.lengthFade / 60;
        sprayMin = paint.sliders.lengthFade;
        sprayMax = paint.sliders.widthFade;
        sprayRange = sprayMax - sprayMin;
        useDirection = paint.useDirection;
        alpha = colours.alpha;
        alias = ! paint.antiAlias;
        var dontCaptureColor = false;
        if(!dontGetPixelColor && paint.palletFrom === commands.paintColImage){
            dontCaptureColor = true;
            if(randomColor && !API.inFeedback){
                getRandomColorSet(colorRange,true);
            }else{
                getPixelColour(true);
            }
        }
        buttonUsed = (mouse.button & 1) ? 1 : (mouse.button & 4) ? 2 : 0;
        if(buttonUsed === 2){
            if(!dontGetPixelColor && paint.palletFrom === commands.paintColImage && wColor1.a > 0){ colours.setColor(wColor1.r,wColor1.g,wColor1.b,true) }
            secondColor = colours.mainColor.css;
            mainColor = colours.secondColor.css;
            colorRange.init(colours.secondColor,colours.mainColor);
            secondDrawMode  = colours.getDrawMode(colours.mainDrawMode);
            mainDrawMode = colours.getDrawMode(colours.secondDrawMode);
        }else{
            if( !dontGetPixelColor && paint.palletFrom === commands.paintColImage && wColor1.a > 0){ colours.setColor(wColor1.r,wColor1.g,wColor1.b) }
            else if (!dontCaptureColor && buttonUsed === 1 && colours.pending) {  colours.pendingColorUsed() }
            mainColor = colours.mainColor.css;
            secondColor = colours.secondColor.css;
            colorRange.init(colours.mainColor,colours.secondColor);
            mainDrawMode = colours.getDrawMode(colours.mainDrawMode);
            secondDrawMode = colours.getDrawMode(colours.secondDrawMode);
        }
    }
    function updatePaintState(){
    }
    function setupContext(spr, seperateStrokeAndFill = false){
        const ctx = spr.image.ctx;
        if(API.inFeedback){
            if(paint.drawType === commands.paintSpray && randomColor && paint.palletFrom === commands.paintColImage){
                ctx.globalAlpha = 0.5;
                ctx.strokeStyle = "red";
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.arc(spr.key.lx, spr.key.ly,curves.curves.C.value * 100, 0, Math.PI2);
                ctx.stroke();
            }
        }
        ctx.imageSmoothingQuality = "high";
        if(randomColor){
            if(buttonUsed === 2){
                mainColor = colours.colorRange[1 - curves.brushColor(Math.random()) * 255 | 0];
            }else{
                mainColor = colours.colorRange[curves.brushColor(Math.random()) * 255 | 0];
            }
        }
        if (seperateStrokeAndFill) {
            ctx.strokeStyle = mainColor;
            ctx.fillStyle = secondColor;
        } else {
            ctx.fillStyle = ctx.strokeStyle = mainColor;
        }
        ctx.globalAlpha = alpha;
        ctx.filter = filter;
        paint.shadow(ctx,true);
        ctx.globalCompositeOperation = mainDrawMode;
    }
    function pointFeedback(spr){
        if (!spr.image.restored) { spr.image.restore() }
        setupContext(spr)
        spr.image.ctx.fillRect(spr.key.lx | 0,spr.key.ly  | 0, 1, 1);
    }
    /* ================================================== RENDER and PAINTING functions Start here ========================================= */
    const aliasRects = [[0,1],  // first is zero size
       [0,1],
       [-1,2],
       [-1.5,3],
       [-2,4],
       [-2.5,5],
    ];

    const getPixelColour = renderFunctions.pixel.getColor;
    const getRandomColorSet = renderFunctions.pixel.getRandomColorSet;
    /* ---------------------------------------------------------------------------------------------------------------------------------------
        Temp fix for image pixel and point rendering as its to much stuffing around to remember how to activate brush renderer
       ---------------------------------------------------------------------------------------------------------------------------------------*/
    renderFunctions.interpolate.image.point = renderFunctions.interpolate.image.brush;
    renderFunctions.interpolate.image.pixel = renderFunctions.interpolate.image.brush;
    /* ---------------------------------------------------------------------------------------------------------------------------------------
        POINT RENDERING
       ---------------------------------------------------------------------------------------------------------------------------------------*/
    const subStroke = renderFunctions.interpolate.desc;
    var pointType;
    var pointMethod;
    var pointStrokeCall;
    var pointUseBrush = false;
    var imageTop;
    function pointCreateBrush(){
        if(pointType === 1){
            imageTop = renderFunctions.pixel.getTopImage();
            mouseBrush1.resetDirection(0);
            renderFunctions.image.createMask(paint.useAlphaDist? curves.brushAlpha: curves.flat)
            renderFunctions.image.imageDir(imageTop.image.desc.mirror,imageTop.key.lx,imageTop.key.ly,0);
            renderFunctions.image.copyToOther();
        }else if(pointType === 0){
            renderFunctions.image.createMask(paint.useAlphaDist? curves.brushAlpha: curves.flat)
            renderFunctions.image.circleBrush(mainColor);
        }
        pointUseBrush = true;
    }
    function pointStrokeFeedback(spr){
        if (!spr.image.restored) { spr.image.restore() }
        subStroke.onSpriteSingle(spr);
        if(subStroke.empty) { return }
        setupContext(spr);
        pointStrokeCall(spr);
    }
    function pointStroke(spr){
        subStroke.onSprite(spr);
        if(subStroke.empty) { return }
        setupContext(spr);
        pointStrokeCall(spr);
    }
    function specialCreateBrush(feedback = false){
        mouseBrush1.resetDirection(0);
        specialBrushes.setupShape(specialBrushes.shape.names[paint.brissleMode]);
        if(useSpeed){
            if(paint.brissleMode === 2 || paint.brissleMode === 3){
                specialBrushes.setupStep("bendAndRotate");
            }else{
                specialBrushes.setupStep("bend");
            }
        }else{
            specialBrushes.setupStep("basic");
        }
        if(paint.colorBlend){
            specialBrushes.setupLoad("curveRange");
        }else if(randomColor) {
            specialBrushes.setupLoad("randomRange");
        }else if(paint.palletFrom === commands.paintColImage && !feedback){
            specialBrushes.setupLoad("empty");
        }else{
            specialBrushes.setupLoad("basic");
        }
        specialBrushes.currentShape(sprayMin, sprayMax, brushMin, brushRange, curves.spraySpread, curves.spraySize,mouseBrush1.direction);
        var dryDist = 10000000;
        if(sizeBlend || paint.colorBlend){
            dryDist = (sizeBlendAmount*32) ** 2;
        }
        specialBrushes.currentLoad(colorRange,curves.sprayColor,dryDist);
        if(paint.palletFrom === commands.paintColImage && !feedback){
            if(paint.colorBlend){
                renderFunctions.pixel.getHairColor(specialBrushes.hairs,sizeBlendAmount,true);
            }else{
                renderFunctions.pixel.getHairColor(specialBrushes.hairs,dryDist);
            }
        }
    }
    function specialStrokeFeedback(spr){
        if (!spr.image.restored) { spr.image.restore() }
        subStroke.onSpriteSingle(spr);
        if(subStroke.empty) { return }
        setupContext(spr);
        if(alias){
            renderFunctions.interpolate.hairs.brushPixel(spr);
        }else{
            renderFunctions.interpolate.hairs.brush(spr);
        }
    }
    function
    
    
    
    