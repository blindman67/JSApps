log This is a test
exit test exit
log this should not dislay
