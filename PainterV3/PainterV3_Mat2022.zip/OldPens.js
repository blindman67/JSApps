const strokes = (()=>{
    const points = [[0,0,0,0,0,0,NaN,0,NaN,0],[0,0,0,0,0,0,NaN,0,NaN,0],[0,0,0,0,0,0,NaN,0,NaN,0]];
    const pointsTemp = [[0,0,0,0,0,0,NaN,0,NaN,0],[0,0,0,0,0,0,NaN,0,NaN,0],[0,0,0,0,0,0,NaN,0,NaN,0]]; // as a cache to reduce calcs
    var count = 0;
    var strokeLen = 0;
    const X = 0;
    const Y = 1;
    const LEN = 2;
    const ULEN = 3;
    const NX = 4;
    const NY = 5;
    const BEZ = 6;
    var lastX = 0; // this is last point of mouse. Smooth will catch up to this point when cleaned
    var lastY = 0;
    function simplify(tolerance) {
        var simplify = function(start, end) {
            var maxDist, index, i, xx , yy, dx, dy, ddx, ddy, p1, p2, p, t, dist, dist1,pxx,pyy;
            p1 = pp[start];
            p2 = pp[end];
            xx = p1[0];
            yy = p1[1];
            ddx = p2[0] - xx;
            ddy = p2[1] - yy;
            dist1 = (ddx * ddx + ddy * ddy);
            maxDist = tolerance;
            for (var i = start + 1; i < end; i++) {
                p = pp[i];
                if (ddx !== 0 || ddy !== 0) {
                    dx = p[0] - xx;
                    dy = p[1] - yy;
                    t = (dx * ddx + dy * ddy) / dist1;
                    if (t > 1) {
                        dx = p[0] - p2[0];
                        dy = p[1] - p2[1];
                    } else if (t > 0) {
                        dx -= ddx * t;
                        dy -= ddy * t;
                    }
                } else {
                    dx = p[0] - xx;
                    dy = p[1] - yy;
                }
                dist = dx * dx + dy * dy
                if (dist > maxDist) {
                    index = i;
                    maxDist = dist;
                }
            }
            if (maxDist > tolerance) {
                if (index - start > 1) { simplify(start, index) }
                tp[newCount][BEZ] = NaN;
                tp[newCount][BEZ+2] = NaN;
                tp[newCount][0] = pp[index][0];
                tp[newCount++][1] = pp[index][1];
                if (end - index > 1) { simplify(index, end) }
            }
        }
        const tp = points;
        const pp = pointsTemp;
        var newCount = 0
        var end = count - 1;
        tp[newCount][BEZ] = NaN;
        tp[newCount][BEZ+2] = NaN;
        tp[newCount][0] = pp[0][0];
        tp[newCount++][1] = pp[0][1];
        simplify(0, end);
        tp[newCount][BEZ] = NaN;
        tp[newCount][BEZ+2] = NaN;
        tp[newCount][0] = pp[end][0];
        tp[newCount++][1] = pp[end][1];
        count = newCount;
    }
    var dist1,dist2,nx1,ny1,nx2,ny2;
    function dotAngle(x, y, xx, yy) {
        dist1 = Math.sqrt(x * x + y * y);
        nx1 = x / dist1;
        ny1 = y / dist1;
        dist2  = Math.sqrt(xx * xx + yy * yy);
        nx2 = xx / dist2;
        ny2 = yy / dist2;
        return Math.acos(nx1 * nx2 + ny1 * ny2);
    }
    function smoothShape (cornerThres,amount,balance,match,dontClose){  // adds bezier control points at points if lines have angle less than thres
        // points: list of points
        // cornerThres: when to smooth corners and represents the angle between to lines.
        //     When the angle is smaller than the cornerThres then smooth.
        // amount: the distance the bezier control points move out from the end point.
        //     It represents the preportion of the line length.
        // match: if true then the control points will be balanced.
        //     The distance away from the end point is amount of the shortest line
        // balance: 0-1 Only smooth lines with balanced line lengths. 0 lines must have
        //     equal distance. 0.5 one line must be at least half as long. 1 don care what length
        var dir1,dir2,p1,p2,p3,x,y,endP,len,tau,angle,i,newPoints,aLen,closed,bal,cont1;
        if (amount < 0.001) { return points }
        if (amount > 0.5) { amount = 0.5 }
        aLen = count;
        p1 = points[0];
        p2 = points[count-1];
        if(aLen <= 2){
           p1[BEZ] = p1[0];
           p1[BEZ+1] = p1[1];
           p1[BEZ+2] = p2[0];
           p1[BEZ+3] = p2[1];
            return
        }
        balance = 1-balance;
        p1 = points[0];
        p2 = points[1];
        endP =points[aLen-1];
        i = 1;  // start from second poitn if line not closed
        closed = false;
        if(dontClose !== true){
        }else{
           p1[BEZ] = p1[0];
           p1[BEZ+1] = p1[1];
           p1[BEZ+2] = p2[0];
           p1[BEZ+3] = p2[1];
            i = 0;
        }
        for(; i < aLen-1; i++){
            p2 = points[i];
            p3 = points[i + 1];
            angle = Math.abs(dotAngle(p2[0] - p1[0], p2[1] - p1[1], p3[0] - p2[0], p3[1] - p2[1]));
            if(dist1 !== 0){
                if(dist2 === 0){
                    bal =-1;
                }else{
                    bal = dist1 > dist2 ? dist2 / dist1 : dist1 / dist2;
                }
                if( angle < cornerThres*3.14 && bal >= balance){
                      if(match){
                          dist1 = Math.min(dist1,dist2);
                          dist2 = dist1;
                      }
                      x = (nx1 + nx2) / 2;
                      y = (ny1 + ny2) / 2;
                      len = Math.sqrt(x * x + y * y);  // normalise the tangent
                      if(len === 0){
                          p2[BEZ] = NaN;
                      }else{
                          x /= len;
                          y /= len;
                          p2[NX] = x;
                          p2[NY] = y;
                          if(i > 0){
                              p1[BEZ + 2] = p2[0] - x * dist1 * amount;
                              p1[BEZ + 3] = p2[1] - y * dist1 * amount;
                          }
                          p2[BEZ + 0] = p2[0] + x * dist2 * amount;
                          p2[BEZ + 1] = p2[1] + y * dist2 * amount;
                      }
                }else{
                    p2[NX] = nx2;
                    p2[NY] = ny2;
                    p1[BEZ + 2] = p2[0];
                    p1[BEZ + 3] = p2[1];
                    p2[BEZ + 0] = p2[0];
                    p2[BEZ + 1] = p2[1];
                }
            }
            p1 = p2;
        }
        if(closed){
        }else{
            p2[BEZ + 2] = p3[0];
            p2[BEZ + 3] = p3[1];
            //newPoints.push([points[points.length-1][0],points[points.length-1][1]]);
        }
        //return newPoints;
    }
    const API = {
        each(cb) {
            var i;
            for(i = 0; i < count; i ++){
                cb(points[i],pointsTemp[i],i);
            }
        },
        eachR(cb) {
            var i,ii;
            for(i = 0; i < count; i ++){
                ii = count - i - 1;
                cb(points[ii],pointsTemp[ii],ii);
            }
        },

        add(x,y){
            API.addIt(x,y);

        },
        addIt(x,y){
            lastX = x;
            lastY = y;
            const a = 0.02;//Math.max(0.02,paint.sliders.lengthFade / 60);
            if(points[count] === undefined){
                points[count] = [0,0,0,0,0,0,0,0,0,0];
                pointsTemp[count] = [0,0,0,0,0,0,0,0,0,0];
            }

            pointsTemp[count][X] = points[count][X] = x;
            pointsTemp[count][Y] = points[count][Y] = y;
            points[count][LEN] = 0;
            points[count][ULEN] = 0;
            points[count][NX] = 0;
            points[count][NY] = 0;
            points[count][BEZ] = NaN;
            points[count][BEZ+2] = NaN;
            pointsTemp[count][BEZ]  = NaN;
            pointsTemp[count][BEZ+2]  = NaN;
            count ++;
        },
        reset(){
            count = 0;
        },
        clean(dontCatchUp){
            var tail = 0
            var i;
            var lx,ly;
            var dist = 0;

            const minLen = paint.sliders.lengthFade;
            for(i = 0; i < count; i ++){
                var t = points[tail];
                var p = points[i]
                if(p[X] !== lx || p[Y] !== ly){
                    if(lx !== undefined){
                        var nx = p[X] - lx;
                        var ny = p[Y] - ly;
                        const d = ((nx ** 2) + (ny ** 2)) ** 0.5;
                        if(d >= minLen || i === count-1){
                            dist += d;
                            points[tail-1][NX] = nx / d;
                            points[tail-1][NY] = ny / d;
                            t[LEN] = dist;
                            lx = t[X] = p[X];
                            ly = t[Y] = p[Y];
                            tail ++;
                        }
                    }else{
                        t[LEN] = dist;
                        lx = t[X] = p[X];
                        ly = t[Y] = p[Y];
                        tail ++;
                    }
                }
            }
            if(tail < 2){
                points[1][NX] = 1;
                points[1][NY] = 0;
                points[1][X] = points[0][X];
                points[1][Y] = points[0][Y];
                points[1][LEN] = 1;
                points[1][ULEN] = 1;
                tail = 2;
                dist = 1;
            }else{
                points[tail - 1][NX] = points[tail - 2][NX];
                points[tail - 1][NY] = points[tail - 2][NY];
            }
            strokeLen = dist;
            count = tail;
            for(i = 0; i < count; i ++){
                points[i][ULEN] = points[i][LEN] / strokeLen;
                pointsTemp[i][X] = points[i][X]
                pointsTemp[i][Y] = points[i][Y]
            }
        }
    }
    return API;
})();
const imageMover = (()=>{
    const can1 = document.createElement("canvas");
    const can2 = document.createElement("canvas");
    can1.width = can2.width = 256;
    can1.height = can2.height = 256;
    const c1 = can1.getContext("2d");
    const c2 = can2.getContext("2d");
    var grad;
    var offsetGrad = false;
    var circleSize;
    var path;
    const smallAliasCirclesFill = [[],
        [0,],
        [1,0,],
        [2,2,1,],
        [3,3,2,1,],
        [4,4,3,2,1,],
        [5,5,4,4,3,1,],
        [6,6,5,5,4,3,1,],
    ];
    const seededRand = [];
    var seedCount = 0;
    var lastSize = -1;
    var cc;
    const API = {
        can1,can2,c1,c2,
        reseedRandom(){ seedCount = 0 ;},
        createBrush(size,sizeB,col){
            this.createStyle(size,sizeB);
            c1.setTransform(1,0,0,1,0,0);
            c1.fillStyle = col;
            c1.fillRect(0,0,256,256);
            c1.globalCompositeOperation = "destination-in";
            var scale = size / 256;
            if(offsetGrad){
                c1.setTransform(scale,0,0,scale,128,128);
                c1.drawImage(can2,-128,-128);
            }else{
                c1.fillStyle = grad;
                if(paint.useDirection){
                     var ssx = paint.sliders.brush.max / 60;
                    var ssy = 1 - ssx;
                    if(ssx > ssy){
                        ssx = 1;
                    }else{
                        ssy = 1 ;
                    }
                    c1.setTransform(scale * ssx,0,0,scale * ssy,128,128);
                }else{
                    c1.setTransform(scale,0,0,scale,128,128);
                }
                //c1.setTransform(scale,0,0,scale,128,128);
                c1.beginPath();
                c1.arc(0,0,128,0,Math.PI * 2);
                c1.fill();
            }
            c1.globalCompositeOperation = "source-over";
            circleSize = 0;
            if(cc === undefined){ cc = view.context }            
                                cc.save();
                    cc.globalAlpha = 1;
                    cc.setTransform(1,0,0,1,0,256);
                    cc.drawImage(can1,0,0);
                    cc.restore();
            return can1;
        },
        resizeBrush(size,sizeB,col){
            c1.setTransform(1,0,0,1,0,0);
            c1.fillStyle = col;
            c1.fillRect(0,0,256,256);
            c1.globalCompositeOperation = "destination-in";
            var scale = size / 256;
            //c1.setTransform(scale,0,0,scale,128,128);
            if(offsetGrad){
                c1.setTransform(scale,0,0,scale,128,128);
                c1.drawImage(can2,-128,-128);
            }else{
                c1.fillStyle = grad;
                if(paint.useDirection){
                     var ssx = paint.sliders.brush.max / 60;
                    var ssy = 1 - ssx;
                    if(ssx > ssy){
                        ssx = 1;
                    }else{
                        ssy = 1 ;
                    }
                    c1.setTransform(scale * ssx,0,0,scale * ssy,128,128);
                }else{
                    c1.setTransform(scale,0,0,scale,128,128);
                }
                c1.beginPath();
                c1.arc(0,0,128,0,Math.PI * 2);
                c1.fill();
            }
            c1.globalCompositeOperation = "source-over";
            circleSize = 0;
            return can1;
        },
        createStyle(size,sizeB){
            if(curves.A.isRandom){
                if(cc === undefined){ cc = view.context }
                var sc = 0;
                c2.clearRect(0,0,256,256);
                c2.fillStyle = "black";
                if(paint.useDirection){
                    var mx = Math.max(paint.sliders.brush.max,paint.sliders.brush.min)
                    const r = 1 * (1 / (mx / 128));
                    var ssx = paint.sliders.brush.max / mx;
                    var ssy = paint.sliders.brush.min / mx;
                    sizeB = Math.max(paint.sliders.curveStep* 2,1);
                    if(lastSize !== sizeB) { seedCount = 0 }
                    lastSize = sizeB;
                    if(seedCount === 0){
                        for(var i = 0; i < sizeB + 1; i ++){
                            const ii = seededRand[sc++] = Math.random();
                            const a = (seededRand[sc++] = Math.random()) * Math.PI * 2;
                            const b = curves.A(ii) * 126 - r;
                            c2.globalAlpha = curves.A(1-ii);
                            c2.beginPath();
                            c2.arc(128 + Math.cos(a) * b * ssx, 128 + Math.sin(a) * b * ssy,r,0,Math.PI * 2);
                            c2.fill();
                        }
                        seedCount = sc;
                    }else{
                        //seedCount = seededRand.length;
                        for(var i = 0; i < sizeB + 1; i ++){
                            const ii = seededRand[(sc ++) % seedCount];
                            seededRand[sc % seedCount] += mouseBrush.directionChange*(ii-0.5) ;
                            const a = seededRand[(sc ++) % seedCount]* Math.PI * 2;
                            const b = curves.A(ii) * 126 - r;
                            c2.globalAlpha = curves.A(1-ii);
                            c2.beginPath();
                            c2.arc(128 + Math.cos(a) * b * ssx, 128 + Math.sin(a) * b * ssy,r,0,Math.PI * 2);
                            c2.fill();
                        }
                    //grad = c1.createPattern(can2,"no-repeat");
                    }
                    offsetGrad = true;
                    cc.save();
                    cc.globalAlpha = 1;
                    cc.setTransform(1,0,0,1,0,0);
                    cc.drawImage(can2,0,0);
                    cc.restore();
                }else{
                    sizeB = Math.max(paint.sliders.curveStep* 2,1)
                    if(lastSize !== sizeB) { seedCount = 0 }
                    lastSize = sizeB;                    
                    if(seedCount === 0){
                        const r = 1 * (1 / (size / 128));
                        for(var i = 0; i < sizeB + 1; i ++){
                            const ii = seededRand[sc++] = Math.random();
                            const a = (seededRand[sc++] = Math.random()) * Math.PI * 2;
                            const b = curves.A(ii) * 126 - r;
                            c2.globalAlpha = curves.A(1-ii);
                            c2.beginPath();
                            c2.arc(128 + Math.cos(a) * b, 128 + Math.sin(a) * b,r,0,Math.PI * 2);
                            c2.fill();
                        }
                        seedCount = sc;
                    }else{
                        const r = 1 * (1 / (size / 128));
                        for(var i = 0; i < sizeB + 1; i ++){
                            const ii = seededRand[(sc ++) % seedCount];
                            const a = seededRand[(sc ++) % seedCount] * Math.PI * 2;
                            const b = curves.A(ii) * 126 - r;
                            c2.globalAlpha = curves.A(1-ii);
                            c2.beginPath();
                            c2.arc(128 + Math.cos(a) * b, 128 + Math.sin(a) * b,r,0,Math.PI * 2);
                            c2.fill();
                        }
                    }
                    //grad = c1.createPattern(can2,"no-repeat");
                    offsetGrad = true;
                }
            }else{
                grad = c1.createRadialGradient(0,0,0,0,0,128);
                for(var i = 0; i < 32; i ++){
                    var pos = i / 31;
                    pos = pos < 0 ? 0 : pos > 1 ? 1 : pos;
                    var a = curves.A(pos);
                    grad.addColorStop(1-pos,"rgba(0,0,0,"+a+")");
                }
                offsetGrad = false;
            }
        },
        sample(x,y,canvas,size,sizeB, dir = mouseBrush.direction){
            this.createStyle(size,sizeB);
            c1.setTransform(1,0,0,1,0,0);
            c1.clearRect(0,0,256,256);
            if(paint.useDirection){
                c1.setTransform(1,0,0,1,128, 128);
                c1.rotate(-dir);
                c1.drawImage(canvas,-x,-y);
            } else {
                c1.setTransform(1,0,0,1,-x + 128, - y + 128);
                c1.drawImage(canvas,0,0);
            }
            c1.globalCompositeOperation = "destination-in";
            var scale = Math.max(size,sizeB) / 128;
            c1.setTransform(scale,0,0,scale,128,128);
            if(offsetGrad){
                c1.drawImage(can2,-128,-128);
            }else{
                c1.fillStyle = grad;
                c1.beginPath();
                c1.arc(0,0,128,0,Math.PI * 2);
                c1.fill();
            }
            c1.globalCompositeOperation = "source-over";
            circleSize = 0;
            return can1;
        },
        sampleArea(x,y,canvas){
            //this.createStyle();
            c1.setTransform(1,0,0,1,0,0);
            c1.clearRect(0,0,256,256);
            if(paint.useDirection){
                c1.setTransform(1,0,0,1,128, 128);
                c1.rotate(-mouseBrush.directionAccum);
                c1.drawImage(canvas,-x,-y);
            } else {
                c1.setTransform(1,0,0,1,-x + 128, - y + 128);
                c1.drawImage(canvas,0,0);
            }
            circleSize = 0;
            return can1;
        },
        aliasCircle(size,col){
    
            const even = (size + 1 | 0) % 2

            
            const sizeR = size / 2 + even / 2 + (size % 2)| 0;

            if(size !== circleSize){
                path = new Path2D();
                circleSize = size;
                //c1.fillStyle = col;
                var x = sizeR-1;
                var y = 0;
                var dx = 1;
                var dy = 1;
                var err = dx - (sizeR << 1);
                var x0 = 0;
                var y0 = 0;
                var x1 = x0 + even;
                var y1 = y0 + even;

                    if(sizeR < smallAliasCirclesFill.length){
                        const sc = smallAliasCirclesFill[sizeR];
                        const len = sc.length;
                        while(y < len){
                            x = sc[y];
                            if(even || (y !== 0 && !even)){
                                path.rect(x0 - x, y0 - y, x * 2 + 1 + even, 1);
                            }
                            path.rect(x0 - x, y1 + y, x * 2 + 1 + even, 1);
                            y ++
                        }
                    }else{
                        var lx = x,ly = y;
                        while (x >= y) {
                            path.rect(x0 - x, y1 + y, x * 2 + 2, 1);
                            path.rect(x0 - x, y0 - y, x * 2 + 2, 1);
                            if(x !== lx){
                                path.rect(x0 - ly, y0 - lx, ly * 2 + 2, 1);
                                path.rect(x0 - ly, y1 + lx, ly * 2 + 2, 1);
                            }
                            lx = x;
                            ly = y;
                            y++;
                            err += dy;
                            dy += 2;
                            if (err > 0) {
                                x--;
                                dx += 2;
                                err += (-sizeR << 1) + dx;
                            }
                        }
                        if(x !== lx){
                            path.rect(x0 - ly, y0 - lx, ly * 2 + 1, 1);
                            path.rect(x0 - ly, y1 + lx, ly * 2 + 1, 1);
                        }
                    }

            }
            return path;
        }
    };
    return API;
})();
const mouseBrush = (()=>{
    const p = {x : 0, y : 1};
    const points = [{...p},{...p},{...p},{...p},{...p},{...p},{...p},{...p},{...p},{...p},{...p}];
    const maxLen = points.length;
    const back = maxLen - 1;
    var pos = 0
    var sc = 0;
    const hairs = [];
    const maxHairs = 64;
    var hairBrushExpoSize = false
    var hairCount = 0;
    var hair = { 
        x : 0,
        y : 0,
    }
    for(var i = 0; i < maxHairs; i ++){
        hairs.push({x : 0, y : 0,lx:0,ly:0,w:0,h:0, dir : 0, size : 0, dx : 0, dy : 0, col : "#FFF", ang : 0, dist : 0,d1:0,next : null});
    }
    const lowHairPos = [
        [0,0],
        [0,1,0.5,1],
        [0,1,1/3,1,2/3,1],
        [0,1,1/4,1,2/4,1,3/4,1],
    ];
    function createHairs(){
        var i = 0;
        var cc;
        hairCount = paint.sliders.curveStep+1;
        var mainC = colours.mainColor.css;
        var mainC = colours.mainColor.css;
        var r,g,b,rr,gg,bb;
        r = colours.mainColor.r;
        g = colours.mainColor.g;
        b = colours.mainColor.b;
        rr = colours.secondColor.r;
        gg = colours.secondColor.g;
        bb = colours.secondColor.b;
        var mainSC = colours.secondColor.css;
        for(var i = 0; i < hairCount; i++){
            const hair = hairs[i];
            if(hairCount < lowHairPos.length){
                var a = lowHairPos[hairCount][i*2];
                var dis = curves.spraySpread(lowHairPos[hairCount][i*2+1]) * paint.sliders.widthFade;
                var d = dis * paint.sliders.widthFade;
               hair.next = hairs[i%hairCount];
            }else{
                var a = Math.random();
                var dis = curves.spraySpread(Math.random())
                var d = dis * paint.sliders.widthFade;
                hair.next = hairs[Math.random()*hairCount|0];
            }
            hair.ang = a * Math.PI * 2;
            hair.dist = hairBrushExpoSize ? d ** 1.5 : d;
            hair.d2 = a/2+0.5;
            hair.d1 = curves.B(1 - d / paint.sliders.widthFade);
            hair.lx1 = hair.lx = hair.x = Math.cos(hair.ang) * hair.dist;
            hair.ly1 = hair.ly = hair.y = Math.sin(hair.ang) * hair.dist;
            hair.a =hair.ang;
            hair.af = 0;
            hair.as = Math.random() * 0.1 + 0.9;
            hair.dx = 0;
            hair.dy = 0;
            var ssi = curves.spraySize(dis);
            hair.size = (ssi *(paint.sliders.brush.max - paint.sliders.brush.min) + paint.sliders.brush.min)/8;
            if(paint.colorBlend){
                hair.r = -1;
                hair.g = -1;
                hair.b = -1;
                hair.al = 0;
                hair.blendA = curves.lineAlpha(ssi);
                hair.blend = curves.lineAlpha(ssi);
            }else{
                 hair.r = -1;
                hair.g = -1;
                hair.b = -1;                 
                hair.al = 0;                 
                hair.rr = rr;
                hair.gg = gg;
                hair.bb = bb;
                hair.aa = 0;
                hair.blendA = curves.lineAlpha(ssi);
                hair.blend = curves.lineAlpha(ssi);
            }                
            if(!paint.colorBlend){
                if(paint.randColor){
                    if(API.shadeMode){
                        hair.col = colours.colorRange[cc = (curves.sprayColor(Math.random()) * 128 | 0)];
                    }else{
                        hair.col = colours.colorRange[curves.sprayColor(Math.random()) * 255 | 0];
                    }
                }else if(API.shadeMode){
                    hair.col = mainC;
                }
            }
            if(API.shadeMode){
                i += 1;
                if(i >= hairCount) {break}                
                const hair1 = hairs[i];
                hair1.ang = hair.ang + 0.1;
                hair1.dist = hair.dist + 2;
                hair1.d2 = hair1.dist;
                hair1.d1 = hair.d1
                hair1.lx1 = hair1.lx = hair1.x = Math.cos(hair1.ang) * hair1.dist ;
                hair1.ly1 = hair1.ly = hair1.y = Math.sin(hair1.ang) * hair1.dist ;
                hair1.a =hair1.ang;
                hair1.af = 0;
                hair1.as = Math.random() * 0.1 + 0.9;
                hair1.dx = 0;
                hair1.dy = 0;
                hair1.size = hair.size;

                if(paint.colorBlend){
                    hair1.r = -1;
                    hair1.g = -1;
                    hair1.b = -1;
                    hair1.al = 0;
                    hair1.blendA = curves.lineAlpha(ssi);
                    hair1.blend = curves.lineAlpha(ssi);
                }else{
                     hair.r = -1;
                    hair.g = -1;
                    hair.b = -1;                 
                    hair.al = 0;                 
                    hair.rr = rr;
                    hair.gg = gg;
                    hair.bb = bb;
                    hair.aa = 0;                  
                    hair1.blendA = curves.lineAlpha(ssi);
                    hair1.blend = curves.lineAlpha(ssi);
                } 
                if(!paint.colorBlend){
                    if(paint.randColor){
                        hair1.col = colours.colorRange[cc + 128];
                    }else{
                        hair1.col = mainSC
                    }
                }
            }
        }
        hair.len = 0;
        hair.step = 0;
        hair.unit = 0;
        API.resetDirection();
    
    }
    var lastMouse = 0;
    const dirChange = Smoother(0.6,0.3);
    const dirChangeA = Smoother(0.4,0.3);
    const speed = Smoother(0.6,0.3);
    const posA = Smoother2D(0.6,0.3);
    const posB = Smoother2D(0.6,0.3);
    const posC = Smoother2D(0.6,0.3);
    var x1,y1,x2,y2,x3,y3,l1,l2,l3,c1,c2,d1,d2;  // l for length, c for cross product, d for dot product
    var dirC1,dirC2,dir,s;
    const API = {
        extra : null,
        setExtraBrush(name){
            if(API[name]){
                API.extra = API[name];
            }
        },
        drawModes : {
            lines : 1,
            lines1 : 6,
            lineHighlight : 7,
            shaded : 9,
            points : 2,
            circles : 3,
            circles1 : 4,
            longContact : 5,
        },
        drawMode : 1,
        shadeMode : 0,
        setExtraDrawMode(name){
            API.forceReset = true;
            if(name === "shaded"){
                API.shadeMode = 1;
                return;
            }else{
                API.shadeMode = 0;
            }
            API.drawMode = API.drawModes[name] ? API.drawModes[name] : API.drawMode;
        },
        forceReset : true,
        brissleMad(x,y,reset,createOnly){
            hairBrushExpoSize = true;
            if(paint.sliders.curveStep+1 !== hairCount || reset || API.forceReset){
                API.forceReset = false;
                createHairs();
                hair.x = x;
                hair.y = y;
                hairs.hairCount = hairCount;    
                //if(createOnly) { return  hairs }
            }
            const drag = (paint.sliders.brush.step / 61)**0.7;
            var unit = hairs.unit;
            var dx = x - hair.x;
            var dy = y - hair.y;
            var len = Math.sqrt(dx * dx + dy * dy);
            if(len > 0){
                dx /= len;
                dy /= len;
            }
            var dl = len - hair.len;
            hair.x = x;
            hair.y = y;           
            hair.lx = x;
            hair.ly = y;
            var ol = hair.len;
            hair.len =len;
            var i = 0;
            var dd =  API.speedChange * unit;
            dd = (2 / (1 + Math.pow(1.5,-(ol + dl * unit))))-1;
            var dd1 = curves.curves.C.value 
            dd1 *= (2 / (1 + Math.pow(1.5,-(API.speed + API.speedChange * unit)*1)))-1;
            var dd2 = 1-dd1;
            var ddA1 = dd1 ** 0.5;
            var ddA2 = 1-ddA1;
            for(const h of hairs){
               h.x -= dx / 2;
               h.y -= dy / 2;
                var aa = (API.directionAccum + API.directionChange * unit) * h.d1;
                var a = h.a;
                var cs = Math.cos(a);
                var ss = Math.sin(a);
                var dp = dx * ss - dy * cs;
                var ssc = curves.brushAlpha(dp) * Math.sign(dp)
                dp = Math.asin(ssc);
                h.af += dp;// *dd;
                h.af *= h.as;
                h.a += (aa+h.af) *(1-h.d1)*0.6; //a + h.af;
                 var ddC = h.ang - h.a;
                h.a += (h.ang - h.a) * h.d1
                var dis = 1-(Math.abs(h.ang - h.a) / Math.PI)
                dis = dis < 0 ? 0 : dis > 1 ? 1 : dis
                h.dx += (Math.cos(h.a) * (h.dist*dis) - h.x) ;
                h.dy += (Math.sin(h.a) * (h.dist*dis) - h.y) ;
                h.dx *= drag;
                h.dy *= drag;
                h.x +=  h.dx;
                h.y +=  h.dy;
                h.ly1 = h.ly1 *ddA1 + h.ly * ddA2;
                h.lx1 = h.lx1 * ddA1 + h.lx * ddA2;
                h.lx = h.lx * dd1 + h.x * dd2;
                h.ly = h.ly *dd1 + h.y * dd2;   
               

                if(!paint.colorBlend && !paint.randColor){
                    if(h.r === -1){
                        h.col = "rgba(0,0,0,0)";
                    }else{
                        h.blend += ((ddC * h.blendA  * dd2) / 8);
                        var be  = ((h.blend  % 1)+1)%1;
                        if(h.blend > 1 || h.blend < -1){
                             h.col = "rgba(" + (h.rr | 0) + "," + 
                            (h.gg | 0) + ","+ 
                            (h.bb | 0) + ","+ 
                            ((h.aa )/255 ) +")";  

  
                        } else {
                            h.col = "rgba(" + (be * (h.r - h.rr) + h.rr | 0) + "," + 
                            (be * (h.g - h.gg) + h.gg | 0) + ","+ 
                            (be * (h.b - h.bb) + h.bb | 0) + ","+ 
                            ((be * (h.al - h.aa) + h.aa )/255 ) +")";
                        }
                    }
                }else{
                    h.blend =h.blendA * dd2;   
                }                    
                              
                i += 1;
                if(i >= hairCount) {break}
            }
            hairs.hairCount = hairCount;    
            return  hairs;  
        },
        brisslePlainA(x,y,reset,createOnly){
            return API.brisslePlain(x,y,reset,createOnly,1);
        },
        brisslePlain(x,y,reset,createOnly,ext = 0){
            hairBrushExpoSize = false;
            if(paint.sliders.curveStep+1 !== hairCount || reset || API.forceReset){
                API.forceReset = false;
                createHairs();
                hair.x = x;
                hair.y = y;
                hairs.hairCount = hairCount;    
                //if(createOnly) { return  hairs }
            }
            var drag = (paint.sliders.brush.step / 61)**0.7;
            var unit = hairs.unit;
            var dx = x - hair.x;
            var dy = y - hair.y;
            var len = Math.sqrt(dx * dx + dy * dy);
            if(len > 0){
                dx /= len;
                dy /= len;
            }

            hair.x = x;
            hair.y = y;

            hair.len =len;
            var i = 0;
            var dd1 = curves.curves.A.value 
            var ddA = curves.curves.B.value 
            dd1 *= (2 / (1 + Math.pow(1.5,-(API.speed + API.speedChange * unit)*1)))-1;
            var dd2 = 1-dd1;            
            ddA *= (2 / (1 + Math.pow(1.2,-(API.speed + API.speedChange * unit)*1)))-1;
            var dd2A = 1-ddA;
            var gg = hairs[0];
            for(const h of hairs){
                h.x -= dx * dd1;
                h.y -= dy * dd1;

         
                
                h.af = (h.af + (Math.asin(dx * Math.sin(h.a) - dy * Math.cos(h.a)) * ddA * (h.d1))) * h.as; 
                if(ext === 1){
                    h.af += curves.brushAlpha(Math.sin(h.a)*0.5+0.5) * 2 - 1; 
                    
                }
                h.a += h.af *(1-h.d1)*0.6;
                var ddC = h.ang - h.a;
                h.a += (h.ang - h.a) * h.d1* ddA;
                if(ext === 1){
                    var dis = curves.brushColor((Math.abs(h.ang - h.a) / Math.PI2))*h.dist
                    h.dx += (Math.cos(h.a+dis) * (dis) - gg.x) ;
                    h.dy += (Math.sin(h.a+dis) * (dis) - gg.y) ;
                }
                    h.dx += (Math.cos(h.a) * (h.dist) - h.x) ;
                    h.dy += (Math.sin(h.a) * (h.dist) - h.y) ;                    
                
                h.x += (h.dx *= drag);
                h.y += (h.dy *= drag);
                h.lx1 = h.lx1 * dd1 + h.x * dd2;
                h.ly1 = h.ly1 * dd1 + h.y * dd2;   
                h.lx = (h.lx1 + h.x) / 2;
                h.ly = (h.ly1 + h.y) / 2;
                if(!paint.colorBlend && !paint.randColor){
                    if(h.r === -1){
                        h.col = "rgba(0,0,0,0)";
                    }else{
                        h.blend += ((ddC * h.blendA  * dd2) / 8);
                        var be  = ((h.blend  % 1)+1)%1;
                        if(h.blend > 1 || h.blend < -1){
                             h.col = "rgba(" + (h.rr | 0) + "," + 
                            (h.gg | 0) + ","+ 
                            (h.bb | 0) + ","+ 
                            ((h.aa )/255 ) +")";  

  
                        } else {
                            h.col = "rgba(" + (be * (h.r - h.rr) + h.rr | 0) + "," + 
                            (be * (h.g - h.gg) + h.gg | 0) + ","+ 
                            (be * (h.b - h.bb) + h.bb | 0) + ","+ 
                            ((be * (h.al - h.aa) + h.aa )/255 ) +")";
                        }
                    }
                }else{
                    h.blend =h.blendA * dd2;   
                }                    
              
                gg = h;
                i += 1;
                if(i >= hairCount) {break}
            }
            hairs.hairCount = hairCount;    
            return  hairs;  
        },
        brissleDirection(x,y,reset,createOnly){
            hairBrushExpoSize = false;
            if(paint.sliders.curveStep+1 !== hairCount || reset || API.forceReset){
                API.forceReset = false;
                createHairs();
                hair.x = x;
                hair.y = y;
                hairs.hairCount = hairCount;    
                //if(createOnly) { return  hairs }
            }
            var drag = (paint.sliders.brush.step / 61)**0.7;
            var unit = hairs.unit;
            var dx = x - hair.x;
            var dy = y - hair.y;
            var len = Math.sqrt(dx * dx + dy * dy);
            if(len > 0){
                dx /= len;
                dy /= len;
            }
            var dl = len - hair.len;
            hair.x = x;
            hair.y = y;
            var ol =hair.len;
            hair.len =len;
            var i = 0;
            var dd =  API.speedChange * unit;
            dd = (2 / (1 + Math.pow(1.5,-(ol + dl * unit))))-1;
            var dd1 = curves.curves.B.value 
            var ddA = curves.curves.C.value 
            dd1 *= (2 / (1 + Math.pow(1.5,-(API.speed + API.speedChange * unit)*1)))-1;
            var dd2 = 1-dd1;            
            ddA *= (2 / (1 + Math.pow(1.2,-(API.speed + API.speedChange * unit)*1)))-1;
            var dd2A = 1-ddA;
           
            for(const h of hairs){
                h.x -= dx / 2;
                h.y -= dy / 2;
                var aa = (API.directionAccum + API.directionChange * unit) ;
                var a = h.a;
                var cs = Math.cos(a + aa);
                var ss = Math.sin(a + aa);
                //var dp = Math.acos(dx * ss - dy * cs);
                 var dp = Math.asin(dx * ss - dy * cs);
                h.af += dp;// *dd;
                h.af *= h.as;
                h.a += dp * ddA * (h.d1); //a + h.af;
                 var ddC = h.ang - h.a;
                h.a += (h.ang+aa - h.a) * h.d1* dd2A;
                h.dx += (Math.cos(h.a + aa) * (h.dist) - h.x) ;
                h.dy += (Math.sin(h.a + aa) * (h.dist) - h.y) ;
                h.dx *= drag;
                h.dy *= drag;
                h.x +=  h.dx;
                h.y +=  h.dy;
                h.lx1 = h.lx1 * dd1 + h.x * dd2;
                h.ly1 = h.ly1 *dd1 + h.y * dd2;   
                h.lx = (h.lx1 + h.x) / 2;
                h.ly = (h.ly1 + h.y) / 2;
                  
                if(!paint.colorBlend && !paint.randColor){
                    if(h.r === -1){
                        h.col = "rgba(0,0,0,0)";
                    }else{
                        h.blend += ((ddC * h.blendA  * dd2) / 8);
                        var be  = ((h.blend  % 1)+1)%1;
                        if(h.blend > 1 || h.blend < -1){
                             h.col = "rgba(" + (h.rr | 0) + "," + 
                            (h.gg | 0) + ","+ 
                            (h.bb | 0) + ","+ 
                            ((h.aa )/255 ) +")";  

  
                        } else {
                            h.col = "rgba(" + (be * (h.r - h.rr) + h.rr | 0) + "," + 
                            (be * (h.g - h.gg) + h.gg | 0) + ","+ 
                            (be * (h.b - h.bb) + h.bb | 0) + ","+ 
                            ((be * (h.al - h.aa) + h.aa )/255 ) +")";
                        }
                    }
                }else{
                    h.blend =h.blendA * dd2;   
                }    
                i += 1;
                if(i >= hairCount) {break}
            }
            hairs.hairCount = hairCount;    
            return  hairs;  
        },
        resetDirection(val = 0){
            API.directionAccum = val;
            API.directionChange = 0;
            dirChange.start(val);
            dirChangeA.start(val);
        },            
        add(x,y) {
            posA.add(x,y);
            posB.add(posA.x, posA.y);
            posC.add(posB.x, posB.y);
            x1 = x - posA.x;
            y1 = y - posA.y;
            x2 = posA.x - posB.x;
            y2 = posA.y - posB.y;    
            x3 = posB.x - posC.x;
            y3 = posB.y - posC.y;
            const oldDir = API.direction;
            API.direction = Math.atan2(y1 + y2 + y3, x1 + x2 + x3);
            l1 = Math.sqrt(x1 * x1 + y1 * y1);
            l2 = Math.sqrt(x2 * x2 + y2 * y2);
            l3 = Math.sqrt(x3 * x3 + y3 * y3);
            s = API.speed;
            API.speedChange = (API.speed = speed.add(l1 + l2 + l3)) - s;
            x2 /= l2;
            y2 /= l2;
            if (l1 !== 0 && l2 !== 0) {
                x1 /= l1;
                y1 /= l1;
                if (x2 * x1 + y2 * y1 < 0) { dirC1 = (d1 = Math.asin(x2 * y1 - y2 * x1)) < 0 ? -Math.PI - d1 : Math.PI - d1 }
                else { dirC1 = Math.asin(x2 * y1 - y2 * x1) }
            } else { dirC1 = 0 }
            if (l2 !== 0 && l3 !== 0) {
                x3 /= l3
                y3 /= l3;
                if (x3 * x2 + y3 * y2 < 0) { dirC2 = (d1 = Math.asin(x3 * y2 - y3 * x2))  < 0 ? -Math.PI - d1 : Math.PI - d1 }
                else { dirC2 = Math.asin(x3 * y2 - y3 * x2) }
            } else { dirC2 = 0 }
            
            x2 = Math.cos(oldDir);
            y2 = Math.sin(oldDir);
            x1 = Math.cos(API.direction);
            y1 = Math.sin(API.direction);
            if (x2 * x1 + y2 * y1 < 0) { dirC1 = (d1 = Math.asin(x2 * y1 - y2 * x1)) < 0 ? -Math.PI - d1 : Math.PI - d1 }
            else { dirC1 = Math.asin(x2 * y1 - y2 * x1) }
            API.directionChange  = dirC1;//(dirChangeA.add(dirC2)+dirChange.add(dirC1))/2;
            API.directionAccum += API.directionChange;
            if(mouse.button === 0){ API.distance = 0 }
            else { API.distance += API.speed }
        },
        directionPrev : 0,
        direction : 0,
        directionChange : 0,
        directionAccum : 0,
        distAccum : 0,
        distAccumSmooth : 0,
        lastDir : {...p},
        speed : 0,
        speedSmooth : 0,
        speedChange : 0,
    };
    API.brissleMad.setBeforColors = true;
    API.brisslePlain.setBeforColors = true;
    return API;
})();


const mouseBrush1 = (()=>{
    const p = {x : 0, y : 1};
    const points = [{...p},{...p},{...p},{...p},{...p},{...p},{...p},{...p},{...p},{...p},{...p}];
    const maxLen = points.length;
    const back = maxLen - 1;
    var pos = 0
    var sc = 0;
    var lx = 0,ly = 0;
    var ldx,ldy;

    var lastMouse = 0;
    const dirChange = Smoother(0.6,0.3);
    const dirChangeA = Smoother(0.4,0.3);
    const speed = Smoother(0.6,0.3);
    const posA = Smoother2D(0.6,0.3);
    const posB = Smoother2D(0.6,0.3);
    const posC = Smoother2D(0.6,0.3);
    var x1,y1,x2,y2,x3,y3,l1,l2,l3,c1,c2,d1,d2;  // l for length, c for cross product, d for dot product
    var dirC1,dirC2,dir,s;
    const API = {

        resetDirection(val = 0){
            API.add(lx+ldx, ly+ldy);
            API.add(lx+ldx, ly+ldy);
            API.add(lx+ldx, ly+ldy);
            API.add(lx+ldx, ly+ldy);
            API.directionAccum = val;
            API.directionChange = 0;
            dirChange.start(val);
            dirChangeA.start(val);
        },            
        add(x,y) {
            ldx = x - lx;
            ldy = y - ly;
            posA.add(x,y);
            posB.add(posA.x, posA.y);
            posC.add(posB.x, posB.y);
            x1 = x - posA.x;
            y1 = y - posA.y;
            x2 = posA.x - posB.x;
            y2 = posA.y - posB.y;    
            x3 = posB.x - posC.x;
            y3 = posB.y - posC.y;
            const oldDir = API.direction;
            API.direction = Math.atan2(y1 + y2 + y3, x1 + x2 + x3);
            l1 = Math.sqrt(x1 * x1 + y1 * y1);
            l2 = Math.sqrt(x2 * x2 + y2 * y2);
            l3 = Math.sqrt(x3 * x3 + y3 * y3);
            s = API.speed;
            API.speedChange = (API.speed = speed.add(l1 + l2 + l3)) - s;
            x2 /= l2;
            y2 /= l2;
            if (l1 !== 0 && l2 !== 0) {
                x1 /= l1;
                y1 /= l1;
                if (x2 * x1 + y2 * y1 < 0) { dirC1 = (d1 = Math.asin(x2 * y1 - y2 * x1)) < 0 ? -Math.PI - d1 : Math.PI - d1 }
                else { dirC1 = Math.asin(x2 * y1 - y2 * x1) }
            } else { dirC1 = 0 }
            if (l2 !== 0 && l3 !== 0) {
                x3 /= l3
                y3 /= l3;
                if (x3 * x2 + y3 * y2 < 0) { dirC2 = (d1 = Math.asin(x3 * y2 - y3 * x2))  < 0 ? -Math.PI - d1 : Math.PI - d1 }
                else { dirC2 = Math.asin(x3 * y2 - y3 * x2) }
            } else { dirC2 = 0 }
            
            x2 = Math.cos(oldDir);
            y2 = Math.sin(oldDir);
            x1 = Math.cos(API.direction);
            y1 = Math.sin(API.direction);
            if (x2 * x1 + y2 * y1 < 0) { dirC1 = (d1 = Math.asin(x2 * y1 - y2 * x1)) < 0 ? -Math.PI - d1 : Math.PI - d1 }
            else { dirC1 = Math.asin(x2 * y1 - y2 * x1) }
            
            API.directionChange  = dirC1;//(dirChangeA.add(dirC2)+dirChange.add(dirC1))/2;
            API.directionAccum += API.directionChange;
            if(mouse.button === 0){ API.distance = 0 }
            else { API.distance += API.speed }
        },
        directionPrev : 0,
        direction : 0,
        directionChange : 0,
        directionAccum : 0,
        distAccum : 0,
        distAccumSmooth : 0,
        lastDir : {...p},
        speed : 0,
        speedSmooth : 0,
        speedChange : 0,
    };

    return API;
})();




const pens1 = (()=>{
    const lineDef = {
        setAs(l){
            this.p1.x = l.p1.x;
            this.p1.y = l.p1.y;
            this.p2.x = l.p2.x;
            this.p2.y = l.p2.y;
            return this;
        }
    };
    const workLineA = {
        p1 : {x : 0, y : 0},
        p2 : {x : 0, y : 0},
        ...lineDef,
    };
    const workLineB = {
        p1 : {x : 0, y : 0},
        p2 : {x : 0, y : 0},
        ...lineDef,
    };
    const workPointA = {x : 0, y : 0};
    const workPointB = {x : 0, y : 0};
    const workPointC = {x : 0, y : 0};
    var cancelStroke = false;
    var firstDown = false;
    var firstDownCommon  = false;
    var secondColor,mainColor,alpha;
    var spraying = false;
    var brushMin, brushMax;
    var hairs;
    var locPoint =  [0,0,0,0,0,0,0,0,0,0];
    var locPointS =  [[0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0]];
    const smallAliasCirclesFill = [[],
        [0,],
        [1,0,],
        [2,2,1,],
        [3,3,2,1,],
        [4,4,3,2,1,],
        [5,5,4,4,3,1,],
        [6,6,5,5,4,3,1,],
    ];
    const smallAliasCirclesStroke = [[],
        [0,0],
        [1,0,0,1],
        [2,0,2,1,1,2,0,2],
        [3,0,3,1,2,2,1,3,0,3],
        [4,0,4,1,3,2,2,3,1,4,0,4],
        [5,0,5,1,4,2,4,3,3,4,2,4,1,5,0,5],
        [6,0,6,1,5,2,5,3,4,4,3,5,2,5,1,6,0,6],
    ];
    var blendColors = false;
    var inFeedback = true;
    var dirty = false;
    var nextDrawMode;
    var currentFilter = "none";
    const maxDrawTime = settings.maxDrawTime;
    const renderFunction = (()=>{
        const shapeEnds = [];
        const shapeSize = 0;
        const API = {
            mark(ctx,x,y,size,col){
                ctx.strokeStyle = col;
                ctx.beginPath();
                ctx.moveTo(x-size,y)
                ctx.lineTo(x+size,y)
                ctx.moveTo(x,y - size)
                ctx.lineTo(x,y + size)
                ctx.stroke();
            },
            line(ctx,l,col){
                ctx.strokeStyle = col;
                ctx.beginPath();
                ctx.moveTo(l.p1.x,l.p1.y)
                ctx.lineTo(l.p2.x,l.p2.y)
                ctx.stroke();
            },
            alias : {
                line(ctx, x1,y1,x2,y2,skipFirst = false, render = true){
                    var sizeRange = brushMax - brushMin;
                    var ww = paint.sizeBlend ? curves.C(0) * sizeRange + brushMin : brushMin;
                    var size = Math.max(1, ww| 0);
                    var offset = size / 2 ;
                    var x,y;
                    x1 = x = Math.round(x1  - offset);
                    y1 = y = Math.round(y1  - offset);
                    x2 = Math.round(x2  - offset);
                    y2 = Math.round(y2  - offset);
                    var dx = Math.abs(x2 - x1);
                    var sx = x1 < x2 ? 1 : -1;
                    var dy = -Math.abs(y2 - y1);
                    var sy = y1 < y2 ? 1 : -1;
                    var er = dx + dy;
                    var e2;
                    var end = false;
                    var dist = (dx * dx + dy * dy) ** 0.5;// ** 0.5;;
                    if (!blendColors && render) { ctx.beginPath() }
                    if(skipFirst){
                        if (x1 === x2 && y1 === y2) {
                            end = true;
                        } else {
                            e2 = 2 * er;
                            if (e2 > dy) {
                                er += dy;
                                x1 += sx;
                            }
                            if (e2 < dx) {
                                er += dx;
                                y1 += sy;
                            }
                        }
                    }
                    while (!end) {
                        const d = ((((x1-x)**2) + ((y1-y)**2)) ** 0.5)/ dist;
                        ww = paint.sizeBlend? curves.C(d) * sizeRange + brushMin : brushMin;
                        size = Math.max(1, ww  | 0);
                        offset = size / 2 | 0;
                        if(blendColors && render){
                            ctx.fillStyle = colours.colorRange[curves.B(d) * 255 | 0];
                            ctx.fillRect(x1 , y1 , size, size);
                        }else{
                            ctx.rect(x1 , y1 , size, size);
                        }
                        if (x1 === x2 && y1 === y2) {
                            end = true;
                        } else {
                            e2 = 2 * er;
                            if (e2 > dy) {
                                er += dy;
                                x1 += sx;
                            }
                            if (e2 < dx) {
                                er += dx;
                                y1 += sy;
                            }
                        }
                    }
                    if(!blendColors && render){ ctx.fill() }
                },
            },
            antiAlias : {
                line(ctx,x1,y1,x2,y2){
                    ctx.lineWidth = brushMin;
                    ctx.lineCap = "round";
                    ctx.beginPath();
                    ctx.lineTo(x1, y1);
                    ctx.lineTo(x2, y2);
                    ctx.stroke();
                }
            }
        };
        return API;
    })();
    function setColors(spr,ctx,seperate = false){
        if(mouse.button === 0){
            if(paint.colorBlend && paint.palletFrom === commands.paintColImage){
                    ctx.strokeStyle = "red";
                    ctx.lineWidth  = 0.5;
                    ctx.globalAlpha  = 0.5;
                    ctx.beginPath();
                    var rad = Math.ceil(paint.sliders.lengthFade * spr.key.cross);
                    ctx.arc(spr.key.lx,spr.key.ly,rad,0,Math.PI*2);
                    ctx.stroke();
            }
            if(paint.drawType === commands.paintFromImage){
                    ctx.strokeStyle = "red";
                    ctx.lineWidth  = 0.5;
                    ctx.globalAlpha  = 0.5;
                    ctx.beginPath();
                    var rad = Math.ceil(brushMin/2);
                    ctx.arc(spr.key.lx,spr.key.ly,rad,0,Math.PI*2);
                    ctx.stroke();
                    if(paint.randColor){
                        rad = paint.sliders.lengthFade;
                        ctx.strokeStyle = "#0f0";
                        ctx.beginPath();
                        ctx.arc(spr.key.lx,spr.key.ly,rad,0,Math.PI*2);
                        ctx.stroke();
                    }
            }
            if(paint.drawType === commands.paintPointShaped || paint.drawType === commands.paintSpray){
                    ctx.strokeStyle = "red";
                    ctx.lineWidth  = 0.5;
                    ctx.globalAlpha  = 0.5;
                    ctx.beginPath();
                    var rad = paint.sliders.widthFade;
                    ctx.arc(spr.key.lx,spr.key.ly,rad,0,Math.PI*2);
                    ctx.stroke();
                    rad = paint.sliders.lengthFade;
                    ctx.strokeStyle = "#0f0";
                    ctx.beginPath();
                    ctx.arc(spr.key.lx,spr.key.ly,rad,0,Math.PI*2);
                    ctx.stroke();
            }
            if(paint.useDirection) {
                    ctx.strokeStyle = "red";
                    ctx.lineWidth  = 1;
                    ctx.globalAlpha  = 0.5;
                    var rad = brushMin / 20;
                    ctx.beginPath();
                    ctx.setTransform(1,0,0,1,spr.key.lx,spr.key.ly);
                    ctx.rotate(mouseBrush.direction);
                    ctx.lineTo(0,0);
                    ctx.lineTo(rad * 20,0);
                    ctx.moveTo(rad * 17 ,rad * 3);
                    ctx.lineTo(rad * 20,0);
                    ctx.lineTo(rad * 17 ,-rad * 3);
                    ctx.stroke();
                    ctx.setTransform(1,0,0,1,0,0);
            }
        }
        if(seperate){
            if(mouse.button === 1 || mouse.button === 0){
                ctx.strokeStyle = mainColor;
                ctx.fillStyle = secondColor;
                colours.setContextDrawMode(ctx, colours.secondDrawMode); // the fill (second color is rendered first
                nextDrawMode = colours.mainDrawMode;
            }else if(mouse.button === 4){
                ctx.strokeStyle = secondColor;
                ctx.fillStyle = mainColor;
                colours.setContextDrawMode(ctx, colours.mainDrawMode); // the fill (now main color is rendered first
                nextDrawMode = colours.secondDrawMode;
            }
        }else{
            if(paint.randColor){
                if(mouse.button === 1 || mouse.button === 0){
                    ctx.fillStyle = ctx.strokeStyle = colours.colorRange[curves.B(Math.random()) * 255 | 0];
                    colours.setContextDrawMode(ctx, colours.mainDrawMode);
                    nextDrawMode = colours.mainDrawMode;
                }else if(mouse.button === 4){
                    ctx.fillStyle = ctx.strokeStyle = colours.colorRange[(1-curves.B(Math.random())) * 255 | 0];
                    colours.setContextDrawMode(ctx, colours.secondDrawMode);
                    nextDrawMode = colours.secondDrawMode;
                }
            }else{
                if(mouse.button === 1 || mouse.button === 0){
                    ctx.fillStyle = ctx.strokeStyle = mainColor;
                    colours.setContextDrawMode(ctx, colours.mainDrawMode);
                    nextDrawMode = colours.mainDrawMode;
                }else if(mouse.button === 4){
                    ctx.fillStyle = ctx.strokeStyle = secondColor;
                    colours.setContextDrawMode(ctx, colours.secondDrawMode);
                    nextDrawMode = colours.secondDrawMode;
                }
            }
        }
        ctx.globalAlpha = alpha;

            
        if( ! inFeedback){
            ctx.filter = paint.buildFilter();//currentFilter;
            paint.shadow(ctx,true);
        }else{
            ctx.filter = "none";
            paint.shadow(ctx);
        }
        
    }
    function setColorsOnly(ctx,seperate = false){

        if(seperate){
            if(mouse.button === 1 || mouse.button === 0){
                ctx.strokeStyle = mainColor;
                ctx.fillStyle = secondColor;

                nextDrawMode = colours.mainDrawMode;
            }else if(mouse.button === 4){
                ctx.strokeStyle = secondColor;
                ctx.fillStyle = mainColor;

                nextDrawMode = colours.secondDrawMode;
            }
        }else{
            if(paint.randColor){
                if(mouse.button === 1 || mouse.button === 0){
                    ctx.fillStyle = ctx.strokeStyle = colours.colorRange[curves.B(Math.random()) * 255 | 0];

                    nextDrawMode = colours.mainDrawMode;
                }else if(mouse.button === 4){
                    ctx.fillStyle = ctx.strokeStyle = colours.colorRange[(1-curves.B(Math.random())) * 255 | 0];

                    nextDrawMode = colours.secondDrawMode;
                }
            }else{
                if(mouse.button === 1 || mouse.button === 0){
                    ctx.fillStyle = ctx.strokeStyle = mainColor;

                    nextDrawMode = colours.mainDrawMode;
                }else if(mouse.button === 4){
                    ctx.fillStyle = ctx.strokeStyle = secondColor;

                    nextDrawMode = colours.secondDrawMode;
                }
            }
        }
        


        
    }    
    function pointAliasFeedback(spr,ctx, restore){
        if(!spr.image.restored && restore){
            spr.image.restore();
        }
        setColors(spr,ctx)
        ctx.lineWidth = 1;
        var w = brushMin;
        var sizeRange = (brushMax - brushMin);
        var minS = brushMin;
        var x,y;
        x = spr.key.lx;
        y = spr.key.ly;
        if(paint.colorBlend){ctx.strokeStyle = ctx.fillStyle = colours.colorRange[curves.B(Math.random()) * 255 | 0]}
        var ww = paint.sizeBlend ? curves.C(0) * sizeRange + minS : w
        const size = Math.max(1, ww  | 0);
        const offset = size / 2;
        var xx = Math.round(x - offset);
        var yy = Math.round(y - offset);
        ctx.fillRect(xx,yy, size, size);
    }
    function pointsAlias(spr,ctx, restore){
        if(!spr.image.restored && restore){
            spr.image.restore();
        }
        setColors(spr,ctx)
        var w = brushMin * spr.key.cross;
        var sizeRange = (brushMax - brushMin) * spr.key.cross;
        var minS = brushMin *  spr.key.cross;
        if (!paint.colorBlend) {ctx.beginPath() }
        var dx,dy,x,y;
        var step = 1/ Math.min(30, paint.sliders.brush.step);
        x = spr.key._lx;
        y = spr.key._ly;
        dx = spr.key.lx - spr.key._lx;
        dy = spr.key.ly - spr.key._ly;
        var len = Math.sqrt(dx * dx + dy * dy) + 0.01;
        if(paint.colorBlend){
            for(var i = 0; i < 1; i += step){
                ctx.fillStyle = colours.colorRange[curves.B(Math.random()) * 255 | 0];
                var ww = paint.sizeBlend ? curves.C(Math.random()) * sizeRange + minS : w
                const size = Math.max(1, ww * spr.key.cross | 0);
                const offset = size / 2;
                var xx = Math.round(x + dx * i - offset);
                var yy = Math.round(y + dy * i - offset);
                ctx.beginPath();
                ctx.rect(xx,yy, size, size);
                ctx.fill();
            }
        }else{
            for(var i = 0; i < 1; i += step){
                var ww = paint.sizeBlend ? curves.C(Math.random()) * sizeRange + minS : w
                const size = Math.max(1, ww * spr.key.cross | 0);
                const offset = size / 2;
                var xx = Math.round(x + dx * i - offset);
                var yy = Math.round(y + dy * i - offset);
                ctx.rect(xx, yy, size, size);
            }
        }
        if(!paint.colorBlend){
            ctx.fill();
        }
        spr.key._lx = spr.key.lx;
        spr.key._ly = spr.key.ly;
    }
    function points(spr,ctx, restore){
        if(!spr.image.restored && restore){
            spr.image.restore();
        }
         setColors(spr,ctx);
        var w = brushMin * spr.key.cross;
        var r = paint.sliders.widthFade * spr.key.cross;
        var sizeRange = (brushMax - brushMin) * spr.key.cross;
        var minS = brushMin *  spr.key.cross;
        var dx,dy,x,y;
        var step = 1/ Math.min(30, paint.sliders.brush.step);
         if (!paint.colorBlend) {ctx.beginPath() }
        if(spr.key._lx !== undefined){
            x = spr.key._lx;
            y = spr.key._ly;
            dx = spr.key.lx - spr.key._lx;
            dy = spr.key.ly - spr.key._ly;
            var len = Math.sqrt(dx * dx + dy * dy) + 0.01;
            var sx = dx / len * 0.1;
            var sy = dy / len * 0.1;
            for(var i = 0; i < 1; i += step){
                var ww = (paint.sizeBlend ? curves.C(Math.random()) * sizeRange + minS : w) / 2;
                var xx = x + dx * i;
                var yy = y + dy * i;
                if(paint.colorBlend){
                    ctx.fillStyle = colours.colorRange[curves.B(Math.random()) * 255 | 0];
                     if(ww < 2){
                        ctx.fillRect(xx - ww, yy - ww, ww + ww, ww+ ww);
                    }else{
                        ctx.beginPath();
                        ctx.moveTo(xx + ww,yy);
                        ctx.arc(xx,yy,ww ,0,Math.PI*2);
                        ctx.fill();
                    }
                }else{
                    if(ww < 2){
                        ctx.rect(xx - ww, yy - ww, ww * 2, ww*2);
                    }else{
                        ctx.moveTo(xx + ww,yy);
                        ctx.arc(xx,yy,ww ,0,Math.PI*2);
                    }
                }
            }
        }
        if (!paint.colorBlend) {ctx.fill() }
        spr.key._lx = spr.key.lx;
        spr.key._ly = spr.key.ly;
    }
    const extraBrushes = {
        extra : null,
        setExtraBrush(name){
            if(extraBrushes[name]){
                extraBrushes.extra = extraBrushes[name];
            }
        },        
        moveBrissles(spr,ctx, restore){

            if(!spr.image.restored && restore){
                spr.image.restore();
            }
            setColors(spr,ctx);
            if(firstDown){

            }
            var r = paint.sliders.widthFade;
            var lf = paint.sliders.lengthFade;
            var rChange = 0;
            var sizeRange = (brushMax - brushMin) / 2;
            var minS = brushMin/ 2;
            var minSChange = 0;
            var speedSize = 1;
            var speedChange
            var dx,dy,x,y;
             var dx,dy,x,y,step = 0;
            var img;
            const randColor = paint.colorBlend || paint.randColor;
            x = spr.key._lx;
            y = spr.key._ly;
            dx = spr.key.lx - spr.key._lx;
            dy = spr.key.ly - spr.key._ly;
            var len = Math.sqrt(dx * dx + dy * dy) + 0.00001;
            var rx = mouse.cMouse.oldRx;
            var ry = mouse.cMouse.oldRy;
            var rdx = mouse.cMouse.rx - rx;
            var rdy = mouse.cMouse.ry - ry;
            var rlen = Math.sqrt(rdx *rdx + rdy * rdy) + 0.00001;        
            var count = 1 ;
            var start = 0;
            if(mouse.button === 0){
                  if( paint.sliders.brush.step > 0){
                    step = 0.5
                }else{
                    step = 0.5;
                }
            }else{
                step = 1 / (len > 1 ? len : 1);
                if(!firstDownCommon){
                    start = step/2;
                }
            }
            var time = performance.now();
            const shadeMode = mouseBrush.shadeMode === 1 || paint.palletFrom === commands.paintColImage;
            hairs.step = step;
            if(mouseBrush.drawMode === mouseBrush.drawModes.circles || 
                mouseBrush.drawMode === mouseBrush.drawModes.circles1|| 
                mouseBrush.drawMode === mouseBrush.drawModes.longContact){
                for(var i = start; i < count; i += step){
                    var xx = x + dx * i;
                    var yy = y + dy * i;
                    hairs.unit = i;
                    mouseBrush.extra(rx+rdx*i,ry+rdy*i,false);
                    ctx.setTransform(1,0,0,1,xx,yy);
                    if(paint.useDirection){
                        if(paint.useSpeed ){
                            ctx.rotate(mouseBrush.direction + i*mouseBrush.directionChange );  
                        }else{
                            ctx.rotate(mouseBrush.directionAccum + i*mouseBrush.directionChange ); 
                        }                    
                    }else if(paint.useSpeed ){
                        ctx.rotate(mouseBrush.direction );  
                    }
                    if(mouseBrush.drawMode  === mouseBrush.drawModes.longContact){
                        for(var j = 0; j < hairs.hairCount - 1; j += 2){
                            var hr = hairs[j];
                            var hr1 = hairs[j+1];
                            hr1.x =   hr.lx1 * 0.8 + hr1.x *   0.2;
                            hr1.y =   hr.ly1 * 0.8 + hr1.y *   0.2;                            
                            hr1.lx =  hr1.x  * 0.8 + hr1.lx *  0.2;
                            hr1.ly =  hr1.y  * 0.9 + hr1.ly *  0.1;                            
                            hr1.lx1 = hr1.x  * 0.9 + hr1.lx1 * 0.1;
                            hr1.ly1 = hr1.y  * 0.9 + hr1.ly1 * 0.1;
                            if(shadeMode){
                                if(j % 4 === 2){
                                    ctx.strokeStyle = hr1.col
                                }else{
                                    ctx.strokeStyle = hr.col
                                }
                            }else if(paint.randColor ){ ctx.strokeStyle = hr.col }
                            ctx.lineWidth = 0.5;
                            ctx.beginPath();
                            ctx.lineTo(hr.x,hr.y);
                            ctx.lineTo(hr.lx,hr.ly);
                            ctx.lineTo(hr.lx1,hr.ly1);  
                            ctx.lineTo(hr1.x,hr1.y);
                            ctx.lineTo(hr1.lx,hr1.ly);
                            ctx.lineTo(hr1.lx1,hr1.ly1);
                            ctx.stroke();
                        }       
                    }else if(mouseBrush.drawMode  === mouseBrush.drawModes.circles){
                        for(var j = 0; j < hairs.hairCount; j += 1){
                            var hr = hairs[j];
                            if(paint.randColor || shadeMode){ ctx.strokeStyle = hr.col }
                            ctx.lineWidth = 0.75;
                            var dx = hr.lx1 - hr.x;
                            var dy = hr.ly1 - hr.y;
                            var r = (2 / (1 + Math.pow(1.4,-Math.abs(hr.ang - hr.a))))-1;
                            ctx.beginPath();
                            ctx.arc(hr.x,hr.y,r * lf,hr.a,hr.a + r * Math.PI * 2);
                            ctx.stroke();
                        }
                        i = count
                    }else{
                        for(var j = 0; j < hairs.hairCount; j += 1){
                            var hr = hairs[j];
                            if(paint.randColor || shadeMode){ ctx.strokeStyle = hr.col }
                            ctx.lineWidth = 0.5;
                            var dx = hr.lx - hr.x;
                            var dy = hr.ly - hr.y;
                            var r = (2 / (1 + Math.pow(1.8,-(Math.sqrt(dx*dx + dy *dy) + 0.3))))-1;
                            ctx.beginPath();
                            ctx.arc(hr.x,hr.y,r*lf,0,Math.PI * 2);
                            ctx.stroke();
                        }
                    }
                }
            }else   if(mouseBrush.drawMode === mouseBrush.drawModes.points){
                for(var i = start; i < count; i += step){
                    var xx = x + dx * i;
                    var yy = y + dy * i;
                    hairs.unit = i;
                    mouseBrush.extra(rx+rdx*i,ry+rdy*i,false);
                    ctx.setTransform(1,0,0,1,xx,yy);
                    if(paint.useDirection){
                        if(paint.useSpeed ){
                            ctx.rotate(mouseBrush.direction + i*mouseBrush.directionChange );  
                        }else{
                            ctx.rotate(mouseBrush.directionAccum + i*mouseBrush.directionChange ); 
                        }                    
                    }else if(paint.useSpeed ){
                        ctx.rotate(mouseBrush.direction );  
                    }
                    for(var j = 0; j < hairs.hairCount; j += 1){
                        var hr = hairs[j];
                        if(paint.randColor || shadeMode){ ctx.fillStyle = hr.col }
                        if(hr.size <= 2){
                            ctx.fillRect(hr.x-hr.size/2,hr.y- hr.size/2,hr.size,hr.size);
                        }else{
                            ctx.beginPath();
                            ctx.arc(hr.x,hr.y,hr.size,0,Math.PI * 2);
                            ctx.fill();
                        }
                    }
                }
            }else if(mouseBrush.drawMode  === mouseBrush.drawModes.lines || mouseBrush.drawMode  === mouseBrush.drawModes.lines1|| mouseBrush.drawMode  === mouseBrush.drawModes.lineHighlight){
                ctx.lineJoin = "round"; 
                ctx.lineCap = "round"; 
                for(var i = start; i < count; i += step){
                    var xx = x + dx * i;
                    var yy = y + dy * i;
                    hairs.unit = i;
                    mouseBrush.extra(rx+rdx*i,ry+rdy*i,false);
                    ctx.setTransform(1,0,0,1,xx,yy);
                    if(paint.useDirection){
                        if(paint.useSpeed ){
                            ctx.rotate(mouseBrush.direction + i*mouseBrush.directionChange );  
                        }else{
                            ctx.rotate(mouseBrush.directionAccum + i*mouseBrush.directionChange ); 
                        }                    
                    }else if(paint.useSpeed ){
                        ctx.rotate(mouseBrush.direction );  
                    }
                    if(mouseBrush.drawMode  === mouseBrush.drawModes.lines1){
                        for(var j = 0; j < hairs.hairCount; j += 1){
                            var hr = hairs[j];
                            if(paint.randColor || shadeMode){ ctx.strokeStyle = hr.col }
                            ctx.lineWidth = hr.size;
                            ctx.beginPath();
                            ctx.lineTo(hr.x,hr.y);
                            ctx.lineTo(hr.lx + 0.5,hr.ly);
                            ctx.lineTo(hr.lx1 + 0.75,hr.ly1);
                            ctx.closePath()
                            ctx.stroke();
                        }
                        i += step * 4
                    }else{
                        for(var j = 0; j < hairs.hairCount; j += 1){
                            var hr = hairs[j];
                            if(paint.randColor || shadeMode){ ctx.strokeStyle = hr.col }
                            ctx.lineWidth = hr.size;
                            ctx.beginPath();
                            ctx.lineTo(hr.x,hr.y);
                            ctx.lineTo(hr.lx + 0.5,hr.ly);
                            ctx.lineTo(hr.lx1 + 0.75,hr.ly1);
                            ctx.stroke();
                        }
                        if(mouseBrush.drawMode  === mouseBrush.drawModes.lineHighlight){
                            if(i + step >= count){
                                var compMode = ctx.globalCompositeOperation;
                                var alph = ctx.globalAlpha;
                                ctx.lineWidth = 0.5;//Math.min(Math.max(0.1,brushMin / 3),1);
                                const off = 2;
                                ctx.globalCompositeOperation = "screen";
                                ctx.globalAlpha = 0.2;
                                ctx.strokeStyle = "#fff"  ;                       
                                ctx.beginPath();
                                for(var j = 0; j < hairs.hairCount; j += 1){
                                    var hr = hairs[j];
                                    ctx.moveTo(hr.x-off,hr.y-off);
                                    ctx.lineTo(hr.lx -off+ 0.5,hr.ly -off);
                                    ctx.lineTo(hr.lx1 -off + 0.75,hr.ly1 -off);
                                }
                                ctx.stroke();
                                ctx.globalCompositeOperation = compMode;
                                ctx.globalAlpha = alph;     
                            }
                        }                            
                    }
                }
            }
            spr.key._lx = spr.key.lx;
            spr.key._ly = spr.key.ly;
        }
    }
    var edgeFillStarted = false;
    var edgeFillSelect = 0;
    var edgeFillDoIt = false;
    var edgeFillX,edgeFillY;
    var edgeFillEdges = [0b10, 0b1000000, 0b100, 0b10000000, 0b1000, 0b10000, 0b1, 0b100000];
    function edgeFillUIRender(c){
        const x = edgeFillX;
        const y = edgeFillY;
        c.fillStyle = "white";
        c.strokeStyle = "black";
        c.lineWidth  = 2;
        c.beginPath();
        c.arc(x,y,32,0,Math.PI2);    
        c.moveTo(x + 16,y);        
        c.arc(x,y,16,0,Math.PI2);    

        c.fill("evenodd");

        c.beginPath();
        c.lineWidth  = 1;
        c.globalAlpha = 0.7;
        c.arc(x,y,8,0,Math.PI2);
        c.moveTo(x + 16,y);
        c.arc(x,y,16,0,Math.PI2);
        c.moveTo(x + 24,y);
        c.arc(x,y,24,0,Math.PI2);
        c.moveTo(x + 32,y);
        c.arc(x,y,32,0,Math.PI2);
        c.stroke();
        c.globalAlpha = 1;
        c.fillStyle  = "red";
        (edgeFillSelect & 1) && (c.fillRect(x - 16, y - 24, 32,8));
        (edgeFillSelect & 2) && (c.fillRect(x + 16, y - 16, 8,32));
        (edgeFillSelect & 4) && (c.fillRect(x - 16, y + 16, 32,8));
        (edgeFillSelect & 8) && (c.fillRect(x - 24, y - 16, 8,32));
        (edgeFillSelect & 16) && (c.fillRect(x - 24, y - 24, 8,8));
        (edgeFillSelect & 32) && (c.fillRect(x + 16, y - 24, 8,8));
        (edgeFillSelect & 64) && (c.fillRect(x + 16, y + 16, 8,8));
        (edgeFillSelect & 128) && (c.fillRect(x - 24, y + 16, 8,8));
   }
   function floodFill(spr,ctx, restore){
        if(!spr.image.restored && restore){
            spr.image.restore();
        }
        setColors(spr,ctx);
        if(paint.fillMode === 0){
            localProcessImage.floodFill(spr.image,spr.key.lx|0,spr.key.ly|0,brushMax*4|0, false, paint.antiAlias,ctx.fillStyle);
        }else if(paint.fillMode === 1){
            localProcessImage.floodFill(spr.image,spr.key.lx|0,spr.key.ly|0,brushMax*4|0, true, paint.antiAlias,ctx.fillStyle);
        }else if(paint.fillMode === 2){
            if(edgeFillDoIt){
                localProcessImage.floodFillOutline(spr.image,spr.key._lx|0,spr.key._ly|0,brushMax*4|0, false,edgeFillSelect,ctx.fillStyle);
                return;
            }
            if(edgeFillStarted){
                var x = edgeFillX;
                var y = edgeFillY;
                var px = mouse.x - x;
                var py = mouse.y - y;
                var dist = Math.sqrt(px * px + py * py);
                if(dist < 8){
                    edgeFillSelect = 0b11111111;                    
                }else {
                    var ang = Math.atan2(py,px) + Math.PI / 8;
               
                    ang = ((ang % Math.PI2) + Math.PI2) % Math.PI2;
                    ang /= Math.PI2;
                    ang *= 8;
                    ang |= 0;
                    edgeFillSelect = edgeFillEdges[ang];
            
                    var ang1 = ang;
                    if(dist < 32){
                        ang += 1;
                        ang1 += 7;
                        edgeFillSelect |= edgeFillEdges[ang%8] | edgeFillEdges[ang1%8];
                    }
                    if(dist < 24){
                        ang += 1;
                        ang1 += 7;
                        edgeFillSelect |= edgeFillEdges[ang%8] | edgeFillEdges[ang1%8];
                    }
                    if(dist < 16){
                        ang += 1;
                        ang1 += 7;
                        edgeFillSelect |= edgeFillEdges[ang%8] | edgeFillEdges[ang1%8];
                    }
                }
   
            }else{
                edgeFillX = mouse.x;
                edgeFillY  = mouse.y;    
                spr.key._lx = spr.key.lx;
                spr.key._ly = spr.key.ly;   
                edgeFillStarted = true;
            }
        }
   }
    
    function cutBufferDraw(spr,ctx, restore){
        if(!spr.image.restored && restore){
            spr.image.restore();
        }
        setColors(spr,ctx);
        cuttingTools.drawBuffer(spr,ctx);
    }
    function imageMove(spr,ctx, restore){
        if(!spr.image.restored && restore){
            spr.image.restore();
        }
        setColors(spr,ctx);
        var r = paint.sliders.widthFade;
        var angAdd = ((paint.sliders.widthFade / 60) - 0.5) * Math.PI;
        var rl = paint.sliders.lengthFade ;
        var sizeRange = (brushMax - brushMin) / 2;
        var minS = brushMin / 2;
        var speedSize = 1;//curves.B(Math.min(30,mouseBrush.speed + 1) / 30)
        if(paint.useSpeed){
            //speedSize = curves.B(Math.min(30,Math.sqrt(mouseBrush.speed) + 1) / 30);
            speedSize = curves.B(Math.min(30,mouseBrush.speedSmooth + 1) / 30)
            minS = speedSize * sizeRange + minS;
            sizeRange *= speedSize;
        }
         var xx,yy,x1,y1,img,dx,dy,x,y,step = 0;
        var lastX,lastY
        lastX = x = spr.key._lx;
        lastY = y = spr.key._ly;
        dx = spr.key.lx - spr.key._lx;
        dy = spr.key.ly - spr.key._ly;
        var len = Math.sqrt(dx * dx + dy * dy) + 0.00001;
        var count = 1 ;
        var start = 0;
        if(mouse.button === 0){
            if(!spraying){
                mouseBrush.resetDirection(mouseBrush.direction + angAdd);
            }else{
                mouseBrush.resetDirection(mouseBrush.direction);
            }
            mouseBrush.distAccum = 0;
            if( paint.sliders.brush.step > 0){
                step =  0.5;
            }else{
                step = 0.5;
                if(paint.sliders.curveStep > 0){
                    step *= paint.sliders.curveStep;
                    count += step/2
                    if (!firstDown){
                        if (len < paint.sliders.curveStep) { return }
                        start += step;
                    }
                }
            }
        }else{
             if( paint.sliders.brush.step > 0){
                step =  1/paint.sliders.brush.step;//1/ Math.min(30, paint.sliders.brush.step);
            }else{
                step = 1 / (len > 1 ? len : 1);
                if(paint.sliders.curveStep > 0){
                    step *= paint.sliders.curveStep;
                    count += step/2
                    if (!firstDown){
                        if (len < paint.sliders.curveStep) { return }
                        start += step;
                    }
                }
            }
        }
        var dxs = dx * step*2;
        var dys = dy * step*2;
        var time = performance.now();
        if(paint.sizeBlend){
            if(spraying){
                for(var i = start; i < count; i += step){
                    var w = curves.C(Math.random()) * sizeRange + minS ;
;
                    var wwc2 = w * 2;
                    var a = Math.random() * Math.PI * 2;
                    var b = curves.C(Math.random()) * r;
                    ctx.globalAlpha = paint.useAlphaDist
                    if(paint.useAlphaDist) { ctx.globalAlpha = curves.sprayAlpha(b / r) * alpha };
                    if(paint.antiAlias){
                        xx = Math.cos(a) * b + (x + dx * i);
                        yy = Math.sin(a) * b + (y + dy * i);
                        img = imageMover.sample(xx-dxs,yy-dys,ctx.canvas, w, brushMax);
                    }else{
                        xx = Math.cos(a) * b + (x + dx * i);
                        yy = Math.sin(a) * b + (y + dy * i);
                        img = imageMover.sample((xx-dxs*2+0.5)|0,(yy-dys*2+0.5)|0,ctx.canvas, w, brushMax);
                        xx = xx+0.5 | 0;
                        yy = yy+0.5 | 0;
                    }
                    if(paint.useDirection){
                        ctx.setTransform(1,0,0,1,xx,yy);
                        ctx.rotate(mouseBrush.direction);
                        ctx.drawImage(img,128-w,128-w,wwc2,wwc2,-w,-w,wwc2,wwc2);
                    }else {
                        ctx.drawImage(img,128-w,128-w,wwc2,wwc2,xx-w,yy-w,wwc2,wwc2);
                    }
                }
            }else{
                for(var i = start; i < count; i += step){
                    var w = curves.C(Math.random()) * sizeRange + minS ;;
                    var wwc2 = w * 2;
                    if(paint.antiAlias){
                        xx = x + dx * i;
                        yy = y + dy * i;
                        img = imageMover.sample(xx-dxs,yy-dys,ctx.canvas, w, brushMax);
                    }else{
                        xx = (x + dx * i + 0.5) | 0;
                        yy = (y + dy * i + 0.5) | 0;
                        img = imageMover.sample((xx-dxs+0.5)|0,(yy-dys+0.5)|0,ctx.canvas, w, brushMax);
                    }
                    if(paint.useDirection){
                        ctx.setTransform(1,0,0,1,xx,yy);
                        ctx.rotate(mouseBrush.direction);
                        ctx.drawImage(img,128-w/4,128-w,wwc2/4,wwc2,-w/4,-w,wwc2/4,wwc2);
                    }else {
                        ctx.drawImage(img,128-w/4,128-w,wwc2/4,wwc2,xx-w/4,yy-w,wwc2/4,wwc2);
                    }
                }
            }
        }else{
            var w = minS;
            var wwc2 = w * 2;
            var ssx = brushMax;
            var ssy = brushMin;
            var wwc2x = Math.max(1,ssx | 0);
            var wwc2y = Math.max(1,ssy | 0);
            var ssMax = Math.max(wwc2y,wwc2x)
            var wwc1x = wwc2x / 2;
            var wwc1D = (-wwc1x + mouseBrush.directionAccum)%(ssMax-wwc2x);
            var wwc1y = wwc2y / 2;
            if(firstDownCommon){
                if(!spraying){
                    mouseBrush.resetDirection( mouseBrush.direction + angAdd);
                }else{
                    mouseBrush.resetDirection(mouseBrush.direction);
                }

            }
            if((paint.useSpeed && !curves.A.isRandom) || (firstDownCommon && (spraying || paint.randColor)) || ((mouse.button & 4) === 4 && (spraying || paint.randColor))){
                if(!spraying){
                    mouseBrush.resetDirection( mouseBrush.direction + angAdd);
                }else{
                    mouseBrush.resetDirection(mouseBrush.direction);
                }
                if(paint.randColor){
                    if(paint.useDirection){
                        img = imageMover.sample((x+0.5)|0,(y+0.5)|0,ctx.canvas,wwc2x,wwc2y,mouseBrush.directionAccum);
                    }else{
                        img = imageMover.sample((x+0.5)|0,(y+0.5)|0,ctx.canvas,wwc2x,wwc2y, mouseBrush.direction);
                    }
                }else{
                    img = imageMover.sample((x+0.5)|0,(y+0.5)|0,ctx.canvas);
                }
                firstDownCommon = false
            }
            if(paint.antiAlias){
                ctx.imageSmoothingEnabled = true;
            }else{
                ctx.imageSmoothingEnabled = false;
            }
            if(spraying){
                for(var i = start; i < count; i += step){
                    for(var j = 0; j < 4; j ++){
                        var a = Math.random() * Math.PI * 2;
                        var b = curves.C(Math.random()) * r;
                        var aa = Math.random() * Math.PI * 2;
                        var bb = curves.C(Math.random()) * rl;
                        var rr = Math.random() * Math.PI * 2;
                        if(paint.useAlphaDist) { ctx.globalAlpha = curves.sprayAlpha(b / r) * alpha };
                        if(paint.useDirection && wwc2 > 2){ //
                            var rr = mouseBrush.direction; //Math.random() * Math.PI * 2;
                            var xdx = Math.cos(rr);
                            var xdy = Math.sin(rr);
                            if(paint.antiAlias){
                                ctx.setTransform(
                                    xdx, xdy, - xdy, xdx,
                                    (x + dx * i) + Math.cos(a) * b,
                                    (y + dy * i) + Math.sin(a) * b
                                )
                                ctx.drawImage(imageMover.can1,
                                    128 + Math.cos(aa) * bb-wwc1x,
                                    128 + Math.sin(aa) * bb-wwc1y,
                                    wwc2x,wwc2y,
                                   -wwc1x, -wwc1y,
                                    wwc2x,wwc2y
                                );
                            }else{
                                ctx.setTransform(
                                    xdx, xdy, - xdy, xdx,
                                    ((x + dx * i) + Math.cos(a) * b+ 0.5) | 0,
                                    ((y + dy * i) + Math.sin(a) * b+ 0.5) | 0
                                )
                                ctx.drawImage(imageMover.can1,
                                    (128.5 + Math.cos(aa) * bb-wwc1x) | 0,
                                    (128.5 + Math.sin(aa) * bb-wwc1y) | 0,
                                    wwc2x,wwc2y,
                                    -wwc1x | 0,
                                     -wwc1y | 0,
                                    wwc2x,wwc2y
                                );
                            }
                        }else{
                            if(paint.antiAlias){
                                ctx.drawImage(imageMover.can1,
                                    128 + Math.cos(aa) * bb-w,
                                    128 + Math.sin(aa) * bb-w,
                                    wwc2,wwc2,
                                    (x + dx * i) + Math.cos(a) * b -w,
                                    (y + dy * i) + Math.sin(a) * b -w,
                                    wwc2,wwc2
                                );
                            }else{
                                ctx.drawImage(imageMover.can1,
                                    (128.5 + Math.cos(aa) * bb-w) | 0,
                                    (128.5 + Math.sin(aa) * bb-w) | 0,
                                    wwc2,wwc2,
                                    ((x + dx * i) + Math.cos(a) * b -w + 0.5) | 0,
                                    ((y + dy * i) + Math.sin(a) * b -w + 0.5) | 0,
                                    wwc2,wwc2
                                );
                            }
                        }
                    }
                }
            }else{
                if(paint.randColor){
                    for(var i = start; i < count; i += step){
                        var aa = Math.random() * Math.PI * 2;
                        var bb = curves.C(Math.random()) * rl;
                        if(paint.useAlphaDist) { ctx.globalAlpha = curves.sprayAlpha(b / r) * alpha };
                        if(paint.antiAlias){
                            var aaa;
                            if(paint.useDirection){
                                aaa = mouseBrush.directionAccum;
                            }else{
                                aaa = angAdd;
                            }
                            var wwc1D = (-wwc1x + mouseBrush.directionAccum+mouseBrush.speed*i)%(ssMax-wwc2x);
                                ctx.setTransform(1,0,0,1,x + dx * i ,y + dy * i );
                                ctx.rotate(aaa);
                                ctx.drawImage(imageMover.can1,
                                    128 + Math.cos(aa) * bb+wwc1D,//wwc1x,
                                    128 + Math.sin(aa) * bb-wwc1y,
                                    wwc2x,wwc2y,
                                    - wwc1x,
                                    - wwc1y,
                                    wwc2x,wwc2y
                                );
                        }else{
                            var aaa;
                            if(paint.useDirection){
                                aaa = mouseBrush.directionAccum;
                            }else{
                                aaa = angAdd;
                            }
                            ctx.setTransform(1,0,0,1,x + dx * i | 0  ,y + dy * i | 0 );
                            ctx.rotate(aaa);
                            ctx.drawImage(imageMover.can1,
                                (128.5 + Math.cos(aa) * bb-wwc1x) | 0,
                                (128.5 + Math.sin(aa) * bb-wwc1y) | 0,
                                wwc2x,wwc2y,
                                -wwc1x,
                                -wwc1y,
                                wwc2x,wwc2y
                            );
                        }
                    }
                }else{
                    for(var i = start; i < count; i += step){
                        if(paint.antiAlias){
                            xx = x + dx * i;
                            yy = y + dy * i;
                            img = imageMover.sample(xx-dxs,yy-dys,ctx.canvas, w, brushMax,mouseBrush.directionAccum);
                            if(paint.useDirection){
                                ctx.setTransform(1,0,0,1,xx,yy);
                                ctx.rotate(mouseBrush.directionAccum );
                                ctx.drawImage(img,128-w,128-w,wwc2,wwc2,-w,-w,wwc2,wwc2);
                            }else{
                                ctx.setTransform(1,0,0,1,xx,yy);
                                    ctx.rotate(angAdd);
                                    ctx.drawImage(img,128-w,128-w,wwc2,wwc2,-w,-w,wwc2,wwc2);
                            }
                        }else{
                            xx = (x + dx * i + 0.5) | 0;
                            yy = (y + dy * i + 0.5) | 0;
                            if(lastX !== xx || lastY !== yy){
                                if(lastX === undefined){
                                    img = imageMover.sample((xx-dxs+0.5)|0,(yy-dys+0.5)|0,ctx.canvas, w, brushMax,mouseBrush.directionAccum);
                                }else{
                                    img = imageMover.sample((lastX+0.5)|0,(lastY+0.5)|0,ctx.canvas, w, brushMax,mouseBrush.directionAccum);
                                }
                                lastX = xx;
                                lastY = yy;
                                if(paint.useDirection){
                                    ctx.setTransform(1,0,0,1,xx,yy);
                                    ctx.rotate(mouseBrush.directionAccum);
                                    ctx.drawImage(img,128-w,128-w,wwc2,wwc2,-w,-w,wwc2,wwc2);
                                }else{
                                    ctx.setTransform(1,0,0,1,xx,yy);
                                    ctx.rotate(angAdd);
                                    ctx.drawImage(img,128-w,128-w,wwc2,wwc2,-w,-w,wwc2,wwc2);
                                }
                            }
                        }
                    }
                }
            }
        }
        spr.key._lx = spr.key.lx;
        spr.key._ly = spr.key.ly;
    }
    function shaped(spr,ctx, restore){
        if(!spr.image.restored && restore){
            spr.image.restore();
        }
         setColors(spr,ctx);
        var r = paint.sliders.widthFade;
        var rChange = 0;
        var sizeRange = (brushMax - brushMin) / 2;
        var minS = brushMin/ 2;
        var minSChange = 0;
        var speedSize = 1;
        var speedChange
        if(paint.useSpeed){
            //log("speed : " + mouseBrush.speed + " root " +( Math.sqrt(mouseBrush.speed) + 1));
            //curves.B(Math.min(30,Math.sqrt(mouseBrush.speed) + 1) / 30)
            speedSize = curves.B(Math.min(30,mouseBrush.speedSmooth + 1) / 30)
            var speedSizeA = curves.B(Math.min(30,mouseBrush.speedSmooth + mouseBrush.speedChange + 1) / 30)
            minSChange = speedSizeA * sizeRange - speedSize * sizeRange;
            minS = speedSize * sizeRange + minS;
            rChange = r * speedSizeA - r * speedSize;
            r *= speedSize;
            sizeRange *= speedSize;
        }
        var dx,dy,x,y;
         var dx,dy,x,y,step = 0;
        var img;
        if((paint.useSpeed && !curves.A.isRandom) || firstDownCommon || (paint.changed && mouse.button === 0)){
            if(curves.A.isRandom){
                img = imageMover.createBrush(brushMin*2, brushMax,ctx.fillStyle);
            }else{
                img = imageMover.createBrush(minS*2, brushMax,ctx.fillStyle);
            }
            firstDownCommon = false;
            paint.changed = false;
        }else{
            img = imageMover.can1;
        }
        const randColor = paint.colorBlend || paint.randColor;
        x = spr.key._lx;
        y = spr.key._ly;
        dx = spr.key.lx - spr.key._lx;
        dy = spr.key.ly - spr.key._ly;
        var len = Math.sqrt(dx * dx + dy * dy) + 0.00001;
        var count = 1 ;
        var start = 0;
        if(mouse.button === 0){
              if( paint.sliders.brush.step > 0){
                step = 0.5
            }else{
                step = 0.5;
                if(paint.sliders.curveStep > 0){
                    step *= paint.sliders.curveStep;
                    count += step/2
                    if (!firstDown){
                        if (len < paint.sliders.curveStep) { return }
                        start += step;
                    }
                }
            }
        }else{
             if( paint.sliders.brush.step > 0){
                step = 1/ paint.sliders.brush.step;//Math.min(30, paint.sliders.brush.step);
            }else{
                step = 1 / (len > 1 ? len : 1);
                if(paint.sliders.curveStep > 0){
                    step *= paint.sliders.curveStep;
                    count += step/2
                    if (!firstDown){
                        if (len < paint.sliders.curveStep) { return }
                        start += step;
                    }
                }
            }
        }
        var time = performance.now();
        if(paint.sizeBlend || randColor){
            sizeRange = paint.sizeBlend ? sizeRange : 0;
            if(spraying){
                if(!paint.sizeBlend && minS * 2 <= 1) {
                    var wwc2 = minS * 2;
                    if(paint.antiAlias){
                        for(var i = start; i < count; i += step){
                            var a = Math.random() * Math.PI * 2;
                            var b = curves.spraySpread(Math.random()) * (r + rChange * i);
                            if(paint.useAlphaDist) { ctx.globalAlpha = curves.sprayAlpha(b / (r + rChange * i)) * alpha }
                            if (mouse.button === 1) { ctx.fillStyle = colours.colorRange[curves.sprayColor(Math.random()) * 255 | 0] }
                            else { ctx.fillStyle = colours.colorRange[(1-curves.sprayColor(Math.random())) * 255 | 0] }
                            ctx.fillRect(
                                Math.cos(a) * b + x + dx * i-minS,
                                Math.sin(a) * b + y + dy * i-minS,
                                wwc2,wwc2
                            );
                        }
                    }else{
                        wwc2 = wwc2+0.5|0;
                        for(var i = start; i < count; i += step){
                            var a = Math.random() * Math.PI * 2;
                            var b = curves.spraySpread(Math.random()) * (r + rChange * i);
                            if(paint.useAlphaDist) { ctx.globalAlpha = curves.sprayAlpha(b / (r + rChange * i)) * alpha }
                            if(mouse.button === 1) { ctx.fillStyle = colours.colorRange[curves.sprayColor(Math.random()) * 255 | 0] }
                            else { ctx.fillStyle = colours.colorRange[(1-curves.sprayColor(Math.random())) * 255 | 0] }
                            ctx.fillRect(
                                Math.cos(a) * b + x + dx * i-minS + 0.5 | 0,
                                Math.sin(a) * b + y + dy * i-minS + 0.5 | 0,
                                wwc2,wwc2
                            );
                        }
                    }
                }else{
                    if(paint.useDirection){
                        for(var i = start; i < count; i += step){
                            var a = Math.random() * Math.PI * 2;
                            var b = curves.spraySpread(Math.random()) * r;
                            var w = paint.sizeBlend ? curves.spraySize(Math.random()) * sizeRange + (minS + minSChange * i) : (minS + minSChange * i) ;
                            xx = Math.round(Math.cos(a) * b + (x + dx * i));
                            yy = Math.round(Math.sin(a) * b + (y + dy * i));
                            if(paint.useAlphaDist) { ctx.globalAlpha = curves.sprayAlpha(b / r) * alpha }
                            var wwc2 = w * 2;
                            if(randColor){
                                if(mouse.button === 1){ imageMover.resizeBrush(w, brushMax, colours.colorRange[curves.sprayColor(Math.random()) * 255 | 0]) }
                                else { imageMover.resizeBrush(w, brushMax, colours.colorRange[(1-curves.sprayColor(Math.random())) * 255 | 0]) }
                            }else{
                                imageMover.resizeBrush(w, brushMax,ctx.fillStyle);
                            }
                            ctx.setTransform(1,0,0,1,xx,yy);
                            ctx.rotate(mouseBrush.direction);
                            ctx.drawImage(img,128-w,128-w,wwc2,wwc2,-w,-w,wwc2,wwc2);
                        }
                    }else{
                        for(var i = start; i < count; i += step){
                            var a = Math.random() * Math.PI * 2;
                            var b = curves.spraySpread(Math.random()) * (r + rChange * i);
                            if(paint.useAlphaDist) { ctx.globalAlpha = curves.sprayAlpha(b / (r + rChange * i)) * alpha }
                            var w = paint.sizeBlend ? curves.spraySize(Math.random()) * sizeRange + (minS + minSChange * i) : (minS + minSChange * i) ;
                            xx = Math.round(Math.cos(a) * b + (x + dx * i));
                            yy = Math.round(Math.sin(a) * b + (y + dy * i));
                            var wwc2 = w * 2;
                            if(randColor){
                                if(mouse.button === 1){ imageMover.resizeBrush(w, brushMax, colours.colorRange[curves.sprayColor(Math.random()) * 255 | 0]) }
                                else { imageMover.resizeBrush(w, brushMax, colours.colorRange[(1-curves.sprayColor(Math.random())) * 255 | 0]) }
                            }else{
                                imageMover.resizeBrush(w, brushMax,ctx.fillStyle);
                            }
                            ctx.drawImage(img,128-w,128-w,wwc2,wwc2,xx-w,yy-w,wwc2,wwc2);
                        }
                    }
                }
            }else{
                if(!paint.sizeBlend && minS * 2 <= 1) {
                    var wwc2 = minS * 2;
                    if(paint.antiAlias){
                        for(var i = start; i < count; i += step){
                            var xx = x + dx * i;
                            var yy = y + dy * i;
                            if (mouse.button === 1) { ctx.fillStyle = colours.colorRange[curves.B(Math.random()) * 255 | 0] }
                            else { ctx.fillStyle = colours.colorRange[(1-curves.B(Math.random())) * 255 | 0] }
                            ctx.fillRect(xx-minS,yy-minS,wwc2,wwc2);
                        }
                    }else{
                        wwc2 = wwc2+0.5|0;
                        for(var i = start; i < count; i += step){
                            if (mouse.button === 1) { ctx.fillStyle = colours.colorRange[curves.B(Math.random()) * 255 | 0] }
                            else { ctx.fillStyle = colours.colorRange[(1-curves.B(Math.random())) * 255 | 0] }
                            ctx.fillRect((x + dx * i-minS+0.5)|0,(y + dy * i-minS+0.5)|0,wwc2,wwc2);
                        }
                    }
                }else{
                    if(paint.useDirection){
                        for(var i = start; i < count; i += step){
                            var w = paint.sizeBlend ? curves.C(Math.random()) * sizeRange + (minS + minSChange * i)  : (minS + minSChange * i);
                            var xx = x + dx * i;
                            var yy = y + dy * i;
                            var wwc2 = w * 2;
                            if(randColor){
                                if(mouse.button === 1){ imageMover.resizeBrush(w, brushMax, colours.colorRange[curves.B(Math.random()) * 255 | 0]) }
                                else { imageMover.resizeBrush(w, brushMax, colours.colorRange[(1-curves.B(Math.random())) * 255 | 0]) }
                            }else{
                                imageMover.resizeBrush(w, brushMax,ctx.fillStyle);
                            }
                            ctx.setTransform(1,0,0,1,xx,yy);
                            ctx.rotate(mouseBrush.direction);
                            ctx.drawImage(img,128-w,128-w,wwc2,wwc2,-w,-w,wwc2,wwc2);
                        }
                    }else{
                        for(var i = start; i < count; i += step){
                            var w = paint.sizeBlend ? curves.C(Math.random()) * sizeRange + (minS + minSChange * i)  : (minS + minSChange * i);
                            var xx = x + dx * i;
                            var yy = y + dy * i;
                            var wwc2 = w * 2;
                            if(randColor){
                                if(mouse.button === 1){ imageMover.resizeBrush(w, brushMax, colours.colorRange[curves.B(Math.random()) * 255 | 0]) }
                                else { imageMover.resizeBrush(w, brushMax, colours.colorRange[(1-curves.B(Math.random())) * 255 | 0]) }
                            }else{
                                imageMover.resizeBrush(w, brushMax,ctx.fillStyle);
                            }
                            ctx.drawImage(img,128-w,128-w,wwc2,wwc2,xx-w,yy-w,wwc2,wwc2);
                        }
                    }
                }
            }
        }else{
            var w = minS;
            var wwc2 = w * 2;
            if(wwc2 <= 1){
                //ctx.beginPath();
                if(spraying){
                    if(paint.antiAlias){
                        for(var i = start; i < count; i += step){
                            var a = Math.random() * Math.PI * 2;
                            var b = curves.spraySpread(Math.random()) * (r + rChange * i);
                            if(paint.useAlphaDist) { ctx.globalAlpha = curves.sprayAlpha(b / (r + rChange * i)) * alpha }
                            ctx.fillRect(
                                Math.cos(a) * b + x + dx * i-w,
                                Math.sin(a) * b + y + dy * i-w,
                                wwc2,wwc2
                            );
                        }
                    }else{
                        wwc2 = wwc2+0.5|0;
                        for(var i = start; i < count; i += step){
                            var a = Math.random() * Math.PI * 2;
                            var b = curves.spraySpread(Math.random()) * (r + rChange * i);
                            if(paint.useAlphaDist) { ctx.globalAlpha = curves.sprayAlpha(b / (r + rChange * i)) * alpha }
                            //ctx.fillRect(xx-w,yy-w,wwc2,wwc2);
                            ctx.fillRect(
                                Math.cos(a) * b + x + dx * i-w + 0.5 | 0,
                                Math.sin(a) * b + y + dy * i-w + 0.5 | 0,
                                wwc2,wwc2
                            );
                        }
                    }
                }else{
                    if(paint.antiAlias){
                        for(var i = start; i < count; i += step){
                            var xx = x + dx * i;
                            var yy = y + dy * i;
                            ctx.fillRect(xx-w,yy-w,wwc2,wwc2);
                        }
                    }else{
                        wwc2 = wwc2+0.5|0;
                        for(var i = start; i < count; i += step){
                            ctx.fillRect((x + dx * i-w+0.5)|0,(y + dy * i-w+0.5)|0,wwc2,wwc2);
                        }
                    }
                }
                //ctx.fill();
            }else{
                if(paint.useDirection){
                    if(spraying){
                        for(var i = start; i < count; i += step){
                            var a = Math.random() * Math.PI * 2;
                            var b = curves.spraySpread(Math.random()) * (r + rChange * i);
                            if(paint.useAlphaDist) { ctx.globalAlpha = curves.sprayAlpha(b / (r + rChange * i)) * alpha }
                            xx = Math.round(Math.cos(a) * b + (x + dx * i));
                            yy = Math.round(Math.sin(a) * b + (y + dy * i));
                            ctx.setTransform(1,0,0,1,xx,yy);
                            ctx.rotate(mouseBrush.direction);
                            ctx.drawImage(img,128-w,128-w,wwc2,wwc2,-w,-w,wwc2,wwc2);
                        }
                    }else{
                        for(var i = start; i < count; i += step){
                            var xx = x + dx * i;
                            var yy = y + dy * i;
                            ctx.setTransform(1,0,0,1,xx,yy);
                            ctx.rotate(mouseBrush.direction);
                            ctx.drawImage(img,128-w,128-w,wwc2,wwc2,-w,-w,wwc2,wwc2);
                        }
                    }
                }else{
                    if(spraying){
                        for(var i = start; i < count; i += step){
                            var a = Math.random() * Math.PI * 2;
                            var b = curves.spraySpread(Math.random()) * (r + rChange * i);
                            xx = Math.round(Math.cos(a) * b + (x + dx * i));
                            yy = Math.round(Math.sin(a) * b + (y + dy * i));
                            if(paint.useAlphaDist) { ctx.globalAlpha = curves.sprayAlpha(b / (r + rChange * i)) * alpha }
                            ctx.drawImage(img,128-w,128-w,wwc2,wwc2,xx-w,yy-w,wwc2,wwc2);
                        }
                    }else{
                        for(var i = start; i < count; i += step){
                            var xx = x + dx * i;
                            var yy = y + dy * i;
                            ctx.drawImage(img,128-w,128-w,wwc2,wwc2,xx-w,yy-w,wwc2,wwc2);
                        }
                    }
                }
            }
        }
        spr.key._lx = spr.key.lx;
        spr.key._ly = spr.key.ly;
    }
    function curve(spr,ctx, restore){
        if(!spr.image.restored && restore){
            spr.image.restore();
        }
            finishCurve(spr,ctx);
            return;
        setColors(spr,ctx);
        ctx.lineWidth = brushMin * spr.key.cross;
        ctx.lineCap = "round";
        ctx.beginPath();
        if(spr.key._lx !== undefined){
            ctx.lineTo(spr.key._lx, spr.key._ly);
            ctx.lineTo(spr.key.lx, spr.key.ly);
        }else{
            ctx.lineTo(spr.key.lx, spr.key.ly);
            ctx.lineTo(spr.key.lx+0.001, spr.key.ly);
        }
        ctx.stroke();
        spr.key._lx = spr.key.lx;
        spr.key._ly = spr.key.ly;
    }
    function curveAlias(spr,ctx, restore){
        if(!spr.image.restored && restore){
            spr.image.restore();
        }
            finishCurveAlias(spr,ctx);
            return;
        setColors(spr,ctx);
        var w = brushMin;
        var sizeRange = (brushMax - brushMin);
        var minS = brushMin;
        var img = imageMover.aliasCircle(w,ctx.fillStyle)
        ctx.beginPath();
        var x = spr.key._lx
        var y = spr.key._ly
        var x1 = spr.key.lx - x;
        var y1 = spr.key.ly - y;
        var dist = ((x1 * x1 + y1 * y1) ** 0.5) + 0.001;
        x1 /= dist;
        y1 /= dist;
        for(var i = 0; i < dist; i ++){
            var ww = paint.sizeBlend ? curves.C(Math.random()) * sizeRange + minS : w
            const size = Math.max(1, ww  | 0);
            const offset = size / 2;
            var xx = Math.round(x - offset);
            var yy = Math.round(y - offset);
            var xs = Math.floor(128 - offset);
            ctx.drawImage(img,xs, xs, offset * 2,offset * 2,xx,yy,offset * 2,offset * 2)
            //ctx.rect(xx, yy, size, size);
            x += x1;
            y += y1;
        }
        ctx.fill();
        spr.key._lx = spr.key.lx;
        spr.key._ly = spr.key.ly;
    }
    function finishCurveAlias(spr, ctx){
        var sizeRange, size, offset, path, x,y,x1,y1,l,l1,tx,ty,sx,sy,dx,dy,e2,er,end,dist,ll,x2,y2,prev,prevp;
        
        sizeRange = (brushMax - brushMin);

        size = Math.max(1, brushMin | 0);
        offset = size / 4 | 0;
        path = imageMover.aliasCircle(size)
        if(!blendColors && size <= 2){ ctx.beginPath() }
        if(mouse.button === 0){
            if(!spr.image.restored){
                spr.image.restore();
            }
            setColors(spr,ctx);
            x1 = spr.key.lx - offset | 0;
            y1 = spr.key.ly - offset | 0;            
            paint.sizeBlend ? offset = (size = Math.max(1, curves.C(0) * sizeRange + brushMin | 0)) / 4 | 0 : 0;
            if(blendColors){
                ctx.fillStyle = colours.colorRange[curves.B(0) * 255 | 0];
                ctx.fillRect(x1 , y1 , size, size);
            }else{
                if(size > 2){
                    ctx.setTransform(1,0,0,1,x1,y1);
                    ctx.fill(path);
                }else{
                    ctx.rect(x1 , y1 , size, size);
                }
            }         
            if(!blendColors && size <= 2){ctx.fill()  }
            return;
        }       

        setColors(spr,ctx);

        
        strokes.each((p, pt, i) => {
            if(i === 0){
                spr.key.strokeToLocal(p, locPointS[0]);
                prev = locPointS[0];
                prevp = p;
            }else{
                const lp = locPointS[i%2]
                spr.key.strokeToLocal(p, lp);

                x1 = x = prev[0] - offset | 0;
                y1 = y = prev[1] - offset | 0;
                tx = ty = 0;
                x2 = lp[0] - offset | 0;
                y2 = lp[1] - offset | 0;
                dx = Math.abs(x2 - x1);
                sx = x1 < x2 ? 1 : -1;
                dy = -Math.abs(y2 - y1);
                sy = y1 < y2 ? 1 : -1;
                er = dx + dy;
                end = false;
                dist = (dx * dx + dy * dy) ** 0.5;
                l = prevp[3];
                ll = p[3] - l;
                while (!end) {
                    const d = ((tx * tx + ty * ty) ** 0.5) / dist * ll;
                    paint.sizeBlend ? offset = (size = Math.max(1, curves.C(l + ll) * sizeRange + brushMin | 0)) / 4 | 0 : 0;
                    if(blendColors){
                        ctx.fillStyle = colours.colorRange[curves.B(l+ll) * 255 | 0];
                        ctx.fillRect(x1 , y1 , size, size);
                    }else{
                        if(size > 2){
                            ctx.setTransform(1,0,0,1,x1,y1);
                            ctx.fill(path);
                        }else{
                            ctx.rect(x1 , y1 , size, size);
                        }
                    }
                    if (x1 === x2 && y1 === y2) {
                        end = true;
                    } else {
                        e2 = 2 * er;
                        if (e2 > dy) {
                            er += dy;
                            x1 += sx;
                            tx += sx;
                        }
                        if (e2 <= dx) {
                            er += dx;
                            y1 += sy;
                            ty += sy
                        }
                    }
                }

                prev = lp;
                prevp = p;
            }
        });
        if(!blendColors && size <= 2){
            ctx.fill();
        }
        
   
        
    }
    function finishCurve(spr, ctx){
        setColors(spr,ctx);
        if(paint.sizeBlend && brushMin !== brushMax){
            var m = brushMin * spr.key.cross
            var r = (brushMax * spr.key.cross) - m;
            const lp = locPoint;
            ctx.beginPath();
            strokes.each((p, pt, i) => {
                spr.key.strokeToLocal(p, pt);
                var d = curves.C(p[3]) * r + m;
                pt[2] *= d;
                pt[3] *= d;
                ctx.lineTo(pt[0] - pt[3], pt[1] + pt[2]);
            });
            strokes.eachR((p,pt, i) => {
                ctx.lineTo(pt[0] + pt[3], pt[1] - pt[2]);
            })
            ctx.fill();
        }else{
            ctx.lineWidth = brushMin * spr.key.cross;
            ctx.lineCap = "round";
            ctx.lineJoin = "round";
            ctx.beginPath();
            var prev;
            strokes.each((p, pt, i) => {
                const lp = locPointS[i%2];
                spr.key.strokeToLocalBez(p,lp);
                if(i === 0){
                    ctx.lineTo(lp[0], lp[1]);
                }else{
                    if(!isNaN(prev[4])){
                        ctx.bezierCurveTo(prev[4],prev[5],prev[6],prev[7],lp[0],lp[1])
                        //ctx.lineTo(pt[0], pt[1]);
                    }else{
                        ctx.lineTo(lp[0], lp[1]);
                    }
                }
                prev = lp;
            });
            ctx.stroke();
        }
    }
    function spray(spr,ctx, restore){
        if(!spr.image.restored && restore){
            spr.image.restore();
        }
        setColors(spr,ctx);
        var w = brushMin * spr.key.cross;;
        var r = paint.sliders.widthFade * spr.key.cross;
        var sizeRange = (brushMax - brushMin) * spr.key.cross;
        var minS = brushMin *  spr.key.cross;
        var dx,dy,x,y;
        var step = 1/ paint.sliders.brush.step;
        if(spr.key._lx !== undefined){
            if(!paint.colorBlend){ ctx.beginPath() }
            x = spr.key._lx;
            y = spr.key._ly;
            dx = spr.key.lx - spr.key._lx;
            dy = spr.key.ly - spr.key._ly;
            var len = Math.sqrt(dx * dx + dy * dy) + 0.01;
            step = 1/paint.sliders.brush.step;
            if(paint.antiAlias){
                for(var i = 0; i < 1; i += step){
                    var a = Math.random() * Math.PI * 2;
                    var b = curves.A(Math.random()) * r;
                    var ww = (paint.sizeBlend ? curves.C(Math.random()) * sizeRange + minS : w)/2;
                    var xx = Math.cos(a) * b + (x + dx * i);
                    var yy = Math.sin(a) * b + (y + dy * i);
                    if(paint.colorBlend){
                        ctx.fillStyle = colours.colorRange[curves.B(Math.random()) * 255 | 0];
                        ctx.beginPath();
                        ctx.arc(xx,yy,ww ,0,Math.PI*2);
                        ctx.fill();
                    }else{
                        ctx.moveTo(xx + ww,yy);
                        ctx.arc(xx,yy,ww ,0,Math.PI*2);
                    }
                }
            }else{
                for(var i = 0; i < 1; i += step){
                    var a = Math.random() * Math.PI * 2;
                    var b = curves.A(Math.random()) * r;
                    var ww = (paint.sizeBlend ? curves.C(Math.random()) * sizeRange + minS : w);
                    const size = Math.max(1, ww * spr.key.cross | 0);
                    const offset = size / 2;
                    var xx = Math.round(Math.cos(a) * b + (x + dx * i) - offset);
                    var yy = Math.round(Math.sin(a) * b + (y + dy * i) - offset);
                    if(paint.colorBlend){
                        ctx.fillStyle = colours.colorRange[curves.B(Math.random()) * 255 | 0];
                        ctx.fillRect(xx, yy, size, size);
                    }else{
                        ctx.rect(xx, yy, size, size);
                    }
                }
            }
            if(!paint.colorBlend){ ctx.fill() }
        }
        spr.key._lx = spr.key.lx;
        spr.key._ly = spr.key.ly;
    }
    function rectangleAlias(spr,ctx){
        if(!spr.image.restored){
            spr.image.restore();
        }
        setColors(spr,ctx,paint.fillMode === 2)
        if(paint.gridGuides || paint.gridGuidesSnap){
            if(mouse.cMouse.gridSpritesCount > 1){
                var len = mouse.cMouse.gridSpritesCount;
                var i,j;
                if(mouse.cMouse.gridSpriteALocked !== null){
                    i = mouse.cMouse.gridSpriteALocked;
                    if (mouse.cMouse.gridSpriteBLocked !== null) { j =  mouse.cMouse.gridSpriteBLocked }
                    else { j =  mouse.cMouse.gridSpritesMinIndex }
                }else{
                    i = mouse.cMouse.gridSpritesMinIndex;
                    j = (i + 1) % len;
                }
                const pms = mouse.cMouse.gridSprites[j];
                const ms = mouse.cMouse.gridSprites[i];
                if(pms && ms){
                    const pg = pms.grid;
                    const g = ms.grid;
                    pms.getGridLine();
                    ms.getGridLine(mouse.cMouse.rox,mouse.cMouse.roy);
                    spr.key.toLocalPoint(getLineIntercept(pg, g, workPointA));
                    ms.getGridLine();
                    pms.getGridLine(mouse.cMouse.rox,mouse.cMouse.roy);
                    spr.key.toLocalPoint(getLineIntercept(pg, g, workPointB));
                    workPointC.x = mouse.cMouse.rox;
                    workPointC.y = mouse.cMouse.roy;
                    spr.key.toLocalPoint(workPointC);
                    ctx.beginPath();
                    ctx.moveTo(spr.key._lx + 0.5, spr.key._ly + 0.5)
                    ctx.lineTo(workPointA.x + 0.5, workPointA.y + 0.5)
                    ctx.lineTo(workPointC.x + 0.5, workPointC.y + 0.5)
                    ctx.lineTo(workPointB.x + 0.5, workPointB.y + 0.5)
                    ctx.closePath();
                    if(paint.fillMode === 1 || paint.fillMode === 2)  { ctx.fill() }
                    colours.setContextDrawMode(ctx, nextDrawMode);
                    if(paint.fillMode === 0 || paint.fillMode === 2)  {
                        ctx.fillStyle = ctx.strokeStyle;
                        ctx.beginPath();
                        renderFunction.alias.line(ctx, spr.key._lx + 0.5, spr.key._ly + 0.5, workPointA.x + 0.5, workPointA.y + 0.5, true, false);
                        renderFunction.alias.line(ctx, workPointA.x + 0.5, workPointA.y + 0.5, workPointC.x + 0.5, workPointC.y + 0.5, true, false);
                        renderFunction.alias.line(ctx, workPointC.x + 0.5, workPointC.y + 0.5, workPointB.x + 0.5, workPointB.y + 0.5, true, false);
                        renderFunction.alias.line(ctx, workPointB.x + 0.5, workPointB.y + 0.5, spr.key._lx + 0.5, spr.key._ly + 0.5, true, false);
                        ctx.fill();
                    }
                    return;
                }
            }
        }else{
            const s = Math.max(1,brushMin | 0);
            const o = s / 2;
            var x = Math.round(Math.min(spr.key._lx, spr.key.lx) - o);
            var y = Math.round(Math.min(spr.key._ly, spr.key.ly) - o);
            var w = Math.round(Math.max(spr.key._lx,spr.key.lx) - x + o)-s;
            var h = Math.round(Math.max(spr.key._ly,spr.key.ly) - y + o)-s;
            if (paint.fillMode === 1) {
                x = Math.floor(Math.min(spr.key._lx, spr.key.lx));
                y = Math.floor(Math.min(spr.key._ly, spr.key.ly));
                w = Math.floor(Math.max(spr.key._lx, spr.key.lx) + 1 - x);
                h = Math.floor(Math.max(spr.key._ly, spr.key.ly) + 1 - y);
                ctx.beginPath();
                ctx.rect(x, y, w, h);
                ctx.fill()
            } else if (paint.fillMode === 2)  {
                ctx.beginPath();
                ctx.rect(x + s, y + s, w, h);
                ctx.fill()
            }
             colours.setContextDrawMode(ctx, nextDrawMode);
            if(paint.fillMode === 0 || paint.fillMode === 2)  {
                ctx.fillStyle = ctx.strokeStyle;
                ctx.beginPath();
                ctx.rect(x, y, w + s , s);
                ctx.rect(x, y + h, w + s, s);
                ctx.rect(x, y + s, s, h);
                ctx.rect(x + w, y + s, s, h);
                ctx.fill();
            }
        }
    }
    function rectangle(spr,ctx){
        if(!spr.image.restored){
            spr.image.restore();
        }
        setColors(spr,ctx,paint.fillMode === 2);
        ctx.lineWidth = brushMin;
        ctx.lineJoin = "miter";
        ctx.beginPath();
        if(paint.gridGuides || paint.gridGuidesSnap){
            if(mouse.cMouse.gridSpritesCount > 1){
                var len = mouse.cMouse.gridSpritesCount;
                var i,j;
                if(mouse.cMouse.gridSpriteALocked !== null){
                    i = mouse.cMouse.gridSpriteALocked;
                    if (mouse.cMouse.gridSpriteBLocked !== null) { j =  mouse.cMouse.gridSpriteBLocked }
                    else { j =  mouse.cMouse.gridSpritesMinIndex }
                }else{
                    i = mouse.cMouse.gridSpritesMinIndex;
                    j = (i + 1) % len;
                }
                const pms = mouse.cMouse.gridSprites[j];
                const ms = mouse.cMouse.gridSprites[i];
                if(pms && ms){
                    const pg = pms.grid;
                    const g = ms.grid;
                    pms.getGridLine();
                    ms.getGridLine(mouse.cMouse.rox,mouse.cMouse.roy);
                    spr.key.toLocalPoint(getLineIntercept(pg, g, workPointA));
                    ms.getGridLine();
                    pms.getGridLine(mouse.cMouse.rox,mouse.cMouse.roy);
                    spr.key.toLocalPoint(getLineIntercept(pg, g, workPointB));
                    workPointC.x = mouse.cMouse.rox;
                    workPointC.y = mouse.cMouse.roy;
                    spr.key.toLocalPoint(workPointC);
                    ctx.moveTo(spr.key._lx + 0.5, spr.key._ly + 0.5)
                    ctx.lineTo(workPointA.x + 0.5, workPointA.y + 0.5)
                    ctx.lineTo(workPointC.x + 0.5, workPointC.y + 0.5)
                    ctx.lineTo(workPointB.x + 0.5, workPointB.y + 0.5)
                    ctx.closePath();
                }
            }
        }else{
            ctx.rect(
                Math.min(spr.key._lx, spr.key.lx) + 0.5,
                Math.min(spr.key._ly, spr.key.ly) + 0.5,
                Math.abs(spr.key._lx - spr.key.lx),
                Math.abs(spr.key._ly - spr.key.ly)
            );
        }
        if(paint.fillMode === 1 || paint.fillMode === 2)  { ctx.fill() }
        colours.setContextDrawMode(ctx, nextDrawMode);
        if(paint.fillMode === 0 || paint.fillMode === 2)  { ctx.stroke() }
    }
    function circle(spr,ctx){
        if(!spr.image.restored){ spr.image.restore() }
        setColors(spr,ctx,paint.fillMode === 2)
        ctx.lineWidth = brushMin;
        ctx.lineCap = "round";
        ctx.beginPath();
        if(paint.gridGuides || paint.gridGuidesSnap){
            if(mouse.cMouse.gridSpritesCount > 1){
                var len = mouse.cMouse.gridSpritesCount;
                var i,j;
                if(mouse.cMouse.gridSpriteALocked !== null){
                    i = mouse.cMouse.gridSpriteALocked;
                    if (mouse.cMouse.gridSpriteBLocked !== null) { j =  mouse.cMouse.gridSpriteBLocked }
                    else { j =  mouse.cMouse.gridSpritesMinIndex }
                }else{
                    i = mouse.cMouse.gridSpritesMinIndex;
                    j = (i + 1) % len;
                }
                const pms = mouse.cMouse.gridSprites[j];
                const ms = mouse.cMouse.gridSprites[i];
                if(pms && ms){
                    const pg = pms.grid;
                    const g = ms.grid;
                    var angY = pg.angle;
                    var angX = g.angle;
                    var angY1 = pms.getGridLine(mouse.cMouse.rox,mouse.cMouse.roy) - angY;
                    var angX1 = ms.getGridLine(mouse.cMouse.rox,mouse.cMouse.roy) - angX;
                    workPointC.x = mouse.cMouse.rox;
                    workPointC.y = mouse.cMouse.roy;
                    spr.key.toLocalPoint(workPointC);

                    var radX = (g.p4.x - g.p3.x) / 2;
                    var radY = (pg.p4.x - pg.p3.x) / 2;
                    radX = Math.max(radX,radY);
                    radY = Math.max(radX,radY);
                    var rad = Math.max( Math.abs(radX), Math.abs(radY))
                    var ax = angX + angX1 * 0.5;
                    var ay = angY + angY1 * 0.5;
                    var cx = spr.key._lx;// + radX * Math.cos(ax) + radY * Math.cos(ay);
                    var cy = spr.key._ly;// + radX * Math.sin(ax) + radY * Math.sin(ay);
                    var dist = 1 / (rad * Math.PI);
                    for(var k = 0; k < 1; k += dist){
                        var ang = k * Math.PI*2;
                        var px = Math.cos(ang);
                        var py = Math.sin(ang);
                        var ax = ((px + 1) / 2) * angX1 + angX;
                        var ay = ((py + 1) / 2) * angY1 + angY;
                        var xdx = Math.cos(ax)
                        var xdy = Math.sin(ax)
                        var ydx = Math.cos(ay)
                        var ydy = Math.sin(ay)
                        px = px * radX;
                        py = py * radY;
                        var x = px * xdx + py * ydx + cx;
                        var y = px * xdy + py * ydy + cy;
                        ctx.lineTo(x,y);
                    }
                    ctx.closePath();
                }
            }
        }else{
            var radius = ((spr.key._lx- spr.key.lx) ** 2 + (spr.key._ly- spr.key.ly) ** 2) ** 0.5;
            ctx.arc(spr.key._lx, spr.key._ly,radius,0,Math.PI * 2);
        }
        if(paint.fillMode === 1 || paint.fillMode === 2)  { ctx.fill() }
        colours.setContextDrawMode(ctx, nextDrawMode);
        if(paint.fillMode === 0 || paint.fillMode === 2)  { ctx.stroke() }
    }
    function circleAlias(spr,ctx){
        if(!spr.image.restored){ spr.image.restore() }
        setColors(spr,ctx,paint.fillMode === 2);
        var radius = (((spr.key._lx- spr.key.lx) ** 2 + (spr.key._ly- spr.key.ly) ** 2) ** 0.5) | 0;
        var sizeRange = brushMax - brushMin;
        var minS = brushMin;
        var ww = paint.sizeBlend ? curves.C(Math.random()) * sizeRange + minS : minS
        const size = Math.max(1, ww| 0);
        const offset = size / 2 | 0;
        var x = radius-1;
        var y = 0;
        var dx = 1;
        var dy = 1;
        var err = dx - (radius << 1);
        var x0 = spr.key._lx | 0;
        var y0 = spr.key._ly | 0;
        var x1 = x0 + 1;
        var y1 = y0 + 1;
        if(paint.fillMode >= 1){
            ctx.beginPath();
            if(radius < smallAliasCirclesFill.length){
                const sc = smallAliasCirclesFill[radius];
                const len = sc.length;
                while(y < len){
                    x = sc[y];
                    ctx.rect(x0 - x, y0 - y, x * 2 + 2, 1);
                    ctx.rect(x0 - x, y1 + y, x * 2 + 2, 1);
                    y ++
                }
            }else{
                var lx = x,ly = y;
                while (x >= y) {
                    ctx.rect(x0 - x, y1 + y, x * 2 + 2, 1);
                    ctx.rect(x0 - x, y0 - y, x * 2 + 2, 1);
                    if(x !== lx){
                        ctx.rect(x0 - ly, y0 - lx, ly * 2 + 2, 1);
                        ctx.rect(x0 - ly, y1 + lx, ly * 2 + 2, 1);
                    }
                    lx = x;
                    ly = y;
                    y++;
                    err += dy;
                    dy += 2;
                    if (err > 0) {
                        x--;
                        dx += 2;
                        err += (-radius << 1) + dx;
                    }
                }
                if(x !== lx){
                    ctx.rect(x0 - ly, y0 - lx, ly * 2 + 1, 1);
                    ctx.rect(x0 - ly, y1 + lx, ly * 2 + 1, 1);
                }
            }
            ctx.fill();
        }
        colours.setContextDrawMode(ctx, nextDrawMode);
        if(paint.fillMode === 0 || paint.fillMode === 2)  {
            ctx.fillStyle = ctx.strokeStyle;
            ctx.beginPath();
            if(radius < smallAliasCirclesStroke.length){
                const sc = smallAliasCirclesStroke[radius];
                const len = sc.length;
                var i = 0;
                while(i < len){
                    x = sc[i];
                    y = sc[i+1];
                    ctx.rect(x0 - x -  offset, y0 - y - offset, size, size);
                    ctx.rect(x1 + x -  offset, y0 - y - offset, size, size);
                    ctx.rect(x0 - x -  offset, y1 + y - offset, size, size);
                    ctx.rect(x1 + x -  offset, y1 + y - offset, size, size);
                    i += 2;
                }
            }else{
                x = radius-1;
                y = 0;
                dx = 1;
                dy = 1;
                err = dx - (radius << 1);
                while (x >= y) {
                    ctx.rect(x1 + x - offset, y1 + y - offset, size, size);
                    ctx.rect(x0 - x - offset, y0 - y - offset, size, size);
                    ctx.rect(x0 - y - offset, y1 + x - offset, size, size);
                    ctx.rect(x1 + x - offset, y0 - y - offset, size, size);
                    if (x > y) {
                        ctx.rect(x1 + y - offset, y1 + x - offset, size, size);
                        ctx.rect(x0 - x - offset, y1 + y - offset, size, size);
                        ctx.rect(x0 - y - offset, y0 - x - offset, size, size);
                        ctx.rect(x1 + y - offset, y0 - x - offset, size, size);
                    }
                    y++;
                    err += dy;
                    dy += 2;
                    if (err > 0) {
                        x--;
                        dx += 2;
                        err += (-radius << 1) + dx;
                    }
                }
            }
            ctx.fill();
        }
    }
    function line(spr,ctx){
        if(!spr.image.restored){
            spr.image.restore();
        }
        setColors(spr,ctx)
        renderFunction.antiAlias.line(ctx,spr.key._lx,spr.key._ly,spr.key.lx,spr.key.ly);
        return;
        ctx.lineWidth = brushMin;
        ctx.lineCap = "round";
        ctx.beginPath();
        if(spr.key._lx !== undefined){
            ctx.lineTo(spr.key._lx, spr.key._ly);
            ctx.lineTo(spr.key.lx, spr.key.ly);
        }else{
            ctx.lineTo(spr.key.lx, spr.key.ly);
            ctx.lineTo(spr.key.lx+0.001, spr.key.ly);
            spr.key._lx = spr.key.lx;
            spr.key._ly = spr.key.ly;
        }
        ctx.stroke();
    }
    function lineAlias(spr, ctx){
        if(!spr.image.restored){
            spr.image.restore();
        }
        setColors(spr,ctx);
        renderFunction.alias.line(ctx,spr.key._lx,spr.key._ly,spr.key.lx,spr.key.ly);
        return;
        var w = brushMin * spr.key.cross;
        var sizeRange = (brushMax - brushMin) * spr.key.cross;
        var minS = brushMin *  spr.key.cross;
        var ww = paint.sizeBlend ? curves.C(0) * sizeRange + minS : w
        var size = Math.max(1, ww| 0);
        var offset = size / 2 ;
        var x,y;
        var x1 = x = Math.round(spr.key._lx  - offset);
        var y1 = y = Math.round(spr.key._ly  - offset);
        var x2 = Math.round(spr.key.lx  - offset);
        var y2 = Math.round(spr.key.ly  - offset);
        var dx = Math.abs(x2 - x1);
        var sx = x1 < x2 ? 1 : -1;
        var dy = -Math.abs(y2 - y1);
        var sy = y1 < y2 ? 1 : -1;
        var er = dx + dy;
        var e2;
        var end = false;
        var dist = (dx * dx + dy * dy) ** 0.5;// ** 0.5;;
        if(!blendColors){
            ctx.beginPath();
        }
        while (!end) {
            const d = ((((x1-x)**2) + ((y1-y)**2)) ** 0.5)/ dist;
            ww = paint.sizeBlend ? curves.C(d) * sizeRange + minS : w
            size = Math.max(1, ww  | 0);
            offset = size / 2 | 0;
            if(blendColors){
                ctx.fillStyle = colours.colorRange[curves.B(d) * 255 | 0];
                ctx.fillRect(x1 , y1 , size, size);
            }else{
                ctx.rect(x1 , y1 , size, size);
            }
            if (x1 === x2 && y1 === y2) {
                end = true;
            } else {
                e2 = 2 * er;
                if (e2 >= dy) {
                    er += dy;
                    x1 += sx;
                }
                if (e2 <= dx) {
                    er += dx;
                    y1 += sy;
                }
            }
        }
        if(!blendColors){
            ctx.fill();
        }
    }
    function lineFeedback(spr,ctx){
        if(!spr.image.restored){
            spr.image.restore();
        }
        setColors(spr,ctx)
        ctx.beginPath();
        ctx.arc(spr.key.lx, spr.key.ly,brushMin / 2, 0, Math.PI * 2);
        spr.key._ly = spr.key._lx = undefined;
        ctx.fill();
    }
    function getColour(){
         sprites.eachDrawableVisual(spr=>{
            if(spr.key.lx >= 0 && spr.key.lx < spr.image.w &&
                spr.key.ly >= 0 && spr.key.ly < spr.image.h){
                if(paint.colorBlend || paint.drawType === commands.paintBrissle){
                    blendColors = true;
                    var r = Math.max(1,Math.ceil(paint.sliders.lengthFade));
                    var rScale = r / Math.max(1,Math.ceil(paint.sliders.widthFade));
                    var xx1 = (spr.key.lx | 0) - r;
                    var yy1 = (spr.key.ly | 0) - r;
                    var dat;

                        dat = spr.image.desc.mirror.ctx.getImageData(xx1,yy1,r * 2, r * 2);

                    const center = r * 4 + (r * 2 * 4 * r);
                    if(dat.data[center] !== undefined && dat.data[center + 3] > 0){
                        colours.setColor(dat.data[center],dat.data[center+1],dat.data[center+2],true);
                        colours.setColor(dat.data[center],dat.data[center+1],dat.data[center+2]);
                    }
                    mainColor = colours.mainColor.css;
                    secondColor = colours.secondColor.css;
                    var x = spr.key.lx | 0;
                    var y = spr.key.ly | 0;
                    var c =0;
                    var i = 0;
                    var d = dat.data;
                    var xdx = Math.cos(mouseBrush.direction);
                    var xdy = Math.sin(mouseBrush.direction);
                    if(paint.drawType === commands.paintBrissle){
                        while(i < hairs.hairCount){
                            var hr = hairs[i++]
                            var xx = hr.x*rScale | 0;
                            var yy = hr.y*rScale | 0;

                            if(xx + x >= 0 && xx + x < spr.image.w && yy + y >= 0 && yy + y < spr.image.h) {
                                var index = ((xx+r) + (yy+r) * (r * 2)) * 4;
                                if(d[index] !== undefined && d[index+ 3] > 0){
                                    if(hr.r === -1 || firstDownCommon){
                                        hr.rr = hr.r = d[index];
                                        hr.gg =  hr.g = d[index+1];
                                         hr.bb = hr.b = d[index+2];
                                         hr.aa = hr.al = d[index+3];
                                        hr.col = "rgb(" + d[index] + "," + d[index+1]  + ","+ d[index+2]  + ")";
                                        hr.blend = 0;
                                    }else{
                                        if(paint.colorBlend){
                                            var b1 = hr.blend/4;
                                            var b = 1-b1;//hr.blend/4;
                                            hr.r = (b * hr.r + b1 * d[index]) | 0;
                                            hr.g = (b * hr.g + b1 * d[index+1])  | 0;
                                            hr.b = (b * hr.b + b1 * d[index+2])  | 0; 
                                            
                                            hr.col = "rgb(" + hr.r + "," + hr.g  + ","+ hr.b  + ")";
                                        }else{
                                            if(hr.blend < -1 || hr.blend > 1){
                                                hr.rr = hr.r;
                                                hr.gg = hr.g;
                                                hr.bb = hr.b;
                                                hr.aa = hr.al;
                                                
                                                 hr.r = d[index];
                                                hr.g = d[index+1];
                                                 hr.b = d[index+2];
                                                 hr.al = d[index+3]; 
                                                 hr.col = "rgb(" + hr.r + "," + hr.g  + ","+ hr.b  + ","+( hr.al /255)+")";

                                                 hr.blend = 0;
                                            }
                                        }
                                            
                                            
                                    }
                                    colours.addToColorRange(i,dat.data[index],dat.data[index+1],dat.data[index+2]);
                                    c++;
                                }else{
                                    hr.col = "rgba(0,0,0,0)";
                                }
                            }
                        }
                    return true;
                    }
                    for(; i < 256; i ++){
                        var a = Math.random() * Math.PI * 2;
                        var b = Math.random() * (r-1);
                        var xx = Math.round(Math.cos(a) * b);
                        var yy = Math.round(Math.sin(a) * b);
                        if(xx + x >= 0 && xx + x < spr.image.w && yy + y >= 0 && yy + y < spr.image.h) {
                            var index = ((xx+r) + (yy+r) * (r * 2)) * 4;
                           //var dat = spr.image.desc.mirror.ctx.getImageData(xx, yy,1,1);
                            if(dat.data[index] !== undefined && dat.data[index+ 3] > 0){
                                colours.addToColorRange(i,dat.data[index],dat.data[index+1],dat.data[index+2]);
                                c++;
                            }
                        }
                    }
                    return true;
                }else{
                    var dat = spr.image.desc.mirror.ctx.getImageData(spr.key.lx | 0, spr.key.ly | 0,1,1);
                    if(dat.data[0] !== undefined  && dat.data[3] > 0){
                        if(mouse.button === 4 && blendColors){
                            colours.setColor(dat.data[0],dat.data[1],dat.data[2],true);
                            secondColor = "rgb("+dat.data[0]+","+dat.data[1]+","+dat.data[2]+")";;
                            colours.createColorRange();
                            return true;
                        }else{
                            colours.setColor(dat.data[0],dat.data[1],dat.data[2]);
                            mainColor = "rgb("+dat.data[0]+","+dat.data[1]+","+dat.data[2]+")";
                            if(mouse.button === 4 && !blendColors){
                                blendColors = true;
                            }
                            return true;
                        }
                    }
                }
            }
        });
    }
    const API = {
        down() {
             alpha = colours.alpha;
            if(cuttingTools.active){

                    if(cuttingTools.cursor === "select"){
                        if(!cuttingTools.draggingSelection){
                            if(cuttingTools.isHoldingBuffer){
                                API.dropSelection();
                            }
                            cuttingTools.setStart();
                        }
                    }else{
                        if(!cuttingTools.dragging){
                            if(cuttingTools.cursor === "move"){
                                if(cuttingTools.isHoldingBuffer){
                                    if((mouse.button & 4) === 4){
                                        API.dropSelection();
                                    }
                                }else if((mouse.button & 4) === 4){
                                    if(cuttingTools.defined){
                                        cuttingTools.toCutBuffer(mouse.ctrl);
                                        cuttingTools.setFromCutBuffer();                                    
                                    }
                                }
                            }
                            cuttingTools.dragStart();
                        }
                    }

                    
                
                return;
            }
            blendColors = false;
            if(dirty){ sprites.unrestore() }
            dirty = false;
            if(paint.drawType === commands.paintBrissle && paint.colorBlend){
                if(mouseBrush.extra.setBeforColors){            
                    hairs = mouseBrush.extra(mouse.cMouse.rx, mouse.cMouse.ry,true,true);
                }
            }
            if(paint.palletFrom === commands.paintColImage){
                getColour();
            }else{
                if(mouse.button === 1){
                    if (colours.pending) {  colours.pendingColorUsed() }
                }
                if(paint.colorBlend){
                    if(mainColor !== colours.mainColor.css || secondColor !== colours.secondColor.css){
                        colours.createColorRange();
                    }
                    blendColors = true;
                }
                mainColor = colours.mainColor.css;
                secondColor = colours.secondColor.css;
            }
            alpha = colours.alpha;
            sprites.eachDrawable(spr=>{
                if (!spr.image.restored) { spr.image.restore() }
                spr.key._lx = spr.key.lx;
                spr.key._ly = spr.key.ly;
                spr.key._lox = spr.key.lox;
                spr.key._loy = spr.key.loy;
            });
            strokes.reset();
            if(paint.filterBlur || paint.filterShadow || paint.filterC || paint.filterD  || paint.filterE  || paint.filterF){
                currentFilter = paint.buildFilter();
            }else{
                currentFilter = "none";
            }
            firstDown = true;
            firstDownCommon = true;
            edgeFillStarted = false;
            edgeFillSelect = 0;
            API.move();
        },
        feedback(){
            alpha = colours.alpha;
            mainColor = colours.mainColor.css;
            secondColor = colours.secondColor.css;
            brushMin = paint.sliders.brush.min;
            brushMax = paint.sliders.brush.max;            
            if(cuttingTools.active){
                if(!cuttingTools.draggingSelection){
                    cuttingTools.updateCursor();
                }
                if(cuttingTools.isHoldingBuffer){
                    sprites.unrestore();
                    sprites.eachDrawable(spr => cutBufferDraw(spr, spr.image.ctx,true));

                    
                }
  
                
                return;
            }
            
            spraying = false;
            if(!mouse.cMouse.over){
                if(dirty){
                    sprites.unrestore();
                    sprites.eachDrawable(spr=> { if (!spr.image.restored) { spr.image.restore() } });
                }
                dirty = false;
                return;
            }
            firstDownCommon = true;
            mouseBrush.add(mouse.cMouse.rx, mouse.cMouse.ry);
            mouse.cMouse.gridSurface = false;
            firstDown = true;
            mouse.requestCursor(0,"crosshair");
            inFeedback = true;

             var drawFunction;
            if(paint.drawType === commands.paintFromImage){
                drawFunction = imageMove;
            }else if(paint.drawType === commands.paintSpray){
                drawFunction = shaped;
                spraying = false;
            }else if(paint.drawType === commands.paintBrissle){
                drawFunction = extraBrushes.extra;
                hairs = mouseBrush.extra(mouse.cMouse.rx, mouse.cMouse.ry,paint.changed);
                paint.changed = false;
                spraying = false;
            }else if(paint.drawType === commands.paintPointShaped){
                drawFunction = shaped;
            }else if(paint.drawType === commands.paintFloodFill){
                drawFunction = pointAliasFeedback;
            }else if(paint.drawType === commands.paintCurve){
                drawFunction = paint.antiAlias ? lineFeedback : finishCurveAlias;


            }else if(paint.drawType === commands.paintLine || paint.drawType === commands.paintCircle || paint.drawType === commands.paintRectangle){
                drawFunction = paint.antiAlias ? lineFeedback : pointAliasFeedback;
                if(paint.drawType === commands.paintCircle || paint.drawType === commands.paintRectangle){
                    if(paint.gridGuides){
                        mouse.cMouse.gridSurface = true;
                    }
                }
            }else{
                drawFunction = shaped;
                spraying = false;
            }
            sprites.unrestore();
            sprites.eachDrawable(spr => drawFunction(spr, spr.image.ctx,true));
            inFeedback = false;
            dirty = true;
        },
        move(mouseCaptureId) {
            brushMin = paint.sliders.brush.min;
            brushMax = paint.sliders.brush.max;
            if(cuttingTools.active){

                if(cuttingTools.draggingSelection){
                    cuttingTools.setEnd();
                }else if(cuttingTools.dragging){
                    cuttingTools.drag();
                }
 
                if(cuttingTools.isHoldingBuffer){
                     sprites.unrestore();
                    sprites.eachDrawable(spr => cutBufferDraw(spr, spr.image.ctx,true));

                    
                }                                            
                
                return;
            }
            
            var onceOnly = false;
            spraying = false;
            mouse.requestCursor(0,"crosshair");
            var recordStroke = false;
            brushMin = paint.sliders.brush.min;
            brushMax = paint.sliders.brush.max;
            mouseBrush.add(mouse.cMouse.rx, mouse.cMouse.ry);
            var drawFunction;
            if (paint.drawType === commands.paintLine){
                drawFunction = paint.antiAlias ? line : lineAlias;
            } else if (paint.drawType === commands.paintCircle){
                drawFunction = paint.antiAlias ? circle : circleAlias;
                if((mouse.button & 0b101) === 0b101) { cancelStroke = true }
            } else if (paint.drawType === commands.paintRectangle){
                 drawFunction = paint.antiAlias ? rectangle : rectangleAlias;
                if((mouse.button & 0b101) === 0b101) { cancelStroke = true }
            } else if (paint.drawType === commands.paintCurve){
                recordStroke = true;
                drawFunction = paint.antiAlias ? curve : curveAlias;
            } else if (paint.drawType === commands.paintSpray){
                drawFunction = shaped;
                spraying = true;
            } else if (paint.drawType === commands.paintPoints){
                drawFunction = shaped;
            } else if (paint.drawType === commands.paintPointShaped){
                spraying = true;
                drawFunction = imageMove;
            } else if (paint.drawType === commands.paintFromImage){
                drawFunction = imageMove;
            } else if (paint.drawType === commands.paintBrissle){
                drawFunction = extraBrushes.extra;

            } else if (paint.drawType === commands.paintFloodFill){
                drawFunction = floodFill;
                onceOnly = true;
            } else {
                drawFunction = imageMove;
                spraying = true;
            }
            var forceRestore = false;
            if (recordStroke) {
                strokes.add(mouse.cMouse.rx, mouse.cMouse.ry);
                strokes.clean(true);
                forceRestore = true;
            }
             if (paint.palletFrom === commands.paintColImage && paint.drawType === commands.paintBrissle){
                 getColour() 
                 
             }

            sprites.unrestore();
            sprites.processDrawable(spr => drawFunction(spr, spr.image.ctx, forceRestore));
            firstDown = false;
            firstDownCommon = false;
            if(edgeFillStarted && onceOnly){
                extraRenders.addOneTime(edgeFillUIRender);
                onceOnly = false;
            }
            if(cancelStroke || onceOnly){
                mouse.cancelButtons(mouseCaptureId);
            }
        },
        dropSelection() {
            if(cuttingTools.active){

                if(cuttingTools.isHoldingBuffer){
                    sprites.unrestore();
                    sprites.eachDrawable(spr => cutBufferDraw(spr, spr.image.ctx,true));
                    sprites.eachProcessedPattern(spr => spr.updatePattern());
                    sprites.eachDrawable(spr=>{
                        if(spr.image.processed) { spr.image.update() }
                    });
                    
                }                                            

            }            
        },
        up() {
            if(cuttingTools.active){

                if(cuttingTools.dragging){
                    cuttingTools.dragEnd();
                }else{
                    cuttingTools.endDragSelection();
                    paint.updateGuidsUI();
                }

                return;
            }
            
            if(cancelStroke){
                cancelStroke = false;
                sprites.eachDrawable(spr=>{
                    if(spr.image.processed) {
                        spr.image.restore();
                        spr.image.update(true);
                    }
                    spr.key._lx = undefined;
                    spr.key._ly = undefined;
                });
                return;
            }
            if(paint.drawType === commands.paintCurve || (paint.drawType === commands.paintFloodFill && paint.fillMode === 2)){
                mouse.button = mouse.oldButton;
                if (paint.palletFrom === commands.paintColImage && mouse.button === 4) { getColour() }
                sprites.unrestore();
                sprites.eachDrawable(spr => { if (!spr.image.restored) { spr.image.restore() } });
                if(paint.drawType === commands.paintFloodFill){
                    edgeFillDoIt = true;
                    sprites.processDrawable(spr => floodFill(spr, spr.image.ctx));
                    edgeFillDoIt = false;
                }else{
                    strokes.clean();
                    if(paint.antiAlias){
                        sprites.processDrawable(spr =>  finishCurve(spr, spr.image.ctx) );
                    }else{
                        sprites.processDrawable(spr =>  finishCurveAlias(spr, spr.image.ctx) );
                    }
                    strokes.reset();
                }
                mouse.button = 0;
            }
            sprites.eachProcessedPattern(spr => spr.updatePattern());
            sprites.eachDrawable(spr=>{
                if(spr.image.processed) { spr.image.update() }
                spr.key._lx = undefined;
                spr.key._ly = undefined;
            });
        },
        setExtraBrush(mouseBrushName, renderName){
            mouseBrush.setExtraBrush(mouseBrushName);
            extraBrushes.setExtraBrush(renderName);
        },
    };
    API.setExtraBrush("brisslePlain","moveBrissles");
    return API;
})();
