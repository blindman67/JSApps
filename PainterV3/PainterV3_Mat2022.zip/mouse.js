"use strict";

const customCursors = (()=>{
    const cursors ={
        encoding:"url('data:image/png;base64,",
        directions: "N,NNE,NE,ENE,E,ESE,SE,SSE,S,SSW,SW,WSW,W,WNW,NW,NNW".split(","),
        directionsShort: "N,NE,E,SE,S,SW,W,NW".split(","),
        getAngleName(angle, cursor) {
            angle = angle % (Math.PI2);
            if (angle < 0) { angle += Math.PI2 }
            angle = (Math.round((angle / (Math.PI2)) * cursor.directionSetCount) + cursor.direction) % cursor.directionSetCount;
            if(cursor.directionSetCount === 8){
                return  customCursors.cursors.directionsShort[angle];
            }
            return customCursors.cursors.directions[angle];
        },
        nativeCursors : {
            resize_N : { direction : 0, directionSetCount :  8 , name : "n-resize" },
            resize_NE : { direction : 1, directionSetCount :  8 , name : "ne-resize" },
            resize_E : { direction : 2, directionSetCount :  8 , name : "e-resize" },
            resize_SE : { direction : 3, directionSetCount :  8 , name : "se-resize" },
            resize_S : { direction : 4, directionSetCount :  8 , name : "s-resize" },
            resize_SW : { direction : 5, directionSetCount :  8 , name : "sw-resize" },
            resize_W : { direction : 6, directionSetCount :  8 , name : "w-resize" },
            resize_NW : { direction : 7, directionSetCount :  8 , name : "nw-resize" },
        },
        pointer_Add : {
            center : " 7 2,",
            image :  "iVBORw0KGgoAAAANSUhEUgAAAB4AAAAdCAYAAAC9pNwMAAABV0lEQVRIibWWsYrDMAyGv3fwelOXLBk6HHi76ZZAhkIphR6UcO//Dr0hMnVVJZEd3w+iUMf6ZMmWDe31EAv/4HsZmiTwQ5UTnpF7o9fgWArXDnqHg2DMG2WuO+3awbAS/SM3NS83F1w7uGXRm99tCWfN9YQJOAGfO8GbNbfAZwUOkgFvqm/MJVut+ZKDaIAHcToZ837l/6kKvBBEYE5bZK7/yfj2DlxlbKQ01RtBdLKKaIxfgW8Z8xxJHzgDdMBHgvO6IaOMlR8n5+p7sZG5nvkRLG8gSzLAETjK78B603mCeO3Lm2AdRLa6VPPNmlopqwGnBhNwXiyLKSwEpwbjrmdxaluCi9PbApzU1cL3gqvhLcBVcN53dbVKoT9UdClL7p0u4AvwReWrUssLTT35SKO3dOD9FWG9KtIN1GS1SfqiP2eWX+5dS2gO75l3rDbX5b5HYcWq9Af3fuUN358uqQAAAABJRU5ErkJggg==')",
            
        },
        rotate_NE : {
            direction: 1,
            directionSetCount: 8,
            center : " 25 15,",
            image : "iVBORw0KGgoAAAANSUhEUgAAACkAAAApCAYAAACoYAD2AAAB2UlEQVRYR+2Y246DMAxEQeL2/1/L5aGtEUaOa8dOSgIrLW9tQT2Z2DMObZN4vT4XPNJ+rsRHs293/xGB2/8MWGuBmpAK3DMgJTjcL9jp25UEQCy5owSDeroVkqonwXEl4fOyLM04jkXr86xJSz0qpdTYuKgSzbRDImBMPc0/tm1r+r4HJc+uv9qi2l8AJXAKe5WqPyupKYzNxX/PAb+kJg0HCDhzrCsw85zuPuovqEftO6jfYRiSPVZMHN7p2ByamXPjh/vWdQ0aCqM0B1SNxZzE4TvB6xI/p4Jemt0ACXYEEBQQmkVbgKeRTEjcYs8URO1Mik7rd9UpUoe82DwpQaCxV1HSsxiEpE1D7Ymou3e4N5nc2+2BpBFrdTcpI3M4uRxSAqXWhVak2ZkYtV6FUu+jXgvPdl331fVo+lYKFVGSOwJdoJTp1hBdFFJSX5q6/gSkte3VlaSNhTaEMTnPczNN0xfTIyAfoSSmTayBYkNycSW5FVFQnkZKozXVIHMOeWfXp5p0zv05hz1qS8WVlLrZs9DqkLE8F7OavWuqomSqmjyBqkF6QaWI/If0DhjWbFlVSTrCacfdIyIDrsdBSkfcWyB5Ez1unmTZvb/2vvX44EmWIzKjO/oGf4cOQGF8rYgAAAAASUVORK5CYII=')"
        },
        rotate_SE : {
            direction: 3,
            directionSetCount: 8,
            center : " 25 25,",
            image : "iVBORw0KGgoAAAANSUhEUgAAACkAAAApCAYAAACoYAD2AAAB4UlEQVRYR+2YyY6EMAxE0xLb/38ty2EGI4yM8RYgMCM1l5ZolpeKK+XwSS8fP/PxmQ8Lw/yzNP8KmObfZIG+BskATdBXICkgzhbMuKboF1KqaUlFT81HlbQALdAvJJ3uiIqamo8piZDjOKa6rs0lmDv9EcgcFSU1v5CgyhkVD2o+lc/Kmrmd1nqMJYVKQ6Ka/D1oDq6acJ3dIpUawL/M7mmaUtM0qe/71HXdYXYfme7Iov6nuqDcqYYBFlUSgDzDLBBGL1kUEhVDyKqqEtSe5urHtw9aTuNaSAX2VCyiJAekizTAoZNRYW8TdjukBKiotuxn1np0feFewAsfzSDVkLQDRBByH2643K3slkbRVKEvWaPusFf2tqne/xqLq6QCJ6oA10JDy10MqhdRUoKTGlKeJmzd22qPnkfzREyjGoeucehI2vLzZYMPCB6M2wTN3VHAAySfErVG1oSgymKdWudyFTwYh6tnGYo3qEL60ajbPSpHwR2kFPpR10fVJgq7ZuXPXFzH8/QKII0+77tj9D3LqK6AQp2BqXgu3wW4M86VmqSmuRNOTJwz7h6GIbVta36pjU5rVuJ4qkbaq6tg9H7VaWcS506wECRelJPdr0E6sNlr3pmBZL/E6ifPAETu+QU2Xw5Az9rE1QAAAABJRU5ErkJggg==')"
        },
        rotate_NW : {
            direction: 7,
            directionSetCount: 8,
            center : " 15 15,",
            image : "iVBORw0KGgoAAAANSUhEUgAAACkAAAApCAYAAACoYAD2AAAB20lEQVRYR9WX2Y6EQAhF9cHl/7+2XZKexkgFaagCR0rbl8nEhdMXuFBtU/F6fy4I134uT1jXw54P82cBENl2VjNsdUgA9MLeAokqW2FvhZRgpXoNhYQ6nKapGYZh4wHlsB6l+qb3KWwIJOniL5YcJP4Q+LvX7sZ3KSSHg0DLsjRd17mNAVUFRS+DlCzGTcZeSKBnPoSK0XdL9eaN8y8lqWIYGL1PqjeerPCaRMB5ng91xv2ONwC1mtDu5oBUIWyQvu9TVvnow/cpJDYV/ZGnfVICpMFI/SQf5MEkyEsnDg3ADZfaDoCD3YBCOUgrXCoTS9dJkBSidH8359gtyKMktQ5pXQvbJ3lKuSfi/5BmaB460iyZKj1TnDjcF9F+tO6+GrA4uy0dCR+JUtDUOBokdvG6rgdfvHIXOIxcrR4kQJwkyvgrlk6p9rT76odzKkYp5oIsqfgIyNfr9R7HsaGLRM7/zqbR+p6Y7ielOlkQmnVuidWW2hqpb7lZU1C+6UjpiTBvHidB5pZRtev2I2q0mltNat2cK+yajfQ7kB41o+e0lL1kQZ6U10z11xZkAa0N+JuQpdq8Q0V16X3kWJQOTNo5Jtq4s92dA70rze7jwx0KmiBJI4UdDSw75R8o6xFEUVHiwQAAAABJRU5ErkJggg==')"
        },
        rotate_SW : {
            direction: 5,
            directionSetCount: 8,
            center : " 15 25,",
            image : "iVBORw0KGgoAAAANSUhEUgAAACkAAAApCAYAAACoYAD2AAAB8klEQVRYR92Y23KDMAxEzQPw/5/LZabFDPIsi4xsgu2mvCQNTn1YaSU5nTOun+3qtstaV/L+7eYHoNteXUvQKCQBNgVVIRFQwugj3krR74TUVGyt5knJO8CWoN8FySoeJgnlD/+ubaKgpAbpCQVI3uNntWrnDqnloijHry1y04QUKA5/zZB3KY6O9eVaoAFSA/HqYXhja0rnZgg3A6Bh2EC4tjTgvndEHT+e7b26hVEugv0ryBb1MUQx5ty/NK4lDb1klFOuQs4WO2IkHx/YQH3fu3VdubcXAX0EebTSALgsixuGodjkbj655KYQzfPsvIp4gPSlqiSoCSkDCLlbraGlQJMhoU8HQN9tvNLaA2idCNYm7WuWIHS0dby17ks0JEWkk6W21KQn0iAO9S5K+nz1YWcA/h9oPgs2CxJNE+nrp1SIRYMnK0vZJEgMl+VuAeCNraOyKKupmgypgcYUESNxPeXJ6jLtwOSFsFmQbABULQbAP8iJwqD0iRXNJaDZkFg3U3q6NsDweUlbg0eTR5CRjfdBmUOsrSVnx5aE4/RrkNyZcmC132iLKMnlBs1D905qM+BrORmND93wZWeaJjeO436nmrtTAXldtTr5FBBLl3aWf63jfALIkLmDxqvuvnsQHJ4t5S6d6FOFcr7/dJ78BT9VMkQQsPUZAAAAAElFTkSuQmCC')"
        },
        drag : {
            center : " 26 26,",
            image : "iVBORw0KGgoAAAANSUhEUgAAADUAAAA1CAYAAADh5qNwAAADn0lEQVRoQ91aPY/bMAyV26FAc5cGlyFAM7Rb5nbokP+PDB3aOVu7BMiQQ5q7K3BDPyzXtGmZIilLitN4aC+xLPGJ5OOjnMJkvv6UV1EUzSrlR1N+br/IsH7WyQGQBQKXxZMbWDZQFKBzAUsOyoKxxoNHfNGV02NJQWkB5fZYMlAA6O1iYXb7vTr9c3gsGlSdOwWXQxLC1MCiQVmDYwDlCMVoUMMBWT7pLp/KYyOC6gfl7PbWHB8eqhsxBToZKNdEXHA5Wvc9NzooymhtnWIAD97wwQ8SO9xqoWsqvgBUQx7YkzGhRkaJVEOG3A8BlRpQRTIao0EtSKzkjKvUuKT9UJ3y2qJdv5lLAoUn5EDZccvl0ux2O2gtVKCgteLaEa0NKlAQRm9ubsyPx0dvH2THLUrNt0eaL5T9uMKrtUME5eaFb1E7brVame122zgd775UozQNpNYWFhSV6BQoO24+n5vD4dDYPp1Ozel0CumnOmHqW8f1POfZXnL6mAtPAjG+Xq/NZrNpAN1NJub+6Qlkjiqn6jwlgUEOa2zCEdEBxVGxlCOf3t2Zz9/vOyFYJ38vAuF7KvS0bIlYs5frDSgS0HO5669eN8wfcgjUMfz3V2NefFABtoNms5k5Ho8dfO0GlGXi+Wdp14Sar8JT/eP1UAWqfVii/04I1KdGEF5wD4yTPM+uRdiF04PvWAeCciSQky/vy8/fVHnnBeaxqwFWOyrECeJYtGskWUj3xQWYAXZuG35uwY6Zs+MBV7TCQv8vqF9fTPHyo99TzP2YXa08xdH40Mn5nPp37AwEgml96Ho9er9K9kNUW72d4HbuXHWK8phkV10X2zqlASYBvkhFAWFo/6eOjl0BaXMxt/azXbHLmNiL2E7cQZOClkrisVS6D5RbLjpqxhO/vdcxY/VTFCgOUOUQjkaB7lHOkSendtw5Ol/JjobafaBqQE1Mo1pAboQdf84zCrCPsl91mqQtilhvSWxJdLLJbEk2EQauUSlcO67dRN+40UHVTJvUjmSTuVJfG364vsR6SCQK7QK+vkULyhtCIZrMmSTaUy7tY9qVNoayGyn4wbYNflCjFyVQ7v2Le5MY3hdd8DtfEMJkDlEHJPY7uJhjrlAvi9ovZEKsPCRyYEgh6Y+wonMK55b9+yp+8eIqibqYsh000pFJPZSsTrkhxTV1nbjP+Lu/ZOFHgfPlWE7dV0VKCCmEjqWEbW5A2UFhusdKI4fewxv+F99DyFgAubWRAAAAAElFTkSuQmCC')"
        },
        drag_small : {
            center : " 25 25,",
            image : "iVBORw0KGgoAAAANSUhEUgAAADMAAAAzCAYAAAA6oTAqAAACQElEQVRoQ+2azW7DIAyAYZdJW6vlVmmnvcLe/yH2CjtN6i1Tu0m9rIMsJIYChmCvCWkuqZSA/fkPQyoF83VWl5RSqJtQd8kpjnVyB4QdiA0GghhvcHuIBcYH8h9A5DAxEG4gUhgN8rzbiY/9Hs1zjpAjg0nxiEtIDUQCMwWEI+SKYfJBzorDFkvloSvAXKZTs92K9nAoXlTJYFwV9YofunyNAEWHQALjU9qETijpA2OK9CkaHLJ8NYumBrzBoMss/sK6wkyHDLRJyp6EKsxyZUc9Y5R62mzE5/GYvB+hhNFVMVV+EMZVKGeVpoYxwYHp4IUp3VhxwehwjwFdwIQUwawC84oTJgZkwaQogRfIvzcA/DCkb1m63Eu9sE4CFqQBxgty+hLi/mHocnMOVyzFf96EuHv1AkKopmlE27YW5wiuDHD6Vvo8Ds/daOlggh7pYMbBqdaEnon9zpmve9ejDwSS0f3IRBgYGqOwF2W0dysEKWCskO4dkz1vbADMF9PaQ6OF8qBECT1ndZ6pJ2eMa6upZlGg/mFunF91ncGAFtcBxIDmApPVm4WA5gCD6bCO/Qz0EFzMFrvTnLoip3TfKUbJlb+uA41c60S7cPUQS+Ip8syYm2eg9dzjoMFK/edy19KxTqI0j4o9Y5LdVXqxXwFy+zYXfHbfZ9IPKWb85QyrXlh1oqxuxTmDdduJ22sSPUgmgUBV/A8gx0OUoWX1jVhMT3leVW8WKgpcHmFtZ3whxw2iZZIWAF9IOod/rPJ+AQ3iOFgpekFcAAAAAElFTkSuQmCC')"
        },
        drag_small_copy : {
            center : " 25 25,",
            image : "iVBORw0KGgoAAAANSUhEUgAAADMAAAAzCAYAAAA6oTAqAAACyklEQVRoQ+2azU7DMAzHUy5IwERvkzjxCrz/Q/AKnJB2K9pA2oXRVE2WuHbsJM7Ypu0ytrSJf/HXPx2dafw6jK+u68z4Zsb3ruVyTScHIM2BmsGEIM4brT3UBAYDOQWQOkwKpDWQKowFeVmvzedmw+Z5i5BTg5F4BBJqA6nAlIC0CLlqmHyQw8gRL6vloX+AWaZTv1qZYbutbqpqMNBE2/GpFyYENBRCFYwNMbZsZV5QI3mKYVyuOFvdzmLf22tCb7g9CHNFQ8MVwTBSZdJgSLXy3wcQXq+dBYwLCxdyzlAJjPPY7NVqIVrtmTDGOY/BkLSfNTziN47LT5jk1njMgBzPzB6ZNjIFg62dsjfpGbfQ89OT+drt0PhOhRMRRlE4cTA2bOH6ZMmnBmDIwC5dUs2w3JDAYNUPsxv1DBP7/p4wDGDupBombJDzegtbpHaQOYNNAMKFLRrUHFrzUFouMkxiBFcwsBwCVSzqQ9x8sNQj83uGKGQWN+6/jbl/sP17miPn4UqYH+b33Zi7t+l+9z0G0fe9GYYhGjo24LER739Gex79OPTQojxGM00wx5u5XQzHw42h/s6Zb7oWsScEinrGYvJCGMz4rnsdvfLhPRxKHjEUYY8HGieCvUk8t6BiUdorK28kBlmgq/NMJCkuOmeCsumfCXugS6xmSaB5kKr3krw5eZ/hgHKeoEiar+R4nKtGqrQZ5ZWWMKlNJXUWp5pT5bIVDBcdRecZru5rw1SfZ8IcAjLlpKo5Z23WMM4L2LiWZ3LXvsFwO3bzDLdDgvHqMKMkN3dCxGyTNNIUkwoM9VQ/JXXgGHzIIXDE4hI1mKLD1mzO2f0+I4c541/O7OamqhcXLpxE4e6PmmrOxaV6THBMqA53u4bKJKH0uYr/A+DOQ0BjVf8Wg5Z2rTAL57kqBUAVBc1kP5lnsJBrDaJeALjjQK1c4VLiD2iOt1gstXxDAAAAAElFTkSuQmCC')"
        },
        rotate_E : {
            direction: 2,
            directionSetCount: 8,
            center : " 13 22,",
            image : "iVBORw0KGgoAAAANSUhEUgAAABQAAAAtCAYAAACu/EtoAAABfElEQVRIS9WXTRKCMAyFy7DiFp7B+9/BK3gMNqg0kMwjJG2Ajo7dIIx8zc9LUro0r/e88hVXNy/9LHLfZZj1rrFHimwiQA2IbGJt4AIt9/Qm2QgNpTix22zlNE2p7/tiyDK8GdCDZQtMC0umlWACtNz2Ymi5uZEb3+g4WsBxHNMwDGbs+P8i3ghQXnISEnKZY6aqyLVyU17aSkgAASJQF4jZtMJR1KFOzJp1qYLTQOw8uqSi0HCL+g8g6Qz6LmcewxNyGZuwyOf1SF1/p3xiOVaBljZBFfQTJVQE7mG32Zqn6BurSKClVoVAQ+ibbn8auLpIMOXuEsufWbhYczGGVid3dCjSqcoGoaw5CtNZHWInalYpluta0LxxyOVLQNBXcTyELNRNgLtItBfSJijsSqltBtWhmQJ9jvV1fOp5g/70XP7ayQFj3PxsUzvKSZZbuesCa0fiwyfYGtCrEnp+1F1VCPuvgJL+9HgwjnS75tL+S4pbk7Ym8hlmDbgPhV40ONcEMdUAAAAASUVORK5CYII=')"
        },
        rotate_S : {
            direction: 4,
            directionSetCount: 8,
            center : " 22 13,",
            image : "iVBORw0KGgoAAAANSUhEUgAAAC0AAAAUCAYAAAAZb7T/AAABmUlEQVRIS82WQRKDIAxFYdzoLXqG3v8MPUNvoRunBSWZT0wAqZ2WDS0CeSQ/Ae9Ce4UW+9h8aPT7X3rJ5+MAcgL/Tw8gQNl/kY+hCdY6wLejgJDJVgZKYyo0SkIq5eooWN5Mkj2oM/JUoeUqGYVP9F+SpZVLJvS6rtuaYRjMPOTFHyQtQWP0pEHJwnapetBArWJcAUw2WsChqu3SoPC2Lm4BlglVS+Ae21tNblnYCqwphjxkRfGs/WZoLDma90qGrQNTVFqkiXucgsb6KRMIDWu1XgOjeaVkNDVtSSRuOs+zG8dRrZmQUDFBUqLcQv/k+d7v/8FTh0sDN1+WxU3TtO2lAW+OszIZjdQ8IefGBE9yyW7ckzJgcCkvFRon4SVgwWsHJHDMhRI0SgUOTWWOy53q6SSV7LGECYOSyMK3Ppwf7rz5wdPwHdfJ/agMo2QlU/YMBTj1eVp8ebGmd20remSvGQcv2sTDdL+dtVdZ6aVoVI8u+12LtEuip05bl01t/DJoqUE0XLsRa5Dy+6XQBH4wot3tZ0lh/hsjtNMQNXVOtAAAAABJRU5ErkJggg==')"
        },
        add : {
            center : " 2 2,  ",
            image : "iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAKElEQVQIW2NkAIL/QMDIyAiiGYA0IyNIACQBEwSzQQpBDGSAUyWGmQAurxz9lP1GCQAAAABJRU5ErkJggg==')"
        },
        rotate_N : {
            direction: 0,
            directionSetCount: 8,
            center : " 22 6, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAAC0AAAAUCAYAAAAZb7T/AAABhUlEQVRIS72WQRLCMAhF0+mmvYVn8P5n8Azeot10tIkh8yVAaMzYhY7FwAv8EKYw+HmdD3c5nc/IMEOdRWCJL+5jJPgwaAIWEh2Bw0jwbmguAwKLMsBs0ybQTlLpzf4XNIFozhCUg0E2U1YBjLJcvsnG/icmUGIqf0Q98lLCwgJTgR2PMM33IoPsbyqyATtuiG8AE6YxVdAZmAdPviW9khxwXX6XgDW70GFKjAiOZ4SfCRHaG8iQAAUVg1vtT5KZG5rAt20Ly7JUcXRN386KPEHTn98II2ma3u37HtZ11c5FSnL6sNqVVUa0dXYPU3aS/yidS9AMrOo8UltjUtO6lXpeBAn6oT0XRO+N6Kk0xu/KtHUpXJ09PMC8WpegrVJbHUGzeYEraL7wOI4UY55nlcMjldYmPMCcpcT1LMbDgO2qd3bAjmW1P6lzpUvMguZjpmdWaGUY7doskzdVuVIzLU1okOnuqbC1GX6ArUmxZFoq0y/lb0G27OZESfr6RzZboFaXQb436grTEAPk/x0AAAAASUVORK5CYII=')"
        },
        rotate_W : {
            direction: 6,
            directionSetCount: 8,
            center : " 6 22, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAABQAAAAtCAYAAACu/EtoAAABfElEQVRIS8WXzZXCMAyEbXJJGdsC/fdADXSRUx6LQxQmssaSSdjNiQfx59Hf2OT04fN4PnppLk+ERxZXS8seJlADrH21wPKOCSwwDTCiq9S5QA8yz3MahmEBbzCWQ1HZgnYBy64RqMTtKpQXI1CELeGzthHYNE1pHEfaXSFgRJkVLlXIgKIG5boKPRhCNcxUaAFxIf5+ChBbav1cGnsr7q7KnjrMncy7Ho6PgayPvg+UYYdpEQMIeef2EtrWY76ldLluTmIlvxmyLgb6oTiO1SIWNFswtK2cf57Oc698jypkjbp+v9swotJcsBZm+U058uvcaBxuVMEpClHN2546c2jZ/aEqa7tfNjjahwg9bVKs0FWF+0bv34EhP4yq3BmJavQqL55rn3KmWOPHCkbvh60zGJ3GPZdZHqldyUVzHa+/udvocWzdE0MhHwm7qyiYx/ANNnqV6waiGu8Cv+tJqx1kTt+uXWdGb0L/VkQ20J4JXcHv2KyRtRmrqcm/RYEqNEObMkwAAAAASUVORK5CYII=')"
        },
        add_sub : {
            center : " 4 4,  ",
            image : "iVBORw0KGgoAAAANSUhEUgAAAAkAAAAICAYAAAArzdW1AAAASElEQVQYV3WOUQ4AIAhC5f6HLnHqKIsfHXsiMNdyAeA0n6CnAgEaBeUefh3wKiBVJnbyL+l4Hf+vTqNbl1RwFH8lPSEBu6OCG+c6QwD6VCvwAAAAAElFTkSuQmCC')"
        },
        copy : {
            center : " 12 4, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAABgAAAAJCAYAAAAo/ezGAAAAjElEQVQoU51TWw6AMAjb7n9oHQSwlrqY7UteLRScI961Xn7P9XZ+lWs+rjPbgSKYmGYPiym/JQG/56aP69xOEBjAASK5AAhEAbfGGgFOtO0qGsAc1YBLhBMIDXVXz4oqjlKnVE6qCHKJIBXnoUSvg8CaRgBX9GsHOPHnBKdXhDLgSbcJTv8D7p5ISrYbHeTwAt8s7ykAAAAASUVORK5CYII=')"
        },
        drag_E : {
            direction: 4,
            directionSetCount: 16,
            center : " 26 9, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAADUAAAATCAYAAAAwE0VbAAABeklEQVRIS+VXwQrCMAxt8SCo4G6CJ7/B//8Gv8GTsNsEFTyILrXt0qzp0lkZaG9ja/Je3kvWajWwnu3Cn+h2De0p/T4XQxIgBMMcgN9UpHJwsKQcIScUBJ2alBRLlBQlBHYaS4pax8bKsnAunl5wCLDdbNSproPWGEOK2tcFzFU8RgpiOZy0JQJS3GaslGQIQBJJLPedMKaxP12xYntSKRAukHTwWSU8CNrkxM4STlFCGBdW35BiCd2vSs2XoqRk7AeEcIVdZXPVD0BEcGHFkjbJZmM3mASPg9KzvZ+YtnBdPvR+bB7WilaoUnFNHFQ1rJghxL0vBQByp5X60H7YEj2l3j/yZK+wRBlcPt/3e2rXAj96fFp3zyVJBT3lskWHhanIAgzlbYWrV1WVapqmV9BPp18sbjdsWgffb8EAo2P9t/9TScXC5hcfcb59ouBOOf9x9uMUG3P2KzWmc28MovvUerVS58tl8quHFMdgf9Crw1SXRHIMS+J+ATj8wRpyQ2XYAAAAAElFTkSuQmCC')"
        },
        drag_EW : {
            direction: 4,
            directionSetCount: 16,
            center : " 26 9, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAADUAAAATCAYAAAAwE0VbAAABeklEQVRIS+VXwQrCMAxt8SCo4G6CJ7/B//8Gv8GTsNsEFTyILrXt0qzp0lkZaG9ja/Je3kvWajWwnu3Cn+h2De0p/T4XQxIgBMMcgN9UpHJwsKQcIScUBJ2alBRLlBQlBHYaS4pax8bKsnAunl5wCLDdbNSproPWGEOK2tcFzFU8RgpiOZy0JQJS3GaslGQIQBJJLPedMKaxP12xYntSKRAukHTwWSU8CNrkxM4STlFCGBdW35BiCd2vSs2XoqRk7AeEcIVdZXPVD0BEcGHFkjbJZmM3mASPg9KzvZ+YtnBdPvR+bB7WilaoUnFNHFQ1rJghxL0vBQByp5X60H7YEj2l3j/yZK+wRBlcPt/3e2rXAj96fFp3zyVJBT3lskWHhanIAgzlbYWrV1WVapqmV9BPp18sbjdsWgffb8EAo2P9t/9TScXC5hcfcb59ouBOOf9x9uMUG3P2KzWmc28MovvUerVS58tl8quHFMdgf9Crw1SXRHIMS+J+ATj8wRpyQ2XYAAAAAElFTkSuQmCC')"
        },
        drag_ESE : {
            direction: 5,
            directionSetCount: 16,
            center : " 25 15,",
            image : "iVBORw0KGgoAAAANSUhEUgAAADMAAAAfCAYAAABKz/VnAAACIklEQVRYR92Ycc6CMAzFZyLiAeQEeBMu7WH0BHoAURM/utjlUVa2Jirz4y8Cg/W3dq8PVs5wPIeDhq+Gw/DY14Ymg2KAF4QPjJhKBFJhIAthZW+3m6uqikCKBBrBYBYo6Mfj4YOWR9EwMgvr9drd73e11ouFIRDez7Es/EpW/J5mmBwQFoFiBcAKs9/v3el0CnupJFXzAmAFkjLNpbg0WIChFT8ej+YGh/2TSxWhRJ9K9jVzAPBAeDlNSnI8p2KpiWJCkoJNvdNyfwTDkmt5QWxsDOAbDiIbxgqK4+Wzn+pTEwcQCxomD95My17f92673Qa167rOHQ4Ht9ls/DUqYzpna5RrXHHvac+YYEC1AovsTwzOQXNPkopp2UvY2HniWK+bqMuwYk9eRa1JSie92+3c+Xz282AW5YQIhBXQNI27XC4jHygVUZYtZXaIcxT/BCZ3FWCF+Btnki3cG/xe6byxXOeEQ6sAhI7qfk59yj0js8VBs9zLlb1er66ua1U4UeYT+zgwvL2JxdzEnLKl2sCcikpVfDsM2qPXeYhXK6MUkHb/KzAMhI1SA8t16zEgKGGflI9kBifWvJn8IJSwudliT0lC8HGYVFBSOKxQWGqLw8SySAG2bZvt4gNQauWWuG/9vvo3MKN+tMTKz82ZkxX+DYb7qwgBiDkJrVHSdfkbLGlnlswWZoadN/hAf6qpcFFqBkFH/+WlWkmRMMJBZMf4B9S/4COrxApbAAAAAElFTkSuQmCC')"
        },
        drag_ENE : {
            direction: 3,
            directionSetCount: 16,
            center : " 25 15,",
            image : "iVBORw0KGgoAAAANSUhEUgAAADMAAAAfCAYAAABKz/VnAAACR0lEQVRYR9WY6a3CMAyAg8Q1AEwAw7A0m8AEZQAuiVfnxZHjOrFTigj9A6WJ7S8+6cw1er36C0yb9ZfVRPNCq8Ap1gEIMgQmL1YDaw4GQQDi8Xi45XIZzwfBclBNw3Avg7fm87mHxIuC/RQMAiwWC/d8Pv0t9VZzMMFAnzM0X3K5SHPr52FCYfDgTcGQcux2u507nU6m4ohe/DoMAuAJ0zywkEQQrW5bhGlrmLHx8KgXUIYlR7i+/X7vPQgsH/OMZqzUFLWD4c+hqkGZRo6PwBQ6+KAB1gLQ9TTEfJi+I0zaSzs4aWy0H5hKrrRXaqK+igU3izA0zkNiqtC4B0eQ+/3uIAxAD3w/HA7ueDx6e+C36/XqVqtV9iyT/iH0HO4V0TM0RGhi5vKrlBtUIcqlkDzhaQqzAXPgTRNMr+wFwx0ZE/4bEtHEy+lms3Fd18VTD+vFfcSIqGO73brL5ZIYzPXRiQC93duZRExyI8U77bA0jnPlFJViuOFBcNmSF0re54WXH/AgzDQYSzm93W5uvV4PPItllEKSwzHnZGlP0sRKw13pmZTFPCykHJi6z5lhakp4KZFBjhQiNfJzaxMYDIWxgqUwrMmNsXpj6IWTeuGMUytQMzY3m9Xqsaz3nsklfklAxgtqIluMGrtmVgsCHjyfz8nf1bHKp95XDSN13qmNGisvwmCV0QQ1DYM5g50ePvnrHA7YKtBgnEHD8XWO9O/vJ2CoB6RpmE+8U3dwLcS152opzb1waA3Ep4lGm/FW1b4aHe+s/QOj8uMjgZQH5gAAAABJRU5ErkJggg==')"
        },
        drag_EW_copy : {
            center : " 26 9, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAADUAAAATCAYAAAAwE0VbAAABbElEQVRIS+VXwQrCMAztToIOZKeB//9twm4TprCTrnWdaZakaS1UsCdxbfpe3kvaNiYynsuAU5plxNaU/p6KQQRog0EOll8tUik4WFKekBfKBq1NSouFJIUJWTvlksLWWWMlWTgVzy64DXDpe3MdhqA0ckhh+/qAqYpTpGwsjxOXRECKWwyV0jQBuwmlEF6rnSftTyV7IyUR8mBw44MehypQ86W5Hhhct6q55QE1YdFFjhRLaL4bcziJ4kiAIBCQUddwUJ1u/6lcQeCCijmbYGAai+GsEtYigcK9qN8lsFilNPZneXIgciz1DSGYZFmpDPtxClL2i6nLZpLBte1Rs6ZKkgpqCnStfW25jByXKe8mWar7cZ3MA+u6zozjGHD+rFmazPwIGhhu61XOKQhCW9Cx2oUHMHmjoAL84o2Cw/Qfdz+uxnKUSjnvpLmpLwbVe+rctuY2TdWfHloc0ScALmR8Iy6lRkwp+D2G4QU4DssaN7UX2QAAAABJRU5ErkJggg==')"
        },
        drag_EW_wheelStep : {
            center : " 26 20,",
            image : "iVBORw0KGgoAAAANSUhEUgAAADUAAAAeCAYAAACMjVaFAAACZ0lEQVRYR+VXQU4DMQz0igMSVKK3Spx4A9/oE/qIfUsf0e+gPoFLkXorUkHqAcEmrFPHa2+cpEVV2ctSNrFnMmOvt4ErvJor5ARnJfXdXU3TQHeD7n7WXFSckyRy4DEogqeE+DPuDml/jYOqSTE1vCrukoSRFJP216paRYoDcmQQOLeeZkX8P9lbbddiUsoJe5F6gNSSkYJUMS1OTR0WkUpYrqGnzxVAa0qKsmfFihWRQiVIZ0MA4b5cLn1ttW0Lm80G1us1zOfzaB1pIIP9f64UghmpKUBSSGy1WsFisdDA+5A9kWKFwiHVtE5JMVdTSJaq5f52qiFwJHEqy1EeSfvRd0gPYLCnJ4FkQqNw9kQyCgm6NtpPQVowmEkpBZ88CMme9EDwEKwuycWhAuQTQem4k0tAIpqLRSSljDhFBcyto1l4TLVcPGJ9PM5m8LbdRnlKlOK2IbbMGnAlUi4W4uRjVURK20w7lKUOXBJLLFxnjBmmkqgpCF8BgdQYCPqStACg7xs8EKoSb+PWmNo67qKo/Tow0XX4ALi9t+QUrSopjABy1U/hosRGbZLNpt/gE3y9QHPzzKf2Yz7yvDQP3xeIdQ+kBlWVh8+E2PEwkfS8KiHZ7GKPK1VpP2oJNnWIg62ZmIKLKuWlol4PwStJ/Sr01MV/DSHpbzGnhZmAK6op0pWGxPzmOwfNL+Of6NPpFHa73QBGbfeT4h6bWNfMDp9RAxO73ygxWvy8OyqnejHvqRSxS5woNEz/Y/bTFCtRylLzljUnmdI5sYfJBN73+6Ip3QI6tQZJWXEkP/hyvzpTAEue52L4AURI4jQMP9/LAAAAAElFTkSuQmCC')"
        },
        drag_EW_wheelStep_copy : {
            center : " -1 -1,",
            image : "iVBORw0KGgoAAAANSUhEUgAAADUAAAAeCAYAAACMjVaFAAAChElEQVRYR91YS04DMQzNsEECJNRVJa7UI/QQPUsP0fv0EkXqrkgFqRsgCXF48diZfKYItZuhM+PkPb9nx2UwN/gZbpCTuSqpL/sZhsHYi7HXq+6F4syykQNPixJ4JMSfcXdI8T0O6ibF1PCquI8kjKSYFN+rahcpDsiRIeDcepoV6T7Edtu1mZSSYS9SAIiWTBRExbR1euqwidSE5QbMPleArCkpyp41K9ZEipSAzkYA4nW73fra2mw25nA4mP1+b1arVfIeNJBR/J8rRWAyNWWIFBHb7XZmvV5r4P2SgUizQjFJPa1TUszVFJFFtdzfTjUCTiTmshzymLQfniEBwCgmkCAysVE4exIZhQS+m8QjyBIMxaSUgp9MhGRPTAglodQltThUgHwiaB13aglIRGuxiKSUEaepgLl1NAvnVKvFI9bHy3JpXo/HZJ8WpbhtwJZVA65Eyq1FOPlYlZDSgrFDldSB20RSiMeWvpfbX0p2JJUjhIck60r+Kw6vrmVL79N96V0ChnHY+rFzSknlxJL2i4B88OXdmPvHrDg5QJwgHq6YfW0NdWMBFxKLB+WIUInPgkpSbAlZfIePXIXby3Vv75bYX92Dg+cWou931hOf1pmaVWvrVgPk1s8r1WA/jVSJElqCRgQUXHGPUITxfwnJAg2kNPDXJpXUFJEQu58n9eAqZ9TlsCPVdj+tfgnYYrEwp9Mpye9vjPXw5SNpYGL3yxILD4ut8dM8sucUgigt6KnaxQNYm7jjz2/h7KgeaHlNhNZevQ5XWDp4fcORukjtrJVrv/9i9tOsqGWl5TypjZllSufEnp+ezNv53DSl1xLIOacUx6SvuX2wIOcAXLJGLYZvX+LrNA0kdogAAAAASUVORK5CYII=')"
        },
        drag_EW_wheelZoom : {
            center : " 26 20,",
            image : "iVBORw0KGgoAAAANSUhEUgAAADUAAAAeCAYAAACMjVaFAAACl0lEQVRYR91YQU4DMQzMigMSINFbJU68gW/0CX1E39JH9DuoT+BSpN6KVJB6QLBJN8usY8fOZqkQe2uTtWc8tuNs4yqfr/aJJpr2kcz5fX7Zb8/tq4QTXhdBWIxHoHGvBBgJWQJg8Z3bM5qUADRRghLXAlBLaLRSlFBMq2CQSTGaer+diqOUIqD64Hbpx6oFaRfWpQCAkqZa5ZStJoXgOKBC3WWJWWtVStUqUt4oNL8k9SK49Xod/K9WK7fb7dx2u3WLxSIqigQba61O2iik1IsEsV1TUpHYZrNxy+VyQApqcRAoTFtrty5SihJClbrUS+xxannlvGqxBlFxJEc6pbmxmUlxhKyHKBLzZAQSbOpdWilzQDoS/USBqnaEgy1sELlazdWTSU4cgyBqRYSwTUvqarWKRLQMyYKrba1aRAnZpBsSIv1PbX40DaDc+WMFrO2z1Ko0wUiKsaSmOCtQBUqMgtHGplI8bAt+mM/d634/wDLm2lAyzGLDoEHgSPk9EScN0oCU9DKmn5ZOsbNZbHkwXCPifODQTGuN1lhPKgeCnBUqr3ioxraMd0f8Dw9fzSg96HPEBudD8uLp3bnrW81fss5dRTAwlFixAwYXlkf2FC921r0QHHw+u+bqqb+GxJrpMwLWx/phGtDZX7tgTWuzb244xfrRhlezI2ajt51XqjL9MCUSpc4fYNiJXCUl4Or9eQNik6gkde6Ej639lx4n/p6S1KCmojeWWCB146GFbfQL2Gw2c4fDIQlsbffj7P40sfaWf/oYNDB6hv7vcyqrWKeSNkhSyUomilwdSeUhTTl/YvbTGkP17CcpNmb208Ba1yeZ0imx+7s793Y8XuQ7OEc0krLiUG+w9GTWbp3W6JfsK8XwDbmKCEOB3VJgAAAAAElFTkSuQmCC')"
        },
        drag_NE : {
            direction: 2,
            directionSetCount: 16,
            center : " 20 20,",
            image : "iVBORw0KGgoAAAANSUhEUgAAACkAAAApCAYAAACoYAD2AAABqUlEQVRYR+2ZwXLDMAhEnZv9/x9r39qiGoYQJGuRipOZ+pJDLPG8ggUnjyX5+vq5kJAPupAFo/cSIBqSnikNkgERIemB0iAjgHRqqZAUMAKaDhkBvQUSBf2HrFkVmpfpSqKA6dVNgNu2Lfu+Q/0gTckeBbkLWaNPgewFZDiGYrn/HBIB5BlCrxHAmQOGnW6sKjYZNYT+zoCW2WLKgOFNN2UwOAeEXkC+79xP2IYhr461mmfAzDYEaQEp7rquy3EcRRRbELUjvvKlMKQHWLOQJ2MGFJQqv3qKnhanFeJ8qlVqJN4UJXXekWNwpSv43wk7oOJQddeUehslM/MxpKSnIBcGfXJ1O5UdTi1ooeeJrc4StZwX83dakgveMm1dIGa/cLHofQTI65mmTYk5ezbiKRqtZlfJlqddtb1Ro+7xzeJptf6qAWqbzcq7FqwLqavVtrqnXOGfQYIm3aNiYek5Tm8zfmeZlXchJZuLkhSUAQNVMiMHX6obgbwDEM7Jj4DM8ES3USDHLYn87oVzB2jIJ7NzUyB73Z/uG3kVQOLIqZ1B4f9WIsGia74BxIYUGL3rV4QAAAAASUVORK5CYII=')"
        },
        drag_N : {
            direction: 0,
            directionSetCount: 16,
            center : " 9 26, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAABMAAAA1CAYAAACjpdDnAAABcElEQVRIS+2Xz27CMAzGnV12mJDWExKnvQLv/xB7hZ0mcSoS2oELkHQ4Shz/qbtGaBK5lJb0x4ftz0kCGOMaRwgB4gXiNWjT1S8JyASKsBKEaiyFLIwDzQE2MA1kAStYAu22W/g+HKy8pGQ0McywOYroL1DgBBNB5x+A17dfRvqMA5/F+xIY/IquCVGJzEA/rA3n+2YDx9MJsjI6JVW8NDgjTA5JyriXULoUdPYd7uFqRatml2SvUf1QZcMwwDiObDvqa/T/GzOtQfaPWRk3zmbSwmIru3wCvOwz0/U3qZVKU6ONJWDTtkuDU7OH8BEb6dekUm3btL7KyXe1VSNdBLuryK2qgMgLSldlZVwwla6Ycb5cnE1UUJXHX+qMAtd1AKG5HPDsZ6Incx16l7rn6rTyLgh9yNmGSw52E9ZmXXaO2k6xVqHsaVUvenfbbA+TgmV0kD4nFI/CWYvwHKC7OUpJWXTe5BRaoKmYrcR5zug3w4FMNA163k8AAAAASUVORK5CYII=')"
        },
        drag_NNE : {
            direction: 1,
            directionSetCount: 16,
            center : " 15 25,",
            image : "iVBORw0KGgoAAAANSUhEUgAAAB8AAAAzCAYAAABvwNN0AAACL0lEQVRYR72Y2Q3CMAyGg8S1ABOUTZibTWACFgCKBDiqI+O6qe249An1+vz7Lqu04PH+Hvj61ffgqNGJCFsQSnlgBzcgDE5VHo/HdL1eEwoHIxaBc5Xr9Tr1fT9yoGSAWzlAAbLdbjOIhFeMXBgcwBjPOShastlsskdo3F3KEa4FTxnwVzh3fRNcE+tRbZPMd8EHaG4g1thT9W44KqKlpsmBcDi+UNMdsTxz09E8ULunlvnY6XhuFPUt8LmSox6R+nyT8hqcl5U04f4GlzzshltUT4W2CX44HNLtdlNNsDDl2kSTthdqhEt5hMtzd7SWmrQi3e/3tNvt8qumtpZmt0/NcQIU16XmhKOuhhYJywFAn89n+Y2dbC7WaIza7TzOXK3V5eqYczBdieDa6XRK5/N5mZhTuJRQX9e/YZEc1mN13FVur7h8Vbs2V0kqOG4ufEpRpYvFnMIxo+lSQLNf+jIJLTW+udA9Tltm7mx/PB5pv98XQaTW1WF0w3+Gw8RH4FyyqeBRE8zV22twnOeWOJtGatT4NCtfEvwTc2m7/AuczmlsIrRjiS5ryPIyUiV12DS6rkuXy2XEtmwrtZIrgwEbhao+A1SXmM/VstRUhrCYOhoXlh+2wDEXWG64jHDBS8IMfypaJpnYZKzqqQEhcNzNNEkXCsfYWwzwzvFiOFWpdT1CvXPcDAePvF6v/BzEOKzUaupBJe903hEq1rkEx3NRKsX5IJ2UJpylArT3fgDRPFFKKc6BngAAAABJRU5ErkJggg==')"
        },
        drag_NNW : {
            direction: 15,
            directionSetCount: 16,
            center : " 15 25,",
            image : "iVBORw0KGgoAAAANSUhEUgAAAB8AAAAzCAYAAABvwNN0AAACN0lEQVRYR72Y663CMAyFg8RrASYomzA3m8AELFAoEpfkciLXpHHsJPRXoZTPPn62K5c4Xu8DX6/eR+o3Lb77+mMPpjzY0cOIRTiBumEY3OVyic62MmQGh9dE9QjcbDbu+XyGz63UKIbTGCMsj8fDeaOsSnzB/Z9N01SUTzDCK2ExIMK95BowqYYQhmq49yQV75wMuMcMzyWaBEYC/gxOY+3hFnC472N5aCwlktPfWaExXyA5yqYkzWviPCvZVLwhK+9sLTJ8Bqey4wJtrUuhaOH9rM75JMtVQVP40mhdSsTucKkSag0QF4Wc9IfDwd1ut7o6z5WX1P1qvBc97ym9CX6/391+v4+CWed6EZx7zyvAOtfVcEwxv3Bst9swD/z5Z6NRzXY1nHc/Nmjaw3nG0wzPXZOGVJHnFJAqrXfCvRACTemp4d4b7Hp+nnvDTqeTO5/PwdHm8FStEwjd49vHnMNpdpMaD55rNtki2cmcj89xdM5zFUrXKxUcCiC2MGocR7fb7frFnJZNqyVD7bk0aDQZb4LDAMxz3kxKy60KXrtimeGS/CXe/wzuk5Rvx93gNPF4aaIRVcEl6Y/Ho7ter7HzEc//O6E09qTr0oLJ76dLSBM4lzhnME1EMxwJxJ/VJaWq4ZAaU0wC0uvN4CUvE5bAIVQaq/lo1cLpBlQN18jOwWY46htlU2JEqt2aZOeznXaw9XqdfIPZBU7zAOfobIkHjJmz1Z6nEpb3AISF73Zd4Ck1UkvlHxW7UUqpHE1LAAAAAElFTkSuQmCC')"
        },
        drag_NW : {
            direction: 14,
            directionSetCount: 16,
            center : " 20 20,",
            image : "iVBORw0KGgoAAAANSUhEUgAAACkAAAApCAYAAACoYAD2AAABk0lEQVRYR+2YSw6DMAxEYQf3PyzsWhzhKLhxmjHGoKpskNrQvPgzHjoO2/XaLrr3XuN29a71WDcSILonnSkSNEMiwaRDRYKaICmFkaAmyEjAFBCuyd50RwPCkHcA/iZkdMOwxsI1eQeoCZJA53kelmUJEXUVkqdQq+ujGqkKyZuXqdVmcARoMgqlVspNe3T0atDsZgToweUgoGXEvUxIDaZqw1qgRSQPVeFlQiBfWAMt61fWrVcZQJBa/XKD0X2apmFd12TlvDQVhpSgmgLUFMJaoybIliLsJXGQtrNpd4Xco5oARapPOXlXSErnYyN5dV2aI6k1EHf3/r3scFPaT0HWQDWtzN7Q8KZ5GrIELQH3aZP1UozLZkS5rvPBNHeDfi7/BWlNopbI1zyESyRrB0JMCYu85sYug+ypV6kKMvp5CKBpRdf3RrRUg48mQze1rCdQfidCng+LJEP1RFSTr0trUm6KgoZH0hLRP6TWHI9PNwp4mEqIJFjXWgDDIXunz6MkCMlIclPIAx5rpVv69ptkPt4IEhQYxUCjnQAAAABJRU5ErkJggg==')"
        },
        drag_NS : {
            direction: 0,
            directionSetCount: 16,
            center : " 9 26, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAABMAAAA1CAYAAACjpdDnAAABcElEQVRIS+2Xz27CMAzGnV12mJDWExKnvQLv/xB7hZ0mcSoS2oELkHQ4Shz/qbtGaBK5lJb0x4ftz0kCGOMaRwgB4gXiNWjT1S8JyASKsBKEaiyFLIwDzQE2MA1kAStYAu22W/g+HKy8pGQ0McywOYroL1DgBBNB5x+A17dfRvqMA5/F+xIY/IquCVGJzEA/rA3n+2YDx9MJsjI6JVW8NDgjTA5JyriXULoUdPYd7uFqRatml2SvUf1QZcMwwDiObDvqa/T/GzOtQfaPWRk3zmbSwmIru3wCvOwz0/U3qZVKU6ONJWDTtkuDU7OH8BEb6dekUm3btL7KyXe1VSNdBLuryK2qgMgLSldlZVwwla6Ycb5cnE1UUJXHX+qMAtd1AKG5HPDsZ6Incx16l7rn6rTyLgh9yNmGSw52E9ZmXXaO2k6xVqHsaVUvenfbbA+TgmV0kD4nFI/CWYvwHKC7OUpJWXTe5BRaoKmYrcR5zug3w4FMNA163k8AAAAASUVORK5CYII=')"
        },
        drag_S : {
            direction: 8,
            directionSetCount: 16,
            center : " 9 26, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAABMAAAA1CAYAAACjpdDnAAABcElEQVRIS+2Xz27CMAzGnV12mJDWExKnvQLv/xB7hZ0mcSoS2oELkHQ4Shz/qbtGaBK5lJb0x4ftz0kCGOMaRwgB4gXiNWjT1S8JyASKsBKEaiyFLIwDzQE2MA1kAStYAu22W/g+HKy8pGQ0McywOYroL1DgBBNB5x+A17dfRvqMA5/F+xIY/IquCVGJzEA/rA3n+2YDx9MJsjI6JVW8NDgjTA5JyriXULoUdPYd7uFqRatml2SvUf1QZcMwwDiObDvqa/T/GzOtQfaPWRk3zmbSwmIru3wCvOwz0/U3qZVKU6ONJWDTtkuDU7OH8BEb6dekUm3btL7KyXe1VSNdBLuryK2qgMgLSldlZVwwla6Ycb5cnE1UUJXHX+qMAtd1AKG5HPDsZ6Incx16l7rn6rTyLgh9yNmGSw52E9ZmXXaO2k6xVqHsaVUvenfbbA+TgmV0kD4nFI/CWYvwHKC7OUpJWXTe5BRaoKmYrcR5zug3w4FMNA163k8AAAAASUVORK5CYII=')"
        },
        drag_SE : {
            direction: 6,
            directionSetCount: 16,
            center : " 20 20,",
            image : "iVBORw0KGgoAAAANSUhEUgAAACkAAAApCAYAAACoYAD2AAABk0lEQVRYR+2YSw6DMAxEYQf3PyzsWhzhKLhxmjHGoKpskNrQvPgzHjoO2/XaLrr3XuN29a71WDcSILonnSkSNEMiwaRDRYKaICmFkaAmyEjAFBCuyd50RwPCkHcA/iZkdMOwxsI1eQeoCZJA53kelmUJEXUVkqdQq+ujGqkKyZuXqdVmcARoMgqlVspNe3T0atDsZgToweUgoGXEvUxIDaZqw1qgRSQPVeFlQiBfWAMt61fWrVcZQJBa/XKD0X2apmFd12TlvDQVhpSgmgLUFMJaoybIliLsJXGQtrNpd4Xco5oARapPOXlXSErnYyN5dV2aI6k1EHf3/r3scFPaT0HWQDWtzN7Q8KZ5GrIELQH3aZP1UozLZkS5rvPBNHeDfi7/BWlNopbI1zyESyRrB0JMCYu85sYug+ypV6kKMvp5CKBpRdf3RrRUg48mQze1rCdQfidCng+LJEP1RFSTr0trUm6KgoZH0hLRP6TWHI9PNwp4mEqIJFjXWgDDIXunz6MkCMlIclPIAx5rpVv69ptkPt4IEhQYxUCjnQAAAABJRU5ErkJggg==')"
        },
        select_add : {
            center : " 6 9,  ",
            image : "iVBORw0KGgoAAAANSUhEUgAAABIAAAAQCAYAAAAbBi9cAAAAkUlEQVQ4T71UWw7AIAiT+x96o0QThDL8MOMHAxUqD2WoPCoiAj1UC2xBAIFvYZIWQ6gs0DxvwWYilsDymR+aMIiXgCkDIUbJyLM4ZZRqRGrWMyLPqgK3NaItCl3su3bCiGGizeiuEfBOPw7BTp9oXeMzaO1Oo1EN7T1GV2vEFqvZvZSfFu5giX8O5L6Wr0XdWL09R6kBeQ6oDQAAAABJRU5ErkJggg==')"
        },
        select : {
            center : " 6 9,  ",
            image : "iVBORw0KGgoAAAANSUhEUgAAABIAAAAQCAYAAAAbBi9cAAAAdklEQVQ4T92T3QrAIAiFPe//0M0kYXPHJtLVhAjKPo8/QWo21ASAZDsqnElRSOpr9xWQ+gxdO98cdFfRVrQeej2mkp6iCDqqqNU1ktpnT6wTNiTBfGbIOe0ePDoJ6UV+XK0UX7Bziljy7RpF2I9BPhK7Hx/LcQFlbowBzQds/wAAAABJRU5ErkJggg==')"
        },
        drag_SSE : {
            direction: 7,
            directionSetCount: 16,
            center : " 15 25,",
            image : "iVBORw0KGgoAAAANSUhEUgAAAB8AAAAzCAYAAABvwNN0AAACN0lEQVRYR72Y663CMAyFg8RrASYomzA3m8AELFAoEpfkciLXpHHsJPRXoZTPPn62K5c4Xu8DX6/eR+o3Lb77+mMPpjzY0cOIRTiBumEY3OVyic62MmQGh9dE9QjcbDbu+XyGz63UKIbTGCMsj8fDeaOsSnzB/Z9N01SUTzDCK2ExIMK95BowqYYQhmq49yQV75wMuMcMzyWaBEYC/gxOY+3hFnC472N5aCwlktPfWaExXyA5yqYkzWviPCvZVLwhK+9sLTJ8Bqey4wJtrUuhaOH9rM75JMtVQVP40mhdSsTucKkSag0QF4Wc9IfDwd1ut7o6z5WX1P1qvBc97ym9CX6/391+v4+CWed6EZx7zyvAOtfVcEwxv3Bst9swD/z5Z6NRzXY1nHc/Nmjaw3nG0wzPXZOGVJHnFJAqrXfCvRACTemp4d4b7Hp+nnvDTqeTO5/PwdHm8FStEwjd49vHnMNpdpMaD55rNtki2cmcj89xdM5zFUrXKxUcCiC2MGocR7fb7frFnJZNqyVD7bk0aDQZb4LDAMxz3kxKy60KXrtimeGS/CXe/wzuk5Rvx93gNPF4aaIRVcEl6Y/Ho7ter7HzEc//O6E09qTr0oLJ76dLSBM4lzhnME1EMxwJxJ/VJaWq4ZAaU0wC0uvN4CUvE5bAIVQaq/lo1cLpBlQN18jOwWY46htlU2JEqt2aZOeznXaw9XqdfIPZBU7zAOfobIkHjJmz1Z6nEpb3AISF73Zd4Ck1UkvlHxW7UUqpHE1LAAAAAElFTkSuQmCC')"
        },
        drag_SSW : {
            center : " 15 25,",
            image : "iVBORw0KGgoAAAANSUhEUgAAAB8AAAAzCAYAAABvwNN0AAACQElEQVRYR71YbbKCMAysM4JegBPATTw3N9ETeAG+Zt6jHdIJIbRpWuGXWmGzySZZvZkfXn/rBY+/rReFOnxQIhYAxXg2DhpAMXDMsus68/l8DBC3QfwEnLK83+9mnudDArkA1MwtqAWp69oBofKylSsGboGhnjFQiKSqKpcRXHcVcwCXAp8FcCk4TX0WuKTWh95GyleBb6BugKTWHrNXgwMj3GoSDRQHhwdKpiO0pxs6khtC3wkpHyYd1YZnnwMeazmcEW7OZzEPgdO24jbcZeBchtXgKazPSpsF3jSN+X6/og1WjLlUaJx7wUGomJdIuZuOqa1G97i9fxgG83g83KPOXEt22s/2OAJk7VK24HCq7Yi05sCCTtPkX8Mki9UaghGnndaZsk1NubjmAeBb6CymJxFzDACpXo2jv5eeczZZLTjK7vV6mb7vnRm0Z2AOU1MvYg7OhW6pjWH0x0ExtYOisSnA6pemXCw4ypw6F+zjpG0mBqc1H8fRPJ9Pn03wbinAavDdcjj5ERhrMxF4qQ2marUQOOzz1HSLx2up9ZnM/JfAu5pz7vIScLynYYjgUcmmLEPlvuYcOxgabdua9/t9wE5xK6GW8ysRTIGoPwuw9jWP9TI3VLayiBfTqdpTwEELRBuqINxNqeBeMNufiimbbJdFeJMTQBFw7EgkwsPtqBmxu1pRSxQLQLvH2dkuTT2AIs+uF5yk7rYky7K4r2rNA83kIWLOh9NJp6mvaKsF5rwqtcHxyh1yGy4mPs35P5rfVEqyeU0MAAAAAElFTkSuQmCC')"
        },
        select_sub : {
            center : " 6 9,  ",
            image : "iVBORw0KGgoAAAANSUhEUgAAABIAAAAQCAYAAAAbBi9cAAAAhElEQVQ4T81TQQ7AIAiz/3/0hgQXLSgcPIyLScGm1IpWq0eqAWi7EzpBJRcwQ32GMdcXwBEJthDZDGML11bRrKKqyLlkF4cfXUlXfVYUec1EVxWlr1ZRVEmI7r2JgHqURWP09dUoNl8vioat6Iy/p+iqR0wW5Cj1OwzZ/4hGJE4/nnd9ATzWlQFjavMAAAAAAElFTkSuQmCC')"
        },
        subtract : {
            center : " 2 2,  ",
            image : "iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAGklEQVQIW2NkwAIY/wMBujgjUABTEJdKDFMBHqMI/RaD0nIAAAAASUVORK5CYII=')"
        },
        drag_SW : {
            direction: 10,
            directionSetCount: 16,
            center : " 20 20,",
            image : "iVBORw0KGgoAAAANSUhEUgAAACkAAAApCAYAAACoYAD2AAABqUlEQVRYR+2ZwXLDMAhEnZv9/x9r39qiGoYQJGuRipOZ+pJDLPG8ggUnjyX5+vq5kJAPupAFo/cSIBqSnikNkgERIemB0iAjgHRqqZAUMAKaDhkBvQUSBf2HrFkVmpfpSqKA6dVNgNu2Lfu+Q/0gTckeBbkLWaNPgewFZDiGYrn/HBIB5BlCrxHAmQOGnW6sKjYZNYT+zoCW2WLKgOFNN2UwOAeEXkC+79xP2IYhr461mmfAzDYEaQEp7rquy3EcRRRbELUjvvKlMKQHWLOQJ2MGFJQqv3qKnhanFeJ8qlVqJN4UJXXekWNwpSv43wk7oOJQddeUehslM/MxpKSnIBcGfXJ1O5UdTi1ooeeJrc4StZwX83dakgveMm1dIGa/cLHofQTI65mmTYk5ezbiKRqtZlfJlqddtb1Ro+7xzeJptf6qAWqbzcq7FqwLqavVtrqnXOGfQYIm3aNiYek5Tm8zfmeZlXchJZuLkhSUAQNVMiMHX6obgbwDEM7Jj4DM8ES3USDHLYn87oVzB2jIJ7NzUyB73Z/uG3kVQOLIqZ1B4f9WIsGia74BxIYUGL3rV4QAAAAASUVORK5CYII=')"
        },
        drag_W : {
            direction: 12,
            directionSetCount: 16,
            center : " 26 9, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAADUAAAATCAYAAAAwE0VbAAABeklEQVRIS+VXwQrCMAxt8SCo4G6CJ7/B//8Gv8GTsNsEFTyILrXt0qzp0lkZaG9ja/Je3kvWajWwnu3Cn+h2De0p/T4XQxIgBMMcgN9UpHJwsKQcIScUBJ2alBRLlBQlBHYaS4pax8bKsnAunl5wCLDdbNSproPWGEOK2tcFzFU8RgpiOZy0JQJS3GaslGQIQBJJLPedMKaxP12xYntSKRAukHTwWSU8CNrkxM4STlFCGBdW35BiCd2vSs2XoqRk7AeEcIVdZXPVD0BEcGHFkjbJZmM3mASPg9KzvZ+YtnBdPvR+bB7WilaoUnFNHFQ1rJghxL0vBQByp5X60H7YEj2l3j/yZK+wRBlcPt/3e2rXAj96fFp3zyVJBT3lskWHhanIAgzlbYWrV1WVapqmV9BPp18sbjdsWgffb8EAo2P9t/9TScXC5hcfcb59ouBOOf9x9uMUG3P2KzWmc28MovvUerVS58tl8quHFMdgf9Crw1SXRHIMS+J+ATj8wRpyQ2XYAAAAAElFTkSuQmCC')"
        },
        wheel_add_sub : {
            center : " 13 9, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAABsAAAAMCAYAAACTB8Z2AAAAwklEQVQ4T52U0REFEQxFk/qUoAi1KEI/mlDHW4z7JrHWZvlhkBy5STAZx68OZqY6UZ3ZaKaumYwkCNYnQAUbTld7t0BOIvw73sk0n51K2mHNuM3IyVirhwj5et7k/VlS+JNytDuMV846Qab5fOw/Arf+dpHBMMbY3xJCoFIK5ZzJOYfKlGCl1C0ybKzyMMMATCmR917BLG1hrkYZXVu3KCHpUOe1/z71GSBwviuSVdObYMjrqlpXvfn0u5hhAvjJRoIvmILGCbU+GGgAAAAASUVORK5CYII=')"
        },
        wheel_step : {
            center : " 13 9, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAABsAAAAMCAYAAACTB8Z2AAAA4klEQVQ4T51U0RWEIAwr8zGCQziLQ7APSzCHZznCS3vF844ffdI0Tdqa5OE5r5NSkush1zM9hJmwD5AmRQSSMpG/86QRfmI42FXfVeiJhEQKIzy7MJX5QCVBQm/hylJ8J6yxvZMtKuqicE/2GcWscJUHMemLdfMeZAMYEvre0kC9Fd4pQ+LjODrXvu/SWpNaq+ScYdEkRn+5IJ7gJz0TkIGwlCLbthkyVnHbM7KId6kXCmtYnb6rSihA8oWyKSjcMx3XQWJsBskiOccafLhnfkFXOzgUmOR32J/JaJD++lUp/gXZ7CEYd6orLAAAAABJRU5ErkJggg==')"
        },
        wheel_zoom : {
            center : " 19 9, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAACEAAAAQCAYAAACYwhZnAAABEklEQVRIS7WU4RHDIAiFzXyOkCGcJUNkH5fIHG3wQu6BPNt4F3+1lcrH48GSyPmcR6+W84zi5FrCR3Hs//J7+LgAYF6WQOOAdwqkgyAPd5V6UK10RhED4QFU5iZZIDnGSyv891EL8I5CBO0I1QDftHsGDEp1XptWgvhmCMK8FkIItTObUUEf27atFVhKScdxpFpryjlrLAKZVnn1bgjXT9NObzYPoSD7vqd1XQ0EeMkUhiANwgOgCleP6RShGvJZVLmgW57AJ3eBGucd/WjpoCKSnCQNW/FLCbodo5ELxhrVNUpTr+HozK7dC2S4fbFFfrE9qvrf5eMK66YFWtHyvwYRmZ0p/RpEMHU016sQADLM8wUuElMV9kmntgAAAABJRU5ErkJggg==')"
        },
        drag_WNW : {
            direction: 13,
            directionSetCount: 16,
            center : " 25 15,",
            image : "iVBORw0KGgoAAAANSUhEUgAAADMAAAAfCAYAAABKz/VnAAACIklEQVRYR92Ycc6CMAzFZyLiAeQEeBMu7WH0BHoAURM/utjlUVa2Jirz4y8Cg/W3dq8PVs5wPIeDhq+Gw/DY14Ymg2KAF4QPjJhKBFJhIAthZW+3m6uqikCKBBrBYBYo6Mfj4YOWR9EwMgvr9drd73e11ouFIRDez7Es/EpW/J5mmBwQFoFiBcAKs9/v3el0CnupJFXzAmAFkjLNpbg0WIChFT8ej+YGh/2TSxWhRJ9K9jVzAPBAeDlNSnI8p2KpiWJCkoJNvdNyfwTDkmt5QWxsDOAbDiIbxgqK4+Wzn+pTEwcQCxomD95My17f92673Qa167rOHQ4Ht9ls/DUqYzpna5RrXHHvac+YYEC1AovsTwzOQXNPkopp2UvY2HniWK+bqMuwYk9eRa1JSie92+3c+Xz282AW5YQIhBXQNI27XC4jHygVUZYtZXaIcxT/BCZ3FWCF+Btnki3cG/xe6byxXOeEQ6sAhI7qfk59yj0js8VBs9zLlb1er66ua1U4UeYT+zgwvL2JxdzEnLKl2sCcikpVfDsM2qPXeYhXK6MUkHb/KzAMhI1SA8t16zEgKGGflI9kBifWvJn8IJSwudliT0lC8HGYVFBSOKxQWGqLw8SySAG2bZvt4gNQauWWuG/9vvo3MKN+tMTKz82ZkxX+DYb7qwgBiDkJrVHSdfkbLGlnlswWZoadN/hAf6qpcFFqBkFH/+WlWkmRMMJBZMf4B9S/4COrxApbAAAAAElFTkSuQmCC')"
        },
        drag_WSW : {
            direction: 11,
            directionSetCount: 16,
            center : " 25 15,",
            image : "iVBORw0KGgoAAAANSUhEUgAAADMAAAAfCAYAAABKz/VnAAACR0lEQVRYR9WY6a3CMAyAg8Q1AEwAw7A0m8AEZQAuiVfnxZHjOrFTigj9A6WJ7S8+6cw1er36C0yb9ZfVRPNCq8Ap1gEIMgQmL1YDaw4GQQDi8Xi45XIZzwfBclBNw3Avg7fm87mHxIuC/RQMAiwWC/d8Pv0t9VZzMMFAnzM0X3K5SHPr52FCYfDgTcGQcux2u507nU6m4ohe/DoMAuAJ0zywkEQQrW5bhGlrmLHx8KgXUIYlR7i+/X7vPQgsH/OMZqzUFLWD4c+hqkGZRo6PwBQ6+KAB1gLQ9TTEfJi+I0zaSzs4aWy0H5hKrrRXaqK+igU3izA0zkNiqtC4B0eQ+/3uIAxAD3w/HA7ueDx6e+C36/XqVqtV9iyT/iH0HO4V0TM0RGhi5vKrlBtUIcqlkDzhaQqzAXPgTRNMr+wFwx0ZE/4bEtHEy+lms3Fd18VTD+vFfcSIqGO73brL5ZIYzPXRiQC93duZRExyI8U77bA0jnPlFJViuOFBcNmSF0re54WXH/AgzDQYSzm93W5uvV4PPItllEKSwzHnZGlP0sRKw13pmZTFPCykHJi6z5lhakp4KZFBjhQiNfJzaxMYDIWxgqUwrMmNsXpj6IWTeuGMUytQMzY3m9Xqsaz3nsklfklAxgtqIluMGrtmVgsCHjyfz8nf1bHKp95XDSN13qmNGisvwmCV0QQ1DYM5g50ePvnrHA7YKtBgnEHD8XWO9O/vJ2CoB6RpmE+8U3dwLcS152opzb1waA3Ep4lGm/FW1b4aHe+s/QOj8uMjgZQH5gAAAABJRU5ErkJggg==')"
        },
        ew_slider_wheel : {
            center :  " 12 13, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAABoAAAATCAYAAACORR0GAAABPElEQVRIS61ViQ2DMBBLhmgHgBk6Redlis4AA9AhKI7iyLnmQyJSlXJc7PM9wbux9YhuX3Ev2apovsEDIABj36Pfs2PTQDLoGhHBAbwfx+G2bXPzPONwsK3r6qZpct4HiGCLe5GsRBRIAA4Q7jG8d9w/VFnwo+quokQEzxgxCRY5DcDX+VtAZnwRSKasqYigkSyoG7AhqHEi2ySsCe1SM+s6TISDSB/SwrWAKDZDsMkz06qElxWhDlhsbwVlvajAjkCzGbKOOz0JgkNUiGi51JY69Xz513naDImkkX9bj+zZdF9GRqKspZtogy9lkEObg+h2EgCbm+RbVQTHqwtXkiFJN8ntNRIlel0lRQw+pLEzIzWhOmsZCWtkD+pnQdu7l0k7a9nQtj4TOiPV74yw620ydDNoGvF/hKR75gc/gagpSBM4aQAAAABJRU5ErkJggg==')",
        },        
        flood_fill : {
            center : " 4 18, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAABEAAAAXCAYAAADtNKTnAAABbUlEQVQ4T62UTUrFMBSFUxScOdKBoCDtEgrO3qwVBCciuJa3hHYrdgsdPHDoWHTSh6LgLyiCOJJ6TsgtaZukT7BwSHpz8/Xc/DRS//BEE4zWjK+j/fHlhiBtlmV6Xl3XbBJo6QL5IB3AgnhBLkgPIJC2bVUU6fSRoz9BSHCBhhCvC3sthqARhLblYbL97gM5IeZLqmkaPS+OY+fuiiMvpCgKlaZpD2DDyrJU8/mc8FkQwgyCbDcCMi5OMfYSLIduXKCqqsTFMcbvQpAzJJy7QEnCo6JOoHfoKgSRpIUNyvNcAF/ocOWXIcgREp6hb+ja2h7COwDjI4iJ8bAcmi99ot2E9qA1iLf5ng4ELBA5YTZUYtsmmfXvQI8G1JnjJBxKfbk0gC+DPsN08WCV1Ouu4oRlfUCXU5BdJOxDF9aaHKC/YSberuKEuVvQq/XfmBkHT2jffC4YH+6OBkEsgVt7MwVwQRhjabIL3sW0nf0CgMme8t9KbzsAAAAASUVORK5CYII=')",
        },
        flood_fill_diagonal : {
            center : " 7 18, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAABQAAAAYCAYAAAD6S912AAAB0klEQVRIS52UPUvEQBCGN6iFjZUWgoLeVbZeLVxxUQQbEfwt+Ql3f8VrBZsrBDsFK8UqB4eC+IUgqI0S33fZCZNNNgkGhv2Y3WffnZlsZNp/mVs6j/Y3tC1qycsGg4FdOplM2HRh06q9bYA5TAGD0CZgASbALMtMFNmtJaX/BpJWBa0DBtXp2PnQWiCvJh836nEI2gh0CkyappbR6XQqC0OUtgIOh0PT6/UKMA0ejUYmSRIetNMayNWEapUCdeqO4HvWQAasMFblYaiyCjoej0XdAfwzAWBvXlvrcDzCftTcMcYnVdBul6VoDmHvsNuQoi047xRQNpxraBzHAvtEh1mblhTqa6r+PhY/wb55kEozD8phnCdQX5dxOFUg64ftOgUfaJdgDMscjK/OPZXJIblCTPRhi7Az5/QTxukV52O8VmGMdeEpk03LcGzCLp06O0/pKAnd5zTVPYgiv/XrkOCXGoWM5Rvsyq3xS61Qd3LYGjobsAtYVYxnmL9xF5AXh6F4JSD0p1ilgYxvw3etfH2Mv0R13a8n1+c1mdE8+wq2R6UwlpKNa9MDy+szm6y/BU8ZD2KGbUFLvJqAsk5avl0EsC75FWBtFPpAjkU1a7BUPn8rpNfzRVmM0wAAAABJRU5ErkJggg==')", 
        },
        flood_fill_edge : {
            center : " 5 18, ",
            image : "iVBORw0KGgoAAAANSUhEUgAAABIAAAAYCAYAAAD3Va0xAAABhklEQVQ4T52UzUrEMBSFWxSfQBeCq3btquvZtYIggvgyfYT2WYprN136Bs4gCB0RBUUFN4ooSj0nJPU2TVpq4JLM3Jsv5/7QMJherQ7ZxP7jCw8nOG2apiqkrmtuMWztujMG6iAC5IX5QD2IAbVtG4ShujJQNhtEigvmAnnVyNrYMCeIKZjFC/K3D+YF6ReDpmnU3SiKnA02ykZBRVEESZL0IBJYlmWQ5zkfWEyCGEWYVGVgWs0pfE+TqVGVC1ZVlVFzBP+tDVJVFvOiIC5YHHOUghPYK2wlQbj/1y3ZNRuWZZmBvOPAbqwNiIQd2LNDEWtwZrWMSjoIfQQpJbpwUzUj9BP2Brujkk75TNAx4h9hN7AXqbJTpORpWZQoz9rH7RB2LZX8VxFBS9i9VbPZNToA4MoH2oDjW8s+d3RtH/9dav8H9gvY4JNrurTHLozM0QJ+PsiZGaSlaihy3cZZzZG1WBcqWcF6nZJx9txQGWd/SytgCl9jSgzMNYBMYVe89uCqiS37F/+ivvNB1JEYAAAAAElFTkSuQmCC')",
        },
        

    }
    const cursorNames = [];
    for(var i in cursors){
        if(cursors[i].image){
            cursorNames.push(i);
        }
    }

    
    
    (()=>{
        const curNS = new Image();
        const curEW = new Image();
        curNS.src = "icons/mouse_rotate_skew_ns.png";
        curEW.src = "icons/mouse_rotate_skew_ew.png";
        curEW.onload = curNS.onload = loaded;
        var count = 0;
        var can = document.createElement("canvas");
        var ctx = can.getContext("2d");
        function getDataURL(img, {x,y,w,h,name,direction}){
            can.width = w;
            can.height = h;
            ctx.drawImage(img, -x, -y);
            var data = ctx.getImageData(0,0,w,h);
            var d32 = new Uint32Array(data.data.buffer);
            var i = 0;
            var xx = 0;
            var yy = 0;
            while(i < d32.length){
                if(d32[i] === 0xFFFF00FF) { d32[i] = 0 }
                else if (d32[i] === 0xFF0000FF) {
                    d32[i] = 0;
                    xx = i % w;
                    yy = (i / w) | 0;
                }
                i++;
            }
            ctx.putImageData(data,0,0);
            var cursor = {
                direction,
                directionSetCount: 8,
                center : " " + xx + " " + yy + ", ",
                image : can.toDataURL().replace("data:image/png;base64,", "")+"')",
            }
            cursors[name] = cursor;
            cursorNames.push(name);
        }
        const nsSet =  [
            { x : 0, y : 0, w : 41, h : 41, name : "rotate_NW_skew_ns",direction : 7},
            { x : 42, y : 0, w : 41, h : 41, name : "rotate_NE_skew_ns",direction : 1 },
            { x : 0, y : 42, w : 41, h : 41, name : "rotate_SW_skew_ns",direction : 5  },
            { x : 42, y : 42, w : 41, h : 41, name : "rotate_SE_skew_ns",direction : 3 },
            { x : 0, y : 84, w : 45, h : 35, name : "rotate_N_skew_ns",direction : 0 },
            { x : 46, y : 84, w : 45, h : 35, name : "rotate_S_skew_ns",direction : 4 },
            { x : 0, y : 120, w : 30, h : 45, name : "rotate_W_skew_ns",direction : 6 },
            { x : 31, y : 120, w : 29, h : 45, name : "rotate_E_skew_ns" ,direction : 2 },
        ];
        const ewSet =   [
            { x : 0, y : 0, w : 41, h : 41, name : "rotate_NW_skew_ew",direction : 7},
            { x : 42, y : 0, w : 41, h : 41, name : "rotate_NE_skew_ew",direction : 1 },
            { x : 0, y : 42, w : 41, h : 41, name : "rotate_SW_skew_ew",direction : 5 },
            { x : 42, y : 42, w : 41, h : 41, name : "rotate_SE_skew_ew",direction : 3 },
            { x : 0, y : 84, w : 36, h : 45, name : "rotate_E_skew_ew",direction : 2 },
            { x : 37, y : 84, w : 35, h : 45, name : "rotate_W_skew_ew",direction : 6 },
            { x : 0, y : 130, w : 45, h : 30, name : "rotate_S_skew_ew",direction : 4 },
            { x : 46, y : 130, w : 45, h : 29, name : "rotate_N_skew_ew",direction : 0 },
        ];
            
            
            
        
        function loaded(){
            count += 1;
            if(count === 2){
                
                nsSet.forEach(s => getDataURL(curNS,s));
                ewSet.forEach(s => getDataURL(curEW,s));
                
                
                
                can = undefined;
                ctx = undefined;
                
                
                
            }
        }
    })();
        
    return {
        cursors,
        names : cursorNames,
    };
})();


const mouse = {
    captured : 0,
    requestCapture(id,element){
        if(mouse.captured === 0){
            mouse.captured = id;
           // log("Mouse captured "+id);
            if(element){
                mouse.element = element;
                mouse.forElement(element);
                
            }
            return true;
        }
        if(mouse.captured === id) { return true }
        return false;
    },
    release(id){
        if(mouse.captured === 0 || mouse.captured === id || id === -1){
            mouse.captured = 0;
            mouse.element = undefined;
            if(id === -1) { 
                mouse.cancelButtons();
                if(mouse.inSavedState){ mouse.restore() }
            }
            return true;
        }
        return false;
    },
    cancelButtons(id){
        if(mouse.captured === 0 || mouse.captured === id){
            mouseEvents({type : "cancel"});
            mouse.requestCursor(0,"default");
        }
    },
    onbutton : null,
    onGlobalClick : null,
    onmove : null,
    x : 0,
    y : 0,
    oldX : 0,
    oldY : 0,
    rx : 0,  // world coords (r is for real)
    ry : 0, 
    page : { x : 0, y : 0},
    button : 0,
    oldButton : 0,
    buttons : [1, 2, 4, 6, 5, 3],
    wheel : 0,
    bounds : null,
    downOn : null,
    getPos(pos) { return (pos.x = mouse.x, pos.y = mouse.y, pos) },
    forElement(el = mouse.element){
        mouse.bounds = el.getBoundingClientRect();
        mouse.x = mouse.page.x - mouse.bounds.left - scrollX;
        mouse.y = mouse.page.y - mouse.bounds.top - scrollY;
        if(mouse.x < mouse.bounds.left || mouse.x > mouse.bounds.right || mouse.x < mouse.bounds.top || mouse.x > mouse.bounds.bottom){
            mouse.over = false;
        }else {
            mouse.over = true;
        }
    },
    cursor : "defualt",
    cursorName : "default",
    cursorAngle : undefined,
    requestCursor(id,name,angle){
        if(mouse.captured === 0 || mouse.captured === id){
            if(name !== mouse.cursorName || angle !== mouse.cursorAngle){
                var cursor = mouse.cursorName = name;
                mouse.cursorAngle = angle;
                if(customCursors.cursors.nativeCursors[cursor] !== undefined){
                    var curs = customCursors.cursors.nativeCursors[cursor];
                    if(angle !== undefined){
                        if(curs.direction !== undefined){
                            var name = cursor.split("_");
                            name[1] = customCursors.cursors.getAngleName(angle, curs);
                            cursor = name.join("_");
                        }
                    }
                    var curs = customCursors.cursors.nativeCursors[cursor];
                    mouse.cursor = curs.name;
                }else if(customCursors.cursors[cursor] !== undefined){
                    var curs = customCursors.cursors[cursor];
                    if(angle !== undefined){
                        if(curs.direction !== undefined){
                            var name = cursor.split("_");
                            name[1] = customCursors.cursors.getAngleName(angle,curs);
                            cursor = name.join("_");
                        }
                    }
                    var curs = customCursors.cursors[cursor];
                    mouse.cursor = customCursors.cursors.encoding + curs.image + curs.center + " pointer"; 
                }else {
                    mouse.cursor = name;
                    
                }
            }else {
                mouse.cursorName = name;
                mouse.cursor = name;
                mouse.cursorAngle = angle;
            }
        }
    },
    updateCursor(element){
        element.style.cursor = mouse.cursor;
    },
    savedState : {
        x : 0, y : 0, button : 0, alt : false, ctrl : false, shift : false 
    },
    inSavedState : false,
    save(){
        mouse.savedState.x = mouse.x;
        mouse.savedState.y = mouse.y;
        mouse.savedState.oldButton = mouse.oldButton;
        mouse.savedState.button = mouse.button;
        mouse.savedState.ctrl = mouse.ctrl;
        mouse.savedState.alt = mouse.alt;
        mouse.savedState.shift = mouse.shift;
        mouse.inSavedState = true;
    },
    set state(stateObj){
        mouse.x = stateObj.x !== undefined ? stateObj.x : mouse.x;
        mouse.y = stateObj.y !== undefined ? stateObj.y : mouse.y;
        mouse.oldButton = stateObj.oldButton !== undefined ? stateObj.oldButton : 0;
        mouse.button = stateObj.button !== undefined ? stateObj.button : 0;
        mouse.ctrl = stateObj.ctrl === true;
        mouse.alt = stateObj.alt === true;
        mouse.shift = sstateObj.shift === true;
        
        
    },
    restore(){
        if(mouse.inSavedState){
            mouse.x = mouse.savedState.x;
            mouse.y = mouse.savedState.y;
            mouse.oldButton = mouse.savedState.oldButton;
            mouse.button = mouse.savedState.button;
            mouse.ctrl = mouse.savedState.ctrl;
            mouse.alt = mouse.savedState.alt;
            mouse.shift = mouse.savedState.shift;
        }
        mouse.inSavedState = false;
    },
    
}
function mouseEvents(e){
    if(e.type === "cancel"){
        mouse.oldButton = mouse.button;
        mouse.button = 0;
        return;
        
    }
    mouse.oldX = mouse.x;
    mouse.oldY = mouse.y;
    mouse.x = mouse.page.x = e.pageX;
    mouse.y = mouse.page.y = e.pageY;
    mouse.alt = e.altKey;
    mouse.shift = e.shiftKey;
    mouse.ctrl = e.ctrlKey;      
    if(mouse.element) { mouse.forElement() }
    if (e.type === "mousemove") {
        if (mouse.onmove) { mouse.onmove(mouse,e) }
    }else if (e.type === "mousedown") { 
        mouse.oldButton = mouse.button;
        mouse.button |= mouse.buttons[e.which-1];
        mouse.downOn = e.target;
        if (e.target.onDrag){ e.target.onDrag(mouse,e) }
        else if (mouse.onbutton) { mouse.onbutton(mouse,e) }
    } else if (e.type === "mouseup") { 
        mouse.oldButton = mouse.button;
        mouse.button &= mouse.buttons[e.which + 2];
        if (mouse.onbutton) { mouse.onbutton(mouse,e) }
        if(mouse.captured === 0 && mouse.downOn !== null && mouse.downOn === e.target && mouse.onGlobalClick){
            mouse.onGlobalClick(e);
        }
        mouse.downOn  = null;
    } else if (e.type === "wheel") { 
        if(Math.abs(e.deltaY) < 100){
            mouse.wheel += -e.deltaY * 30;
        }else{
            mouse.wheel += -e.deltaY;
        }
        if(e.target.updateWheel) { e.target.updateWheel(mouse,e) }
    }    
}
["mousedown","mouseup","mousemove","wheel"].forEach(name => document.addEventListener(name,mouseEvents));
document.addEventListener("contextmenu",(e)=>{e.preventDefault()});

const keyboard = (()=>{
    
    const keys = {};
    var defaultMode;
    var activeMode;
    var activeModeName;
    const API = {
        addMode(modeName){
            if(keys[modeName] === undefined){
                keys[modeName] = {};
            }
            if (defaultMode === undefined) { defaultMode = modeName }
                
        },
        set defaultMode(name) { defaultMode = name },
        get mode() { return activeModeName },
        set mode(name){ 
            //log("key mode set to " + name);
            if(name.toLowerCase() === "default"){ name = defaultMode }
            activeModeName = name;
            activeMode = keys[name];
        },   

        mapKeyCommand(keyName, keyMods = {}, mode = activeModeName, command){
            if(keys[mode] === undefined){
                API.addMode(mode);
            }
            const modName = "M" + (keyMods.alt ? "a" : "") + (keyMods.shift ? "s" : "") +  (keyMods.ctrl ? "c" : "");
            if(keys[mode][keyName] === undefined){
                keys[mode][keyName] = {};
            }
            keys[mode][keyName][modName] = {
                command,
                alt : keyMods.alt ? true : false,
                shift : keyMods.shift ? true : false,
                ctrl : keyMods.ctrl ? true : false,
                oldButton : keyMods.second ? 4 : 1,
                button : keyMods.second ? 4 : 1,
            }
        }
        
        
    }
    function keyEvent(event){
        if(event.type === "keydown"){
            if(activeMode[event.code]){
                const modName = "M" + (event.altKey ? "a" : "") + (event.shiftKey ? "s" : "") +  (event.ctrlKey ? "c" : "");
                const key = activeMode[event.code][modName];
                if(key){
                    mouse.save();
                    mouse.state = key;
                    issuseCommand(key.command);
                    mouse.restore();
                    event.preventDefault();
                }
            }
        }
        
    }
    document.addEventListener("keydown",keyEvent);
    
    return API;
})();





