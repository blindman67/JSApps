"use strict";
const functionLinkBuilder = (()=> {
    const functionLink = {
        functions: (()=> {
            var val = 0, str, strJoin = "", count = 0, min, max, vals = [], num,rgb = [],RGB={r:0,g:0,b:0};
            return {
                system: {
                    rand(f) { return f.value = Math.random() * f.scale + f.offset },
                    acc(f) { return f.value += f.offset },
                    default(f) { return f.value },
                },
                reset(f) {
                    if (f.follow !== undefined) { f.follow = undefined }
                    if (f.prev !== undefined) { f.prev = undefined }
                    if (f.acc !== undefined) { f.acc = undefined }
                    f.blocks = 0;
                    if (f.type === "cap") {
                        f.cap = true
                        f.resetOnChange = true;
                    } else {
                        if(f.cap !== undefined) { f.cap = undefined }
                        if(f.resetOnChange !== undefined) { f.resetOnChange = undefined }
                        if(f.captureList !== undefined) {
                            f.captureList = undefined;
                            f.outputs.forEach(spr => {
                                if(spr.captureList !== undefined) { delete spr.captureList }
                            });
                        }
                    }
                },
                rgb(v, start, end, f) {
                     if (end) {
                        if(count === 1) {
                            rgb[2] = rgb[1] = rgb[0];
                            count =1;
                        } else if(count === 2){
                            rgb[0] = rgb[1] = rgb[2] = rgb[0] + rgb[1];
                            count = 2;
                        } else {
                            count = Math.ceil(count / 3);
                        }
                        RGB.r = (Math.unit(rgb[0] / count * f.scale + f.offset) * Math.W16) ** 0.5 | 0;
                        RGB.g = (Math.unit(rgb[1] / count * f.scale + f.offset) * Math.W16) ** 0.5 | 0;
                        RGB.b = (Math.unit(rgb[2] / count * f.scale + f.offset) * Math.W16) ** 0.5 | 0;
                        return f.value = RGB;
                    }
                    if (start) { rgb[0] = rgb[1] = rgb[2] = 0, count = 0 }
                    else {
                        if(v.g !== undefined) {
                            rgb[(count++) % 3] += v.r * v.r / Math.W16;
                            rgb[(count++) % 3] += v.g * v.g / Math.W16;
                            rgb[(count++) % 3] += v.b * v.b / Math.W16;
                        } else {
                            rgb[(count++) % 3] += v;
                        }
                    }
                },
				A(v, start, end, f) { if (end) { return 0 } },
                acc(v, start, end, f) {
                    if (end) { return f.value }
                    if (!start) { f.value +=  v * f.scale + f.offset }
                },
                sum(v, start, end, f) {
                    if (end) { return f.value = val  * f.scale + f.offset }
                    if (start) { val = 0 }
                    else { val += v }
                },
                flr(v, start, end, f) {
                    if (end) { return f.value = Math.floor(val  * f.scale + f.offset) }
                    if (start) { val = 0 }
                    else { val += v }
                },
                rnd(v, start, end, f) {
                    if (end) { return f.value = Math.round(val  * f.scale + f.offset) }
                    if (start) { val = 0 }
                    else { val += v }
                },
                dif(v, start, end, f) {
                    if (end) {
                        val = val === undefined ? 0 : val;
                        return f.value = val  * f.scale + f.offset
                    }
                    if (start) { val = undefined }
                    else { val = val === undefined ? v : val - v }
                },
                div(v, start, end, f) {
                    if (end) {
                        val = val === undefined ? 0 : val;
                        return f.value = val  * f.scale + f.offset
                    }
                    if (start) { val = undefined }
                    else { val = val === undefined ? v : (v === 0 ? 0 : val / v) }
                },
                mult(v, start, end, f) {
                    if (end) { val = val === undefined ? 0 : val; return f.value = val  * f.scale + f.offset }
                    if (start) { val = undefined }
                    else { val = val === undefined ? v : val * v }
                },
                chase(v, start, end, f) {
                    if (end) {
                        if(f.follow === undefined) {
                            f.follow = 0;
                            f.value = val;
                        }
                        var s = f.scale;
                        var o = f.offset;
                        s = s < 0 ? 0 : s > 1 ? 1 : s;
                        o = o < 0 ? 0 : o > 1 ? 1 : o;
                        f.follow = ((f.follow += (val - f.value) * s) * o);
                        f.value += f.follow
                        return f.value;
                    }
                    if (start) { val = 0 }
                    else { val += v }
                },
                spring(v, start, end, f) {
                    if (end) {
                        if(f.follow === undefined) {
                            f.follow = 0;
                            f.value = val;
                        }
                        var s = f.scale;
                        var o = f.offset;
                        f.scale = s = s < 0 ? 0 : s;
                        f.offset = o = o < 0 ? 0 : o > 1 ? 1 : o;
                        var dif = Math.abs(val - f.value);
                        s = dif <= 10 ? s * (dif / 10) : s;
                        f.follow = (f.follow += Math.sign(val - f.value) * s) * (1 - o);
                        f.value += f.follow
                        return f.value;
                    }
                    if (start) { val = 0 }
                    else { val += v }
                },
                ecurve(v, start, end, f) {
                    if (end) { return f.value = eCurve(val, f.offset) + f.scale }
                    if (start) { val = 0 }
                    else { val += v }
                },
                scurve(v, start, end, f) {
                    if (end) { return f.value = sCurve(val, f.offset) + f.scale }
                    if (start) { val = 0 }
                    else { val += v }
                },
                sqrWave(v, start, end, f) {
                    if (end) {
                        val = Math.abs(val * f.scale + f.offset) % 1;
                        return f.value = val < 0.5 ? 0 : 1;
                    }
                    if (start) { val = 0 }
                    else { val += v }
                },
                pulseWave(v, start, end, f) {
                    if (end) {
                        if (count === 1) {
                            val = Math.abs(val * f.scale + f.offset) % 1;
                            return f.value = val < 0.5 ? 0 : 1;
                        }
                        num = Math.abs(vals[0] * f.scale + f.offset) % 1;
                        return f.value = num < Math.abs(val % 1) ? 1 : 0;
                    }
                    if(start) { count = 0; return }
                    if(count === 0) {
                        val = v;
                        vals[0] = 0;
                        count = 1;
                    } else { vals[0] += v }
                    count++;
                },
                triangleWave(v, start, end, f) {
                    if (end) {
                        if (count === 1) {
                            val = (Math.abs(val * f.scale + f.offset) % 1) * 2;
                            return f.value = val <= 1 ? val : 2 - val;
                        }
                        const pos = Math.abs(val % 1), posInv = 1 - pos;
                        num = Math.abs(vals[0] * f.scale + f.offset) % 1;
                        return f.value = num < pos ? num / pos : num > pos ? 1 - (num - pos) / posInv : 0;
                    }
                    if(start) { count = 0; return }
                    if(count === 0) {
                        val = v;
                        vals[0] = 0;
                        count = 1;
                    } else {
                        vals[0] += v;
                        count = 2;
                    }

                },
                delay(v, start, end, f) {
                    if (end) {
                        if(f.prev === undefined) { f.value = f.prev = val }
                        f.value = f.prev * f.scale + f.offset;
                        f.prev = val;
                        return f.value;
                    }
                    if (start) { val = 0 }
                    else { val += v }
                },
                cmpEq(v, start, end, f) {
                    if (end) { return f.value = count === 1 ? 1 : 0 }
                    if (start) { count = 0 }
                    else if(count === 0) {
                        count = 1;
                        val = v;
                    } else if(count === 1) {
                        count = val === v ? 1 : 2;
                    }
                },
                cmpGtLt(v, start, end, f) {
                    if (end) { return f.value = count === 1 ? 1 : 0 }
                    if (start) { count = 0 }
                    else if(count === 0) {
                        count = 2;
                        val = v;
                    } else if(count > 0) {
                        count = (f.scale > 0 && val < v) || (f.scale < 0 && val > v) ? 1 : count;
                    }
                },
                mean(v, start, end, f) {
                    if (end) { return f.value = (val / count)  * f.scale + f.offset }
                    if (start) { val = 0; count = 0 }
                    else { val += v; count += 1 }
                },
                abs(v, start, end, f) {
                    if (end) { return f.value = Math.abs(val) * f.scale + f.offset }
                    if (start) { val = 0}
                    else { val += v }
                },
                min(v, start, end, f) {
                    if (end) { return f.value = min  * f.scale + f.offset }
                    if (start) { min = Infinity }
                    else { min = Math.min(v, min) }
                },
                max(v, start, end, f) {
                    if (end) { return f.value = max  * f.scale + f.offset }
                    if (start) {  max = -Infinity }
                    else { max = Math.max(v, max) }
                },
                mod(v, start, end, f) {
                     if (end) {
                        val = val  * f.scale + f.offset;
                        return f.value = ((val  % 1) + 1) % 1;
                    }
                    if (start) { val = 0 }
                    else { val += v }
                },
                sqr(v, start, end, f) {
                    if (end) { return f.value = val * val  * f.scale + f.offset }
                    if (start) { val = 0 }
                    else { val += v }
                },
                sqrt(v, start, end, f) {
                    if (end) { return f.value = Math.sqrt(Math.abs(val))  * f.scale + f.offset }
                    if (start) { val = 0 }
                    else { val += v }
                },
                pow(v, start, end, f) {
                    if (end) { return f.value = (Math.abs(val- num) ** num)  * f.scale + f.offset }
                    if (start) { val = 0; num = 0}
                    else {
                        val += v;
                        num = v;
                    }
                },
                sin(v, start, end, f) {
                    if (end) { return f.value = Math.sin(val)  * f.scale + f.offset }
                    if (start) { val = 0 }
                    else { val += v }
                },
                cos(v, start, end, f) {
                    if (end) { return f.value = Math.cos(val)  * f.scale + f.offset }
                    if (start) { val = 0 }
                    else { val += v }
                },
                asin(v, start, end, f) {
                    if (end) { return f.value = Math.asinc(val)  * f.scale + f.offset }
                    if (start) { val = 0 }
                    else { val += v }
                },
                acos(v, start, end, f) {
                    if (end) { return f.value = Math.acosc(val)  * f.scale + f.offset }
                    if (start) { val = 0 }
                    else { val += v }
                },
                sign(v, start, end, f) {
                    if (end) { return f.value = Math.sign(val)  * f.scale + f.offset }
                    if (start) { val = 0 }
                    else { val += v }
                },
                tan(v, start, end, f) {
                    if (end) { return f.value = Math.tan(val)  * f.scale + f.offset }
                    if (start) { val = 0 }
                    else { val += v }
                },
                tan2(v, start, end, f) { // AKA direction
                    if (end) {
                        if(vals.length < 2) { return 0 + f.offset }
                        return f.value = Math.atan2(vals[1], vals[0])  * f.scale + f.offset
                    }
                    if (start) { vals.length = 0 }
                    else { vals[vals.length] = v }
                },
                hypot(v, start, end, f) {
                    if (end) { return f.value = Math.hypot(...vals)  * f.scale + f.offset }
                    if (start) { vals.length = 0 }
                    else { vals[vals.length] = v }
                },
                vdot(v, start, end, f) {
                    if (end) { return f.value = (vals[0] * vals[2] + vals[1] * vals[3])  * f.scale + f.offset }
                    if (start) { vals.length = 0 }
                    else { vals[vals.length] = v }
                },
                vcross(v, start, end, f) {
                    if (end) { return f.value = (vals[0] * vals[3] - vals[1] * vals[2])  * f.scale + f.offset }
                    if (start) { vals.length = 0 }
                    else { vals[vals.length] = v }
                },
                uvdot(v, start, end, f) {
                    if (end) { return f.value = Math.uVecDot2d(vals[0], vals[1], vals[2], vals[3])  * f.scale + f.offset }
                    if (start) { vals.length = 0 }
                    else { vals[vals.length] = v }
                },
                uvcross(v, start, end, f) {
                    if (end) { return f.value = Math.uVecCross2d(vals[0], vals[1], vals[2], vals[3])  * f.scale + f.offset }
                    if (start) { vals.length = 0 }
                    else { vals[vals.length] = v }
                },
                svdot(v, start, end, f) {
                    if (end) { return f.value = Math.sVecDot2d(vals[0], vals[1], vals[2], vals[3]) * f.scale + f.offset }
                    if (start) { vals.length = 0 }
                    else { vals[vals.length] = v }
                },
                svcross(v, start, end, f) {
                    if (end) { return f.value =  Math.sVecCross2d(vals[0], vals[1], vals[2], vals[3])  * f.scale + f.offset }
                    if (start) { vals.length = 0 }
                    else { vals[vals.length] = v }
                },
                vAng(v, start, end, f) {
                    if (end) { return f.value = Math.angleVec2d(vals[0], vals[1], vals[2], vals[3])  * f.scale + f.offset }
                    if (start) { vals.length = 0 }
                    else { vals[vals.length] = v }
                },
                vClamp(v,start,end,f) {
                    if (end) {
                        if(count <= 1) {
                            return f.value = val  < f.scale ? f.scale : val > f.offset ? f.offset : val;
                        }
                        if(count === 2) {
                            if (vals[0] < 0) {
                                return f.value = (val < vals[0] ? vals[0] : val > 0 ? 0 : val) * f.scale + f.offset;
                            }
                            return f.value = (val < 0 ? 0 : val > vals[0] ? vals[0] : val) * f.scale + f.offset;
                        }
                        return f.value =  (val < vals[0] ? vals[0] : val > vals[1] ? vals[1] : val) * f.scale + f.offset;
                    }
                    if (start) { val = 0; num = undefined; count = 0 }
                    else if(count === 0) {
                        val = v;
                        count = 1;
                    } else {
                        vals[count-1] = v;
                        count ++;
                    }
                },
                vMod(v,start,end,f) {
                    if (end) {
                        if(num === undefined) {
                            return f.value = (val % f.offset + f.offset) %  f.offset;
                        }
                        num = num  * f.scale + f.offset;
                        return f.value = (num % val + val) % val;
                    }
                    if (start) { val = 0; num = undefined; count = 0 }
                    else if(count === 0) {
                        count = 1;
                        val = v;
                    } else {
                        (num === undefined && (num = v)) || (num += v);
                    }
                },
                cMod(v,start,end,f) {
                    if (end) {
                        if(num === undefined) {
                            num = f.offset + f.offset;
                            num = (val % num + num) %  num;
                            num = num > f.offset ? (f.offset * 2) - num : num;
                            return f.value = num;
                        }
                        num = num  * f.scale + f.offset;
                        var n = val + val;
                        n = (num % n + n) %  n;
                        n = n > val ? (val * 2) - n : n;
                        return f.value = n;
                    }
                    if (start) { val = 0; num = undefined; count = 0 }
                    else if(count === 0) {
                        count = 1;
                        val = v;
                    } else {
                        (num === undefined && (num = v)) || (num += v);
                    }
                },
                toUnit(v,start,end,f) {
                    if (end) {
                        if(num === undefined) {
                            if(Math.abs(f.scale) < 0.01) {
                                val = (val - f.offset) /  (f.scale < 0 ? -0.01 : 0.01);
                            } else {
                                val = (val - f.offset) /  f.scale;
                            }
                            return f.value = val  < 0 ? 0 : num > 1 ? 1 : val;
                        }
                        if(Math.abs(val) < 0.01) {
                            num = (num * f.scale + f.offset) / (val < 0 ? -0.01 : 0.01);
                        } else {
                            num = (num * f.scale + f.offset) / val;
                        }
                        return f.value = num  < 0 ? 0 : num > 1 ? 1 : num;
                    }
                    if (start) { val = 0; num = undefined; count = 0 }
                    else if(count === 0) {
                        count = 1;
                        val = v;
                    } else {
                        (num === undefined && (num = v)) || (num += v);
                    }
                },
                clamp(v, start, end, f) {
                    if (end) {
                        val = val  * f.scale + f.offset;
                        return f.value = val  < 0 ? 0 : val > 1 ? 1 : val;
                    }
                    if (start) { val = 0 }
                    else { val += v }
                },
                rand(v, start, end, f) {
                    if (end) { return f.value = (Math.random() * val) * f.scale + f.offset }
                    if (start) { val = 0 }
                    else { val += v }
                },
                select(v,start,end,f) {
                    if(end) { return f.value = val * f.scale + f.offset }
                    if(start) { count = 0 ; return }
                    if(count === 0) {
                        num = Math.floor(v * (f.inputs.length - 1)) + 1;
                    } else if(count === num || (count === 1 && num < count) || num > count) {
                        val = v;
                    }
                    count++;
                },
                swch(v,start,end,f) {
                    if(end) {
                        if (val > 1 || val <0) {
                            f.acc = 1;//Math.floor(val);
                            f.idx = (f.idx + (val > 1 ? 1 : count - 2)) % (count - 1);
                            f.val = vals[f.idx];
                        }
                        return f.value = f.val * f.scale + f.offset;
                    }
                    if(start) {
                        count = 0;
                        return;
                    }
                    if(count === 0) {
                        if(f.acc === undefined) { f.acc = Math.floor(v); f.idx = 0; f.val = 0 }
                        val = v;
                    } else {
                        vals[count - 1] = v;
                    }
                    count++;
                },
                trig(v,start,end,f) {
                    if(end) {
                        if (val < 0) { return f.value = num * f.scale  + f.offset }
                        return f.value =  undefined;
                    }
                    if(start) {
                        count = 0;
                        val = 0;
                        num = 0;
                        return;
                    } else if(count === 0) {
                        val = v;
                        count = 1;
                    } else { num += v }
                },
                cap(v,start,end,f) {
                    if(end) {
                        if(f.cap === true) {
                            f.resetOnChange = true;
                            f.cap = false;
                            f.value = f.captureList.size;
                            return f.captureList;
                        }
                        return f.value = f.captureList ?  f.captureList.size : 0;
                        return f.value;
                    }
                    if(start && f.cap === true) {
                        if(f.captureList === undefined) {
                            f.captureList = new Set(f.inputs);
                        } else {
                            f.captureList.clear();
                            for(const spr of f.inputs) { f.captureList.add(spr) }
                        }
                    }
                },
                map(v,start,end,f) {
                    if(end) {
                        return f.value =  val * f.scale  + f.offset;
                    }
                    if (start) {
                        count = 0;
                        val = 0;
                        return;
                    }
                    if (count === 0) {
                        if (v.text !== undefined) {
                            if (!f.map) {
                                f.map = new Map();
                            }
                            if (f.map && f.map.text !== v.text) {
                                f.map.clear();
                                f.map.text = v.text;
                                f.map.lastValue = 0;
                                const t = v.text.replace(/\].*?\[/g,",").split("[")[1].split("]")[0];
                                t.split(",").forEach(str => {
                                    const [key, val] = str.split(":");
                                    f.map.set(Math.floor(Number(key)), Number(val));
                                });
                            }

                        }
                        count = 1;
                        return;
                    }
                    if (f.map) {
                        v = Math.floor(v);
                        if (f.map.has(v)) {
                            val += f.map.lastValue = f.map.get(v);
                        } else if (count === 1) {
                            val += f.map.lastValue;
                        }
                        count ++;
                    }
                },
                obj(v,start,end,f) {
                    if (end) { return f.value = val }
                    if (start) { }
                    else { val = v }
                },
                spr(v,start,end,f) {
                    if(end) {
                        if(f.cap === true) {
                            f.resetOnChange = true;
                            f.cap = false;
                            f.value = f.spriteSet.size;
                            f.value.asArray = [...f.spriteSet.values()];
                            return f.spriteSet;
                        }
                        return f.value = f.spriteSet ?  f.spriteSet.size : 0;
                        return f.value;
                    }
                    if(start && f.cap === true) {
                        if(f.spriteSet === undefined) {
                            f.spriteSet = new Set(f.inputs);
                        } else {
                            f.spriteSet.clear();
                            for(const spr of f.inputs) { f.spriteSet.add(spr) }
                        }
                    }
                },

            };
        })(),
        input: {
            names : {
                none:[""],
                v:["Val"],
                x:["X"],
                y:["Y"],
                rx:["RotX"],
                ry:["RotY"],
                sx:["ScX"],
                sy:["ScY"],
                w:["Width"],
                h:["Height"],
                iW:["Image width"],
                iH:["Image height"],
                a:["Alpha"],
                R:["Red"],
                G:["Green"],
                B:["Blue"],
                RGB:["Color"],
                ax:["Atch X"],
                ay:["Atch Y"],
                text:["Text"],
                subSpr:["Sub sprite idx"],
                img:["Img Seq"],
                mx:["Mouse X"],
                my:["Mouse Y"],
                mOver:["M Ovr"],
                f:["A Frame"],
                t:["A Time"],
                gt:["G Time"],
                fo:["fL Offset"],
                fs:["fL Scale"],
                pi:["PI"],
                al:["Anim Len"],
                shpR:["Radius"],
                shpI:["Inner"],
                shpS:["Count"],
                shpA:["Val A"],
                shpB:["Val B"],
                shpC:["Val C"],
                shpD:["Val D"],
                asf:["Anim Start"],
                aef:["Anim End"],
                spr:["Capture"],
                sel:["IsSelected"],
                pixel:["Pixel"],
                vX:["View X"],
                vY:["View Y"],
                vCX:["View center X"],
                vCY:["View center Y"],
                vW:["View W"],
                vH:["View H"],
                vS:["View Scale"],
                palC:["Pallet Count"],
                SVol:["Sound Volume"],
                SOff:["Sound Play Offset"],
                SRate:["Sound rate Scale"],
                SLev:["Sound level"],
                SLevM:["Sound level mean"],
				/*A:["Sprite attach from"],*/
				An:["Sprite anim list"],
            },
            system: {
                f() { return animation.frame },
                al() { return animation.length },
                asf() { return animation.startTime },
                aef() { return animation.endTime },
                t() { return animation.seconds },
                gt() { return globalTime / 1000 },
                v() { return 0 },
                pi() { return Math.PI },
                R() { return colours.mainColor.r * colours.mainColor.r / Math.W16 },
                G() { return colours.mainColor.g * colours.mainColor.g  / Math.W16 },
                B() { return colours.mainColor.b * colours.mainColor.b  / Math.W16 },
                RGB() { return colours.mainColor },
                vX() {  return viewTopLeft.x },
                vY() {  return viewTopLeft.y },
                vCX() {  return viewCenter.x },
                vCY() {  return viewCenter.y },
                vW() {  return viewSize.x },
                vH() {  return viewSize.y },
                vS() {  return viewScale },
            },
            sprite: {
                v(from) { return from.type.functionLink ? from.fLink.value : 0 },
                x(from) { return from.x },
                y(from) { return from.y },
                rx(from) { return from.rx },
                ry(from) { return from.ry},
                sx(from) { return from.sx },
                sy(from) { return from.sy },
                w(from) { return from.w * from.sx },
                h(from) { return from.h * from.sy },
                iW(from) { from.type.image ? (from.type.subSprite ? from.subSprite.w : from.image.w) : from.w },
                iH(from) { from.type.image ? (from.type.subSprite ? from.subSprite.h : from.image.h) : from.h },
                a(from) { return from.a },
                R(from) { return from.rgb.r2 / Math.W16 },
                G(from) { return from.rgb.g2 / Math.W16 },
                B(from) { return from.rgb.b2 / Math.W16 },
                RGB(from) { return from.rgb },
                ax(from) { return from.type.attached ? from.attachment.x : 0},
                ay(from) { return from.type.attached ? from.attachment.y : 0},
                mx(from) { return from.key.lx },
                my(from) { return from.key.ly },
                pixel(from) {
                    if (from.type.image && from.image.isDrawable && from.key.over) {
                        const dat = from.image.ctx.getImageData(from.key.lx | 0, from.key.ly | 0, 1, 1).data;
                        return new Sprite.RGB(dat[0],dat[1],dat[2]);
                    }
                    return new Sprite.RGB(0,0,0);
                },
                palC(from) { return from.pallet?.length ?? 0 },
                mOver(from) { return from.key.over ? 1 : 0 },
                shpR(from) { return from.type.shape ? from.shape.radius : 0 },
                shpI(from) { return from.type.shape ? from.shape.inner : 0 },
                shpS(from) { return from.type.shape ? from.shape.sides : 1 },
                shpA(from) { return from.type.shape ? from.shape.valA / 4 * Math.TAU : 0 },
                shpB(from) { return from.type.shape ? from.shape.valB / 4 *  Math.TAU : 0 },
                shpC(from) { return from.type.shape ? from.shape.valC : 0 },
                shpD(from) { return from.type.shape ? from.shape.valD : 0 },
                text(from) {
                    if (from.type.text === true) {
                        const textNum = new Number(from.textInfo.text);
                        textNum.text = from.textInfo.text;
                        return textNum;
                    } else {
                        const textNum = new Number(0);
                        textNum.text = "0";
                        return textNum;
                    }
                },
				subSpr(from) {return from.type.subSprite ? from.subSpriteIdx : 0 },
                img(from) { return from.type.imgSequence ? from.imageIdx : 0 },
                fo(from) { return from.type.functionLink ? from.fLink.offset : 0 },
                fs(from) { return from.type.functionLink ? from.fLink.scale : 1 },
                spr(from) { return 0 },
                sel(from) { return from.selected ? 1 : 0 },
				SVol(from) { return from.type.sound ? from.sound.volume : 0 },
				SOff(from) { return from.type.sound ? from.sound.startOffset : 0 },
				SRate(from) { return from.type.sound ? from.sound.rateScale : 0 },
				SLev(from) { return from.type.sound && from.sound.pos >= 0 ? from.image.desc.vBuf[from.sound.pos * 2] : 0 },
				SLevM(from) { return from.type.sound && from.sound.pos >= 0 ? from.image.desc.vBuf[from.sound.pos * 2 + 1] : 0 },
				/*A(from) { return 0 },*/
				An(from) { return 0 },
            }
        },
        output: {
            names : {
                none:[""],
                v:["Val"],
                x:["X"],
                y:["Y"],
                r:["Rot"],
                rx:["RotX"],
                ry:["RotY"],
                s:["Scale"],
                sx:["Scale X"],
                sy:["Scale Y"],
                w:["Width"],
                h:["Height"],
                swh:["Size"],
                a:["Alpha"],
                R:["Red"],
                G:["Green"],
                B:["Blue"],
                RGB:["Color"],
                ax:["Atch X"],
                ay:["Atch Y"],
                text:["Text"],
                img:["Img seq"],
                subSpr:["Sub sprite idx"],
                fo:["fL Offset"],
                fs:["fL Scale"],
                fbO:["fL Block Out"],
                fbI:["fL Block In"],
                mx:["Mouse X"],
                my:["Mouse Y"],
                shpR:["Radius"],
                shpI:["Inner"],
                shpS:["Count"],
                shpA:["Val A"],
                shpB:["Val B"],
                shpC:["Val C"],
                shpD:["Val D"],
                spr:["SprList"],
                cap:["CapList"],
				SVol:["Sound Volume"],
                SOff:["Sound Play Offset"],
                SRate:["Sound rate Scale"],
				/*A:["Sprite attach to"],*/

            },
            system: {
            },
            sprite: {
                v(v, to) { return false },
                x(v, to) { to.x = v; return true},
                y(v, to) { to.y = v; return true},
                r(v, to) { const roff = to.ry - to.rx; to.rx = v; to.ry = v + roff; return true },
                rx(v, to) { to.rx = v; return true},
                ry(v, to) { to.ry = v; return true},
                s(v, to) { to.setScale(v,v); return false},
                sx(v, to) { to.setScale(v,to.sy); return false},
                sy(v, to) { to.setScale(to.sx,v); return false},
                w(v,to) { to.setScale(v / to.w, to.sy); return false},
                h(v,to) { to.setScale(to.sx, v / to.h); return false},
                swh(v,to) {to.setScale(v / to.w, v / to.h); return false},
				SVol(v, to) { to.type.sound && (to.sound.volume = v); return false},
				SOff(v, to) { to.type.sound && (to.sound.startOffset = v); return false },
				SRate(v, to) { to.type.sound && (to.sound.rateScale = v); return false },				
                a(v, to) { to.a = v < 0 ? 0 : v > 1 ? 1 : v; return false},
                R(v, to) { to.rgb.r = (to.rgb.r2 = Math.unit((v.r !== undefined ? v.r * v.r / Math.W16 : v)) * Math.W16) ** 0.5 | 0; to.rgb.update(); return false},
                G(v, to) { to.rgb.g = (to.rgb.g2 = Math.unit((v.g !== undefined ? v.g * v.g / Math.W16 : v)) * Math.W16) ** 0.5 | 0; to.rgb.update(); return false},
                B(v, to) { to.rgb.b = (to.rgb.b2 = Math.unit((v.g !== undefined ? v.b * v.b / Math.W16 : v)) * Math.W16) ** 0.5 | 0; to.rgb.update(); return false},
                RGB(v, to) {
                    if(v.g !== undefined) {
                        if (!to.rgb.isSame(v)) {
                            to.rgb.fromRGB(v)
                            if (to.type.shape && to.shape.colorChanged) { to.shape.colorChanged(true) }
                        }
                    } else {
                        to.rgb.r = to.rgb.g = to.rgb.b = (to.rgb.r2 = to.rgb.g2 = to.rgb.b2 = Math.unit(v) * Math.W16) ** 0.5 | 0;
                        to.rgb.update();
                    }
                    return false
                },
                ax(v, to) { to.type.attached && (to.attachment.x = v, to.attachment.position()); return true },
                ay(v, to) { to.type.attached && (to.attachment.y = v, to.attachment.position()); return true },
                shpR(v, to) { to.type.shape && (to.shape.radius = v); return false },
                shpI(v, to) { to.type.shape && (to.shape.inner = v); return false },
                shpS(v, to) { to.type.shape && (to.shape.sides = Math.round(v)); return false },
                shpA(v, to) { to.type.shape && (to.shape.valA = (v / Math.TAU) * 4); return false },
                shpB(v, to) { to.type.shape && (to.shape.valB = (v / Math.TAU) * 4); return false },
                shpC(v, to) { to.type.shape && (to.shape.valC = v); return false },
                shpD(v, to) { to.type.shape && (to.shape.valD = v); return false },
                text(v,to) {
                    if(to.type.text) {
                        to.textInfo.text = v && v.text ? v.text : v.toFixed(0);
                        //to.textInfo.text = to.textInfo.fLinkText.replace(/(#+\.#*)|(#+)|(^$)/, (str,f,i) => f?v.toFixed(f.split(.)[1].length):(i?v.toFixed(0):v.toFixed(6)));
                        return true;
                    }
                    return false;
                },
			    subSpr(v,to) { to.type.subSprite && to.changeToSubSprite(v = v < 0 ? 0 : v | 0); return false },
                img(v,to) {
                    if(to.type.image && to.type.imgSequence) {
                        to.imageIdx = ((v % to.imgSequence.length + to.imgSequence.length) % to.imgSequence.length) | 0;
                        to.image = to.imgSequence[to.imageIdx];
                        if(to.image.w !== to.w || to.image.h !== to.h) {
                            to.cx = (to.w = to.image.w) / 2;
                            to.cy = (to.h = to.image.h) / 2;
                            return true;
                        }
                        return false;
                    }
                },
                fo: (() => { const func = (v, to) => { to.type.functionLink && (to.fLink.offset = v); return false }; func.flProp = true; return func })(),
                fs: (() => { const func = (v, to) => { to.type.functionLink && (to.fLink.scale = v); return false }; func.flProp = true; return func; })(),
                fbO: (() => { const func = (v, to) => { to.type.functionLink && (v > 0 ? to.fLink.blocks |= 2 : to.fLink.blocks &= 1); return false }; func.flProp = true; return func; })(),
                fbI: (() => { const func = (v, to) => { to.type.functionLink && (v > 0 ? to.fLink.blocks |= 1 : to.fLink.blocks &= 2); return false }; func.flProp = true; return func; })(),
                mx(v, to) { to.key.funcLinkLock |= 1; to.key.flx = v; return false },
                my(v, to) { to.key.funcLinkLock |= 2; to.key.fly = v; return false },
                spr(v, to) { to.type.functionLink && v instanceof Set && (to.spriteList = v.asArray); return false },
                cap(v, to) { to.type.liveCapture && v instanceof Set && (to.captureList = [...v.values()]); return false },
				/*A(v, to) { return false },*/
            },
        },
    };

    const names = {
        inputType: ["v","gt","t","f","al","asf","aef","x","y","rx","ry","sx","sy","w","h","iW","iH","ax","ay","vX","vY","vCX","vCY","vW","vH","vS","a","R","G","B","RGB","palC","subSpr","img","mOver","mx","my","text","shpI","shpR","shpS","shpA","shpB","shpC","shpD","fs","fo","pi","spr","sel","pixel","SVol","SOff","SRate","SLev","SLevM",/*"A",*/ "An"],
        inputTypeLong: [ "Value", "GlobalTime?Time since page load in seconds", "Time?Cyrrent animation time in seconds", "Frame?Current animation frame number 60th second per frame", "Anim length?Animation length in frames", "Anim start?Start time of animation", "Anim end?End time of animation", "Position X?World x position of input sprite", "Position Y?World y position of input sprite", "Rotate X Axis?Direction in radians of input sprite x axis", "Rotate Y Axis?Direction in radians of input sprite x axis", "Scale X?X axis scale of input sprite", "Scale Y?Y axis scale of input sprite", "Width?World width of input sprite in pixels", "Height?World width of input sprite in pixels", "Image width?Image or sub sprite width in pixels", "Image height?Image or subSprite height in pixels", "Attached X?Local X attached position relative top left depending on attachment type", "Attached Y?Local Y attached position relative top left depending on attachment type","View X?Workspace X coordinate of top left corner","View Y?Workspace Y coordinate of top left corner","View center X?Workspace center X coordinate","View center Y?Workspace center Y coordinate","View W?Workspace width in pixels","View H?Workspace height in pixels","View Scale?Workspace scale","Alpha?Alpha value of input sprite range 0 to 1", "Red?Input sprite red value range 0 to 1", "Green?Input sprite Green value range 0 to 1", "Blue?Input sprite Blue value range 0 to 1", "Color?Color of input sprite","Pallet count?Number of color contained in pallet", "Sub sprite index?Sub Sprite index", "Image Seq Idx?Idx of current image if input sprite is an image sequence", "Mouse Over?Value of 1 if mouse over input sprite else 0", "Mouse X?Relative x position of mouse to input sprite", "Mouse Y?Relative y position of mouse to input sprite", "Text?Reads imput text sprites text as number", "Shape Inner?Shape inner property value", "Shape radius?Shape radius property value", "Shape count?Shape count property value", "Shape A?Shape A property value", "Shape B?Shape B property value", "Shape C?Shape C property value", "Shape D?Shape D property value", "Func link Scale?Scale value of input sprite if function link", "Func link Offset?Offset value of input sprite if function link", "PI", "Sprite List", "Is selected?If input sprite is selected value is 1 else 0", "Pixel?gets RGB of pixel under mouse of input sprite (MUST BE Drawable)","Sound volume?Gets the current volume of input sounds","Sound offset?Gets the sound play offset in seconds of input sounds","Sound Rate scale?Gets the playback rate scale of input sounds", "Sound level?Level of sound at current time", "Sound mean level?Mean sound level at current time", /*"Loc from?Links locator from sprite",*/  "Spr anim?Links sprites in animation order"],
        outputType: ["v","x","y","r","rx","ry","s","sx","sy","w","h","swh","ax","ay","a","R","G","B","RGB","subSpr","img","mOver","mx","my","text","shpI","shpR","shpS","shpA","shpB","shpC","shpD","fs","fo","fbO","fbI","spr","cap","SVol","SOff","SRate",/*"A"*/],
        outputTypeLong: [ "Value", "Position X", "Position Y", "Rotation?Combined x and y axis rotation", "Rotate X Axis", "Rotate Y Axis", "Scale?Combinded X and Y axis scale of output sprite", "Scale X", "Scale Y", "Width", "Height", "Size", "Attached X", "Attached Y", "Alpha", "Red", "Green", "Blue", "Color", "Sub sprite index?Selects sub sprite if sprite has sub sprite", "Image Seq Frame?Selects image if sprite has a image sequence", "Mouse Over?Overwrites mouse over on linked sprite", "Mouse X?Overwrites mouse x on linked sprite", "Mouse Y?Overwrites mouse y on linked sprite", "Text?Outputs result as text if linked to a text sprite", "Shape Inner?Set the inner value of a shape", "Shape radius?Set the radius value of a shape", "Shape count?Set the count value of a shape", "Shape A?Set shape A property", "Shape B?Set shape B property", "Shape C?Set shape C property", "Shape D?Set shape D property", "Func ink Scale?Set scale value of a function line", "Funclink Offset?Set offset value of a function line", "Funclink Block OUT?Blocks output of linked function link when value > 0", "Funclink Block IN?Blocks input of linked function link when value > 0", "Sprite List", "Capture List","Sound volume?Gets the current volume of input sounds","Sound offset?Gets the sound play offset in seconds of input sounds","Sound Rate scale?Gets the playback rate scale of input sounds",/* "Loc to?Links locator to sprite"*/],
        functionType: ["sum","dif","acc","mult","div","chase","spring","delay","ecurve","scurve","sqrWave","pulseWave","triangleWave","cmpEq","cmpGtLt","cMod","mean","abs","flr","rnd","sign","vClamp","vMod","toUnit","clamp","mod","max","min","sqr","sqrt","pow","sin","cos","asin","acos","tan","vdot","vcross","uvdot","uvcross","svdot","svcross","vAng","select","swch","trig","tan2","rgb","hypot","rand","map","obj","spr","cap","A"],
        functionTypeLong: [ "Sum?Sums all input values", "Diference?Subtract inputs after the first from the first", "Accumulater?Adds summed inputs or offset once every fram", "Multiply?Multiplies all inputes", "Divide?Divides first input by all other inputs", "Chaser?Simulates a value chasing the sum of all inputs\nScale sets the acceleration 0-1\nOffset sets the inverse drag 0-1", "Spring?Simulates a spring (like) moving to sum of all inputs\nScale set the max velocity as fraction of difference\nOffset sets drag 0 no drag 1 no movement", "Delay?Sum of all inputs is held for one frame", "Ease In Out?Applies curve to input sum\nOffset is the power of the curve\nOutput 0 to 1", "Sigmoid?Applies sigmod curve to input sum\nOffset is exponent\nOutput -1 to 1", "Square wave?Using sum of input as time\nOutput 0 or 1\nOffset is phase Scale is frequencey", "Pulse wave?Same as Square wave if 1 input else\n1st in is pulse width and time is sum of remaining inputs\nOutput 0 or 1\nOffset is phase\nScale is frequencey", "Triangle wave?If 1 input then Offset is phase Scale is frequencey else\n1st input is peek center and time is sum of remaining inputs\nOutput 0 or 1\nOffset is phase\nScale is frequencey", "Equal?Outputs 1 if all inputs are the same", "Greater Less Than?Outputs 1 when true\nTrue if scale positive and inputs greater than first\nTrue if scale negative and inputs less than first", "Cycle Mod?First input val is divisor\nApplys mod to sum of remaing inputs as a triangle wave", "Mean?Sets output as mean of inputs", "Abs?Sum of inputs is made positive", "Floor?Floors sum of inputs to nearest integer value", "Round?Rounds sum of inputs to nearest integer value", "Sign?Outs is -1 for neg number 1 for positive and 0 for zero", "Value clamp?If 1 input use scale offset to set clamp input\nelse first input is clampped by 1 pr more inpute", "Value mod?First input val is divisor\nApplys mod to sum of remaing inputs as a saw wave", "To unit?Divide sum of input values by first input value", "Unit clamp?Clamps sum of input values to range 0-1 inclusive", "Unit modulo?Outputs fractional part of sum of inputs", "Max?Outputs max value of inputs", "Min?Outputs min value of inputs", "Square?Squares the sum of inputs", "Square Root?Outputs square root of sum of inputs", "Power?Sum of first inputs to power of last input","Sin?Outputs the sin of the sum of inputs\nUnits radians", "Cos?Outputs the cos of the sum of inputs\nUnits radians", "aSin?Outputs radians for sum of inputs\nInput is clamped to prevent out of range value", "aCos?Outputs radians for sum of inputs\nInput is clamped to prevent out of range value", "Tan?Outputs the tan of the sum of inputs\nUnits radians", "VDot?Outputs dot product of input vectors\nInput 1 and 2 is first vector x y\nInput 3 and 4 is first vector x y\nAddition inputs are ignored", "VCross?Outputs cross product of input vectors", "U-VDot?Outputs dot product of normalised input vectors", "U-VCross?Outputs cross product of normalised input vectors", "S-VDot?Outputs dot product of input vectors divided by length of first vect squared", "S-VCross?Outputs cross product of input vectors divided by length of first vect squared",     "Angle between Vectors?Outputs the angle between input vectors", "Input Select?Use first input in range 0 1 to select as output one of remaining inputs", "Input Switch?Uses first input to switch betwwen remaining inputs\nSwitches down we first input neg up when first input is greater than 1", "Trigger < 0?Output 1 if sum off input is negative or 0", "Direction?Outputs direction of first input vector", "RGB?Converts inputs to rgb value\nOne input is gray scale\nMore than one will sum RGB as encountered", "Hypot?Outputs the root of the sum of the squares of the inputs", "Random?Outputs random value", "Data map?First input is text representation of map [int: value] [int: value] and Outputs the sum of remaining mapped inputs","Object?To pass inputs that are not numbers", "Sprite list?Outputs a list of input sprites", "Capture List?Outputs a list of renderable input sprites","Game Sprites?Does nothing"],
        vetName(type, name) {
            const shortName = names[type + "Type"];
            if (shortName.includes(name)) { return name }
            const longName = names[type + "TypeLong"];
            if (longName.includes(name)) {
                return shortName.inputType[longName.indexOf(name)];
            }
        },
        vetIn(name) { return names.vetName("input", name) },
        vetOut(name) { return names.vetName("output", name) },
        vetFunc(name) { return names.vetName("function", name) },

    };
    const viewTopLeft = utils.point;
    const viewSize = utils.point;
    const viewCenter = utils.point;
    var viewScale;


    return {
        data: {
            viewTopLeft,
            viewCenter,
            viewSize,
            viewScale: 1,
        },
        updateFrameData() {
            view.toWorld(0,0,viewTopLeft);
            view.toWorld(mainCanvas.width, mainCanvas.height, viewSize);
            viewSize.x -= viewTopLeft.x;
            viewSize.y -= viewTopLeft.y;
            viewCenter.x = viewSize.x * 0.5 + viewTopLeft.x;
            viewCenter.y = viewSize.y * 0.5 + viewTopLeft.y;
            functionLinkBuilder.data.viewScale = viewScale = view.scale;
        },
        names,
        functionLink,
    };
})();