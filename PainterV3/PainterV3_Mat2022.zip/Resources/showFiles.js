"use strict";
const showFiles = (()=>{
    var el,head,headf;
    const imageFiles = ["jpg","jpeg","png","gif","webp","svg"];
    const API = {
        clear() {
            API.hideFileView();
            dirListing.innerHTML = "";
            el = $("div",{className:"dirListing dirListing_content"});
            head = $("div",{});
            headf = $("div",{});
        },
        update(){
            $$(dirListing,[el,head,headf]);
        },
        hideFileView() {
            fileViewer._currentView && fileViewer._currentView.classList.add("viewing");
            fileViewer._currentView = undefined;
            fileViewer.classList.remove("show");
            fileViewer.innerHTML = "";
        },
        showCurrent() {
            var d = dirRoot.current;
            var str = d.path.join("/") + "/" + d.name;
            $$(head,$("div",{textContent: str, className: "dirListing dirListing_heading",listing: d.parent}));
        },
        showDirs() {
            var first = true;
            for(const d of Object.values(dirRoot.current.dirs)) {
                var str =  d.name
                $$(el,$("div",{textContent: str, className: "dirListing dirListing_dir", listing: d}));
            }
        },
        showFiles() {
            $$(headf,
                $$($("div",{ className: "dirListing dirListing_file header"}),[
                    $("span",{textContent: "Name", className: "dirListing dirListing_file dirListing_file_name", clickAction:["sortFiles","name"]}),
                    $("span",{textContent: "Type", className: "dirListing dirListing_file dirListing_file_type", clickAction:["sortFiles","type"]}),
                    $("span",{textContent: "Size", className: "dirListing dirListing_file dirListing_file_size", clickAction:["sortFiles","size"]}),
                    $("span",{textContent: "Date", className: "dirListing dirListing_file dirListing_file_date", clickAction:["sortFiles","date"]}),
                ])
            )
            var d = dirRoot.current;
            var path = d.path.join("/") + "/"+dirRoot.current.name  ;
            path = path.replace("JavaScript/","").replace("JavaScript","");
            if (path !== "") { path += "/" }
            var clickAction;
            for(const f of dirRoot.current.files) {
                const {date, size, name, type, dir} = f;
                if (imageFiles.includes(type.toLowerCase())) {
                    clickAction = ["showImage", ["http://localhost/MarksHome/"+path + name + "." + type]];
                } else {
                    clickAction = undefined;
                }

                //var str = name + ".path.join("/") + "/" + d.name
                $$(el,
                    $$($("div",{ className: "dirListing dirListing_file", listing: f, clickAction}),[
                        $("span",{textContent: name, className: "dirListing dirListing_file dirListing_file_name"}),
                        $("span",{textContent: type, className: "dirListing dirListing_file dirListing_file_type"}),
                        $("span",{textContent: size, className: "dirListing dirListing_file dirListing_file_size"}),
                        $("span",{textContent: date, className: "dirListing dirListing_file dirListing_file_date"}),
                    ])
                )
            }
        },
        dirChanged() {
            API.clear();
            API.showDirs();
            API.showFiles();
            API.showCurrent();
            API.update();

        },
        start() {
            dirRoot.addEvent("directorychanged",API.dirChanged);
            dirRoot.addEvent("filessorted",API.dirChanged);
            systemEvents.removeEvent("directoryloaded",API.start);
            API.dirChanged();
        },
        click(event) {
            const t = event.target;
            if(t.listing) {
                if(t.listing.isDir) {
                    dirRoot.cd(t.listing);
                }else if(t.listing.isFile) {
                    debugger;

                }
            }else if(t.clickAction) {
                if(dirRoot[t.clickAction[0]]) {
                    dirRoot[t.clickAction[0]](t.clickAction[1]);
                }
             }else if(t.parentElement.clickAction) {
                if(dirRoot[t.parentElement.clickAction[0]]) {
                    dirRoot[t.parentElement.clickAction[0]](t.parentElement,...t.parentElement.clickAction[1]);
                }
             }


        }


    };
    dirListing.addEventListener("click",API.click);
    systemEvents.addEvent("directoryloaded",API.start);
    return API;
})();