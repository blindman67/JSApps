"use strict";
const dirRoot = (()=>{
    const API = {};
    const busyId = busy("Loading data");
    jsonReadWriter.loadText("http://localhost/MarksHome/GameEngine/Jan2018/DirectoryListing.json",file => {
        var ii ="\\\\"+("UglifyJS,zebra,ChipmunkPhysics,node_modules,ace-master,NodeJS,js,ThirdParty,Git,GitHub,English,codePens,CodeTester,Electron".split(",").join("|\\\\"));
        if(typeof file === "string") { log("load failed") }
        else {
            setTimeout(()=>{
                const ignoreDir = new RegExp(ii,"")
                const fileExt = /(?<date>\d\d\/\d\d\/\d\d\d\d  \d\d:\d\d [PA]M) +(?<size>[\d,]+) (?<name>.+)\.(?<ext>.+$)/
                const dirExt = /(\d\d\/\d\d\/\d\d\d\d  \d\d:\d\d +[PA]M) +(<DIR>) +(.+$)/
                const dirPathExt = /Dir (?<path>.+$)/
                file.text = file.text.split("\r\n");
                var inDir = "";
                var ignore = true;
                file.text = file.text.filter(line => {
                    if(inDir === "") {
                        if(dirPathExt.test(line)) {
                            const {path} = dirPathExt.exec(line).groups;
                            ignore = ignoreDir.test(line);
                            inDir = path;
                            return !ignore;
                        }
                        return false;
                    }
                    if(dirPathExt.test(line)) {
                        const {path} = dirPathExt.exec(line).groups;
                        ignore = ignoreDir.test(line);
                        inDir = path;
                        return !ignore;
                    } else if(ignore) { return false }
                    else if(fileExt.test(line)) {
                        return true;
                    }
                    return false;
                });
                var count =  file.text.length
                var idx = 0;
                const getDirectory = (...path) => {
                    var r = root;
                    path.shift();
                    while(path.length){
                        const rr = r.dirs[path.shift()];
                        if(rr === undefined){
                            return r
                        }
                        r = rr;
                    }
                    return r;
                }
                const createDir = line => {
                    const path = dirPathExt.exec(line).groups.path.split("\\");
                    const name = path.pop();
                    path.shift();
                    return {
                        path,
                        isDir: true,
                        toString() {
                            return [...this.path, this.name].join("/").replace(markLocalHost.rootName, markLocalHost.url);
                        },
                        name,
                        dirs: {},
                        parent: null,
                        files: Object.assign([],{
                            toString() {
                                var str = "", s = "";
                                for(const f of this) {
                                    str += s + f.name;
                                    s = ", ";
                                }
                                return str;
                            }
                        }),
                    };
                }
                const createFile = line => {
                    var {date, size, name, ext} = fileExt.exec(line).groups;
                    size = Number(size.replace(/,/g,""));
                    return { date, size, name, type : ext, dir, isFile: true};
                }
                var dir, root;
                const files = [];
                while(count--) {
                    const line = file.text[idx++];
                    if(dirPathExt.test(line)) {
                        const d = createDir(line);
                        if(!root) {
                            root = d;
                        } else {
                            dir = getDirectory(...d.path)
                            dir.dirs[d.name] = d;
                            d.parent = dir;
                        }
                        dir = d;
                    }else if(dirExt.test(line)) {
                    }else if(fileExt.test(line)) {
                        const f = createFile(line);
                        dir.files.push(f);
                        files.push(f);
                    }else {
                    }
                }
                root.parent = root;
                const sorts = {
                    name(a,b) {
                        if(a.name > b.name) { return -1 }
                        if(a.name < b.name) { return 1 }
                        return 0;
                    },
                    type(a,b) {
                        if(a.type > b.type) { return -1 }
                        if(a.type < b.type) { return 1 }
                        return 0;
                    },
                    size(a,b) { return a.size - b.size }
                }

                Object.assign(API, {
                    root,
                    files,
                    url: "http://localhost/MarksHome",
                    rootName: root.name,
                    current: root,
                    sortFiles(type) {
                        if(sorts[type]) {
                            this.current.files.sort(sorts[type]);
                            API.fireEvent("filessorted",type);
                        }



                    },
                    getDirectory(...path){
                        var r = this.root;
                        path[0] === "" && path.shift();
                        path[0] === this.root.name && path.shift();
                        while(path.length){
                            const rr = r.dirs[path.shift()];
                            if(rr === undefined){
                                return r
                            }
                            r = rr;
                        }
                        return r;
                    },
                    cd(path = "") {
                        const oldDir = this.current;
                        if (path.isDir) {
                            this.current = path;
                        } else if (path.trim && path.trim() === "") {
                        } else if (path === ".") {
                            this.current = this.current.parent;
                        } else if(path === "..") {
                            this.current = this.root;
                        } else if(this.current.dirs[path]) {
                            this.current = this.current.dirs[path];
                        } else {
                            this.current = this.getDirectory(...path.split(/\/|\\/));
                        }
                        if(oldDir !== this.current) {
                            API.fireEvent("directorychanged",this.current);
                        }

                    },
                    dir(){
                        for(const d of Object.values(this.current.dirs)) {
                        }
                    },

                    showImage(element, name) {
                        if (fileViewer._currentView) {
                            fileViewer._currentView.classList.remove("viewing");
                        }
                        fileViewer.classList.add("show");
                        fileViewer.innerHTML = "";
                        fileViewer._currentView = element;
                        element.classList.add("viewing");
                        $$(fileViewer,$("img",{src: name, className: "imageView"}));

                    },
                });
                Object.assign(API, Events(API));
                busy.end(busyId);
                systemEvents.directoryLoaded();
            },0);
        }
    });
    return API;
})();