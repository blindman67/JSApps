"use strict";
const log = (data) => {
    console.log(data);
}
    
var AID = 1; // app id, this can have duplicates and be reused
var UID = 1; // Unique Id to session, must not be duplicated, must not be reused 
const APPNAME = "PainterV3_Resource";
localStorage[APPNAME + "_GUID"] = localStorage[APPNAME + "_GUID"] ? localStorage[APPNAME + "_GUID"] : 1;
function getGUID(){  // Global unique to Painter  must not be duplicated, must not be reused 
    var GUID = Number(localStorage[APPNAME + "_GUID"] ) + 1;
    localStorage[APPNAME + "_GUID"]  = GUID;
    return GUID;
}
function getUID(){  // Global unique to Painter  must not be duplicated, must not be reused 
    return AID++;
}
const systemEvents = (()=> {

    const API = {
        allLoaded() { API.fireEvent("allloaded", API) },
        canRender() { API.fireEvent("canrender", API) },
        directoryLoaded() {  API.fireEvent("directoryloaded", API) },
    
    };
    Object.assign(API,Events(API));
    return API;
})();
  log("loader started")