"use strict";
const busy = (() => {
    const ids = new Map();
    var id = 0;
    

    const API = {
        count : 0,
        text : "",
        progress : null,
        start(text){
            if(text === undefined){
                API.start.count += 1;
                return;
            }
            API.start.count += 1;
            id++;
            ids.set(id, text);
            API.start.text = text;
            return id;
        },
        end(busyId) {
            if(busyId === undefined){
                API.start.count = API.start.count < 1 ? 0 : API.start.count -1;
                return;
            }
            ids.delete(busyId);
            if(ids.size > 0){
                API.start.text = [...ids.values()].pop();
                API.start.text = API.start.text === undefined ? "" : API.start.text;
            }else{
                API.start.text = "";
            }
            API.start.count = API.start.count < 1 ? 0 : API.start.count -1;
            if(API.start.count === 0) { 
                API.start.text = "";
                API.progress = null;
            }

        }
    }
    return Object.assign(API.start,API);;
})();
const busyRender = (()=>{
    var id;
    var show = false;
    const ticker = "-\|//";
    const tickRate = 10;
    const bEl = $("div",{className: "busyDisplay hide"});
    function renderBusyDOM() {
        if(busy.count > 0) {
            if(!show) {
                bEl.classList.remove("hide");
                show = true;
            }
            var str = busy.text;
            str += " " + (busy.progress !== null ? busy.progress+ "%" : ticker[(frameCount / tickRate | 0) % ticker.length]);
            bEl.textContent = str;
            
        } else {
            if(show) {
                bEl.classList.add("hide");
                bEl.textContent = "";
                show = false
            }
        }
        
    }
    const API = {
        start() {
            log("busy started")
            $$(topLayer,bEl);
            id = Render.addRender(renderBusyDOM);
            systemEvents.removeEvent("canRender",API.start);
        }
    };
    systemEvents.addEvent("canRender",API.start);
    return API;
})()