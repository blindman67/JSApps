"use strict";

var frameCount = 0;
var globalTime = 0;
const Render = (()=> {
    var running = false;
    var ok = true;
    const renderStack = [];
    function mainLoop(time) {
        globalTime  = time;
        frameCount ++;
        for(const item of renderStack) {
            item.render(time);
        }
        if (running) {
            requestAnimationFrame(mainLoop);
            ok = true;
            
        }else {
            ok = true;
        }
    }
    const API = {
        get running() { return running },
        set running(state) {
            if(ok) {
                if(!running && state) {
                    API.start();
                }else if(running && !state) {
                    API.stop();
                }
            }
        },
        addRender(rendFunc) {
            const rend = {
                id : getUID(),
                render: rendFunc,
            }
            renderStack.push(rend);
            return rend.id;
        },
        removeRender(id) {
            const idx = renderStack.findIndex(r => r.id === id);  
            if(idx > -1) {
                renderStack.splice(idx,1);
            }
            
        },
        
        start() {
            if(ok && !running) {
                running = true;
                requestAnimationFrame(mainLoop);    
                ok = false;
            }
        },
        stop() {
            if(ok) {
                running = false;
                ok = false;
            }
        }
        
        
        
    };
    Object.assign(API, Events(API));
    return API;
})();
Render.running = true;
systemEvents.canRender();
            log("render started")