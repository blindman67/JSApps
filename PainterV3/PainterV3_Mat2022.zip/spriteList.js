"use strict";
const spriteList = (()=>{
    var groupId = 0;
   // var listPannel;
    const id = UID ++;
    const showTypes = {
        sprites: commands.spritesShowSprites,
        collections: commands.spritesShowCollections,
        groups: commands.spritesShowGroups,
        layers: commands.spritesShowLayers,
    };

    var showType = showTypes.sprites;
    var debounceUpdateHandle;
    var lastUpdateFrame = 0;
    var keepOpenButton = localStorage[APPNAME + "_lastLoadedSprites"] !== undefined;
    var selectedCallback, editingNameListItem, editingName, listElement, tabElement, flasher, index = 0;
    const updateFlags = {
        hasSelected: false,
        clear() { updateFlags.hasSelected = false },
    };    
    const buttonMap = new Map();
    const items = [];
    const groups = [];
    function ungroup(){
        const itemsToAdd = [];
        const groupsToRemove = [];

        items.forEach(item => {
            if(item.isGroup){
                groupsToRemove.push(item);
                //API.remove(item,false);
                itemsToAdd.push(...item.items.map(listItem => listItem.item));
            }
        });
        groupsToRemove.forEach(group => {
            
                group.list.remove(group.element);
                var i = 0;
                while (i < items.length) {
                    if(items[i].guid === group.guid) {
                        items.splice(i,1);
                        break;
                    }
                    i++;
                }
        });

        itemsToAdd.forEach(item => API.add(item));
        //API.order();
    }
    function createGroup(parent, name){
        if (parent.indent === undefined) {
            parent.indent = 0;
        }
        var open = false;
        const group = {
            indent: parent.indent + 15,
            isGroup : true,
            isOpen() { return open },
            open() {
                this.each(listItem => { listItem.element.classList.remove("hideItem") });
            },
            close() { 
               this.each(listItem => { listItem.element.classList.add("hideItem") });
            },
            toggleOpen() { 
                if (!open) {
                    this.open();
                    open = true;
                } else {
                    this.close();
                    open = false;
                }
            },
            get name() { return name },
            set name(str) { name = str },
            guid : getGUID(),
            items : [],
            remove(guid){
                return
                for(var i = 0; i < this.items.length; i++){
                    const item = this.items[i];
                    if (item.isGroup) {
                        item.remove(guid)
                        if (item.items.length === 0) {
                            this.items.splice(i--,1);
                            log("removed group");
                        }
                    } else if(item.guid === guid) { this.items.splice(i--,1) }
                }
            },
            
            get index() {
                var max = -1;
                for(const item of this.items){
                    var ind = item.item.index;
                    if(ind > max){  max = ind }
                }
                return ind;
            },
            eachItem(cb) {
                for (const listItem of this.items) {

                    if (listItem.isGroup) { listItem.eachItem(cb) }
                    else { cb(listItem.item) }
                }
            },            
            each(cb, i = 0) {
                var index = i;
                for(const listItem of this.items){ 
                    if(listItem.isGroup) {
                        if(listItem.guid !== group.guid) {
                            listItem.each(cb);
                        }
                    }else if( cb(listItem, index++) === true ) { return --index } 
                }            
            },
            get selected() { return this.items.some(item => item.item.selected === true) },
            toString() { return ((open ? textIcons.triangleDown : textIcons.triangleRight) + " " + name + " " + this.items.length + " items") },
            commandId: commands.spritesItem,
        };

        group.element = parent.addFoldItem(group);
        
        group.element.listItem = group.list;
        group.element.listItem.item = group;
        group.element.listItem.element = group.element;
        [...items].forEach(item => {
            if(item.item.selected){
                API.remove(item.item,true);
                const listItem = { item : item.item, element : group.list.addItem(commands.spritesItem, group.indentStr + item.item.toString()),} ;
                listItem.element.style.textIndent = group.indent+"px";
                listItem.element.listItem = listItem;  
                listItem.element.classList.add("hideItem");
                group.items.push(listItem);
            }
        });       
        group.element.textContent = group.toString();
         
     
      //  const groupItem = API.add(group);
      //  group.element = groupItem.element;
        API.order();
        return group;
    }
    function mouseInOut(event) {
        var highlight;
        var target = event.target.listItem;
        if(target && target.item) {
            highlight = event.type === "mouseover";
            if(target.item.isGroup) {
                target.item.each(item => {
                    if(sprites.selectingSprite) {
                        item.highlightSelecting = highlight;
                    } else {
                        item.highlight = highlight;
                    }
                });
                
            }else{
                if(sprites.selectingSprite) {
                    target.item.highlightSelecting = highlight;
                }else{
                    target.item.highlight = highlight;
                }
            }
        }
    }
    var findTopSelect = false;
    var topSelect;
    function updateItem(listItem, index = listItem.element.listPosition) {
        const item = listItem.item;

        const element = listItem.element;
        element.listPosition = index;
        var icons = " " + (item.locks && item.locks.UI ? textIcons.locked : "");       
        element.textContent = item.toString() + icons;        
        if(item.helpString){ element.title = item.helpString() }
        else { element.title = "" }
        if (item.selected) { 
            updateFlags.hasSelected = true;
            element.classList.add("itemSelected") 
        } else { element.classList.remove("itemSelected") }
        if(item.attachedTo && item.attachedTo.selected) { element.classList.add("itemAttachedSelected") }
        else{ element.classList.remove("itemAttachedSelected") }
        
        var lSelected = false;
        if(item.locates) {
            for(const l of item.locates) { if(l.selected) { lSelected = true; break }}
        }
        if(lSelected) { element.classList.add("itemLocatesSelected") }
        else{ element.classList.remove("itemLocatesSelected") }
        if(item.type && item.type.flagged) { element.classList.add("itemFlagged") }
        else{ element.classList.remove("itemFlagged") }        

        if(listItem.isGroup){ listItem.update() }
        if(findTopSelect) {
            if(item.selected) {
                topSelect = element;
                findTopSelect = false;
            }
        }
    }
    const API = {
        updateItemNameComplete(status) { 
            if(status === "rejected") {
                editingNameListItem.item.name = editingName;
                updateItem(editingNameListItem, editingNameListItem.element.listPosition);  
            }else if(editingNameListItem.item.name.trim() === ""){
                editingNameListItem.item.name = editingName;
                updateItem(editingNameListItem, editingNameListItem.element.listPosition);  
                setTimeout(()=>log.warn("Blank name rejected."), 100);
            }
            if(editingNameListItem.item.type && editingNameListItem.item.type.functionLink) {
                editingNameListItem.item.name = textIcons.strToMath(editingNameListItem.item.name.trim());
            }else{
                editingNameListItem.item.name = editingNameListItem.item.name.trim(); 
            }
            updateItem(editingNameListItem, editingNameListItem.element.listPosition);              
            editingNameListItem.element.classList.remove("itemEditingText");
            editingNameListItem = undefined;
        },
        updateItemName() {
            editingNameListItem.item.name = commandLine();
            updateItem(editingNameListItem, editingNameListItem.element.listPosition);  
            editingNameListItem.element.classList.add("itemEditingText");
        },
        
        each(cb, i = 0){
            index = i;
            for(const item of items){ 
                if(item.isGroup) {
                    item.each(cb);
                }else if( cb(item, index++) === true ) { return --index } 
            }
        },
        findItems(cb, list, ifOpen = false) {
            for(const item of items){ 
                if(item.isGroup) {
                    
                } else if(list.includes(item.item)) {
                    if(cb(item) === true) { break }
                }
            }
        },            
        eachOpen(cb){
            var idx = 0;
            for(const item of items){ 
                if(item.isGroup) {
                    cb(item, idx++);
                     if(item.isOpen()) {
                        item.eachOpen(cb, idx);
                    }                   
                }else { cb(item, idx++) } 
            }
        },
        getButton(commandId) { return buttonMap.get(commandId) },        
        ready(pannel) {
            tabElement = pannel.titleElement;
            flasher = elementFlasher(tabElement, {newItem : "tabFlashNew"});
            listElement = buttonMap.get(commands.sprites).element;
            ["mouseover","mouseout"].forEach(name => buttonMap.get(commands.sprites).element.addEventListener(name,mouseInOut,{passive:true}))   
            setTimeout(API.update,100);
        },
        selectionCallback(cb) { selectedCallback = cb },
        command(commandId,button,event) {
            const rightClicked = (mouse.oldButton & 4) === 4;
            
            if(commandId === commands.spritesSaveAll) {
                 if (sprites.length > 0) {
                    if (sprites.hasDirtyImage()) {
                        log.warn("Sprites use 1 or more unsaved images.");
                    } else {
                        animation.time = animation.startTime;                        
                        if (mouse.ctrl) {
                            storage.saveJSON( sprites.serialize(), "p3SpritesLoc", "sprites");
                            log.info("Sprites saving in local storage.");
                        } else {
                            const name = storage.saveJSON( sprites.serialize(), sprites.sceneName, "sprites");
                            log.info("Downloading scene as '" + name + "'");
                        }
                        keepOpenButton = true;
                    }
                } else {
                    log.info("No sprites selected");
                }               
            
            }else  if(commandId === commands.spritesGroup){
            }else  if(commandId === commands.spritesGroup){
                items.push(createGroup(listElement,"Group " + (groupId ++)));
                spriteList.update();
                editSprites.update();

            }else  if(commandId === commands.spritesShowGroups){
                showType = commandId;
                spriteList.update();
            }else  if(commandId === commands.spritesShowCollections){
                showType = commandId;
                spriteList.update();
            }else  if(commandId === commands.spritesShowLayers){
                showType = commandId;
                spriteList.update();
            }else  if(commandId === commands.spritesShowSprites){
                showType = commandId;
                spriteList.update();
            }else  if(commandId === commands.spritesUngroup){
                ungroup();
                spriteList.update();
                editSprites.update();

            }else  if(commandId === commands.spritesRecall){
                sprites.recall();
                //spriteList.update();
                //editSprites.update();

            }else  if(commandId === commands.spritesRemember){
                const name = "spriteMem" + getGUID();
                sprites.remember(name);
                spriteList.update();
            }else  if(commandId === commands.spritesSaveSelected){
                if (rightClicked) {
                    if(mouse.ctrl) {
                        if (localStorage.p3SpritesLoc) {
                            storage.loadJSON("p3SpritesLoc");
                            log.info("Loaded local storage");
                        } else {
                            log.info("No sprites found in local storage");
                        }
                    } else {
                        if (localStorage[APPNAME + "_lastLoadedSprites"] !== undefined) {                        
                            storage.loadJSON(localStorage[APPNAME + "_lastLoadedSprites"]);
                        } else {
                            log.info("There is no last sprite file name saved.");
                        }
                    }
                    
                } else {
                    if (selection.length > 0) {
                        if (selection.hasDirtyImage()) {
                            log.warn("Selected sprites contain 1 or more unsaved images.");
                        } else {
                            animation.time = animation.startTime;                        
                            if (mouse.ctrl) {
                                storage.saveJSON( selection.serialize(), "p3SpritesLoc", "sprites");
                                log.info("Selected sprites saving in local storage.");
                                
                            } else {
                                if(selection.length === sprites.length) {
                                    const name = storage.saveJSON( selection.serialize(), sprites.sceneName, "sprites");
                                    log.info("Downloading scene as '" + name + "'");
                                } else {
                                    const name = storage.saveJSON( selection.serialize(), "p3Sprites", "sprites");
                                    log.info("Downloading selected sprites as '" + name + "'");
                                }
                            }
                            keepOpenButton = true;
                        }
                    } else {
                        log.info("No sprites selected");
                    }
                }
            }else  if(commandId === commands.spritesItem){
                const item = event.target.listItem.item;
                if(mouse.shift && (mouse.oldButton & 1) === 1 && item.isGroup) {

                    item.toggleOpen();

                } else if(mouse.ctrl && (mouse.oldButton & 1) === 1) {
                    const eEl = event.target.listItem.element;

                        editingNameListItem = event.target.listItem;
                        editingName= event.target.listItem.item.name;
                    
                    commandLine(API.updateItemName, API.updateItemNameComplete);
                    commandLine(item.name, false, true);         
                    log.command("Click for text modifer help","text ?" );
                }else{
                    if(sprites.selectingSprite) { //selectedCallback){
                        selection.silent = true;
                        selection.clear()
                        if(item.isGroup){ item.each(listItem => selection.add(listItem)) }
                        else { selection.add(item) }
                        selection.silent = false;
                        widget.specialSelectionSelect(false);
                        return;
                    }
                    if ((mouse.oldButton & 4) === 4){
                        if (item.selected) {
                            if(item.isGroup){ item.each(listItem => selection.remove(listItem.item)) }
                            else { selection.remove(item) }
                        } else {
                            if(item.isGroup){ item.each(listItem => selection.add(listItem.item)) }
                            else { selection.add(item) }
                        }
                    } else {
                        if (!item.selected) {
                            selection.clear(true);
                            if(item.isGroup){ item.each(listItem => selection.add(listItem.item)) }
                            else { 
                                if(item.type.flagged) {
                                    if(item.flag) {
                                        log.info("Sprite flagged "+textIcons.flag+ " with message...");
                                        log.info(item.flag);
                                    }
                                    item.type.flagged = false;
                                    item.flag = "";
                                }
                                selection.add(item);
                            }
                        } else {
                            if(item.isGroup){ item.each(listItem => selection.remove(listItem.item)) }
                            else { selection.remove(item) }
                        }
                    }
                }
                //spriteList.update();
                //editSprites.update();

            }else  if(commandId === commands.spritesToDrawable){
                selection.each(spr => {
                   if(spr.type.image){
                       if(!spr.image.isDrawable){
                           var mItem = mediaList.getMediaItem(spr.image);
                           var newM = media.toDrawable(spr.image);
                           sprites.each(s => {
                               if (s.type.image && s.image === mItem.media) { s.image = newM }
                           });
                           mItem.media = newM;
                           mItem.element.textContent = mItem.media.desc.toString();
                           API.update();
                       }
                   }
                });
                editSprites.update();

            }else  if(commandId === commands.spritesSelectAll){
                selection.add(sprites.map(spr=>spr));
                //API.update();
                //editSprites.update();
            }else  if(commandId === commands.spritesSelectInvert){
                const inv = sprites.filter(spr => !spr.selected);
                selection.clear();
                selection.add(inv);
                
                //API.update();
                //editSprites.update();
            }
        },
        updateInfo(){
            clearTimeout(debounceUpdateHandle);
            debounceUpdateHandle = setTimeout(()=>API.update(),250);
        },        

            
        update(scrollIntoView = false) {
            if(lastUpdateFrame === frameCount) {
                API.updateInfo();
                return;
            }
            topSelect = undefined;
            lastUpdateFrame = frameCount;
            clearTimeout(debounceUpdateHandle);
            updateFlags.clear();
            if(scrollIntoView) { findTopSelect = true }
            API.each(updateItem);
            if(scrollIntoView) { 
                topSelect.scrollIntoView()
            }
            if(updateFlags.hasSelected) {
                buttonMap.get(commands.spritesToDrawable).enable();
                buttonMap.get(commands.spritesToDrawOn).enable();
                buttonMap.get(commands.spritesGroup).enable();
                buttonMap.get(commands.spritesUngroup).enable();
                buttonMap.get(commands.spritesSaveSelected).enable();
            } else {
                buttonMap.get(commands.spritesToDrawable).disable();
                buttonMap.get(commands.spritesToDrawOn).disable();
                buttonMap.get(commands.spritesGroup).disable();
                buttonMap.get(commands.spritesUngroup).disable();
                if(keepOpenButton) {
                    buttonMap.get(commands.spritesSaveSelected).enable();                
                }else{
                    buttonMap.get(commands.spritesSaveSelected).disable();                
                }
            }

            buttonMap.get(showTypes.groups).enable();
            buttonMap.get(showTypes.sprites).enable();
            buttonMap.get(showTypes.layers).enable();
            buttonMap.get(showTypes.collections).enable();
            buttonMap.get(showType).disable();
            //buttonMap.get(commands.spritesRemember).enable();                
            if(sprites.hasMemory()) {
            //    buttonMap.get(commands.spritesRecall).enable();                                
            }else{ 
            //    buttonMap.get(commands.spritesRecall).disable();                            
            }
            
            mediaList.update();
        },
        add(addItem) {
            var item;
            items.push(item = { item : addItem, element : listElement.addItem(commands.spritesItem, addItem.toString()),});
            item.element.listItem = item;
            flasher("newItem");
            return item;
        },
        remove(removeItem, dontCheckGroups) {
            const i = this.each(item => {
                if (!dontCheckGroups && item.item.isGroup) {
                    item.item.remove(removeItem.guid);
                    if (item.item.items.length === 0) { return true }
                } else if(removeItem.guid === item.item.guid){return true }
            });
            if (i !== undefined) {
                listElement.remove(items[i].element);
                items.splice(i,1);
                flasher("newItem");
            }
        },

        order(){
            const oldList = [];
            this.each(item => oldList.push(item.item));
            this.clear();
            oldList.sort((a,b)=>a.index - b.index);
            oldList.forEach(API.add);
        },
        clear(){
            if(items.length) { flasher("newItem") }
            API.each(item => { listElement.remove(item.element) });
            items.length = 0;

        },
        setButtons(buttons) {
            for (const but of buttons) { buttonMap.set(but.command, but) }
            return buttons;
        }
    };
    return API;
})();