            schetchLineChase(x,y,step){
                var rr,gg,bb,travelFade,lw,fromImage,dx,dy,len,lenr,speed,nx,ny,dd,xdx,xdy,ddx,ddy,a,i,x1,y1,d1,xo,yo,xx,yy,lag,lag1,angAccel,angDrag,h1,t;
                travelFade = paint.sizeBlend;
                fromImage = paint.palletFrom === commands.paintColImage;
                
                include setup;
                while(i < hairCount) {
                    const h = hairsMirror[i];
                    const np = i /hc;
                    t = 1-h.travel / dist;
                    h.angle += dd;
                    if(t <= 0.0 || h.x3 === 0){
                        if(t <= 0.0){
                            h.x3 = 0;
                            if(!h.hide){ perStep ++ }
                        }
                        if(perStep === 0 ||(h.x3 === 0 && Math.random() > hairFrac)) { h.hide = true }
                        else{
                            if(h.y3 === 0){ h.y3 = h.size - bm }
                            perStep --;
                            h.hide = false;
                            h.x1 = h.x;
                            h.y1 = h.y;
                            h.x2 = Math.cos(h.angle) * h.dist;
                            h.y2 = Math.sin(h.angle) * h.dist;
                            h.x = h.x1;
                            h.y = h.y1;

                            h.xc1 = (h.x2-h.x1)/dist;
                            h.yc1 = (h.y2-h.y1)/dist;
                            h.travel = 0;
                            t =1;
                            h.x3 = 1;
                        }
                    }
                    if(h.hide){
                        h.x -= nx;
                        h.y -= ny;          
                    }else if(!h.hide){
                        a = 1-t;
                        h.x1 -= nx;
                        h.y1 -= ny;                       
                        h.x2 -= nx;
                        h.y2 -= ny;                                        
                        h.speed = Math.sqrt(nx * nx + ny * ny) + Math.random()*(dist/stepCount)
                        h.x = h.x1 + h.xc1 * h.speed;
                        h.y = h.y1 + h.yc1 * h.speed;      
                        
                        include speedsize;
                        include colours;
                    }
                    i++;
                }
                include mirrorCenter;
            },  
            
named setup {
    use dx,dy,nx,ny,lenFull,len,speed,directionChange,yy,xx,yo,xo,i,lag,lag1,hairCount1,brushSize,brushMin,hairFrac,stepCount,perStep
    
    travelFade = paint.sizeBlend;
    fromImage = paint.palletFrom === commands.paintColImage;                
    dx = hairs.dx;
    dy = hairs.dy;
    nx = dx * step;
    ny = dy * step;
    lenFull = Math.sqrt(dx * dx + dy * dy);
    const dirc = Math.atan2(dy,dx)
    len = lenFull*step 
    speed = len;
    directionChange = hairs.directionChange * step;
    xdx = Math.cos(-directionChange * 0.1)
    xdy = Math.sin(-directionChange * 0.1)
    yy = xx = yo = xo = i = 0;
    lag = paint.pickupRadius/100;
    lag1 = 1 - lag;
    const dist = curves.curves.brushColor.value * 10 + 1;
    const maxPerStep = (curves.curves.brushAlpha.value * (hairCount-1) | 0)+1;
    hairCount1 = hairCount - 1;
    brushSize = paint.brushMax/4;
    brushMin = paint.brushMin/4 -0.001;
    hairFrac = 1 / (hairCount*2);
    stepCount = (1 / step) | 0;
    perStep = (hairCount / stepCount) | 0 + 1;
    perStep = perStep > maxPerStep ? maxPerStep : perStep;
}    
    
named speedsize {    
    use alpha, hair, brushMin;
    hair.segs = 1;
    hair.travel += hair.speed; 
    hair.size = (hair.y3 * curves.lineWidth(1-alpha) + brushMin);            
}
    
    
named colours {
    use lw,rr,gg,bb, alpha, hair;
    
    lw = curves.lineColor(alpha)
    alpha = curves.lineAlpha(alpha)*  hair.a* hair.fade;
    const lw1 = 1-lw;
    rr = Math.sqrt(hair.r * hair.r * lw + hair.r1 * hair.r1 * lw1) | 0;
    gg = Math.sqrt(hair.g * hair.g * lw + hair.g1 * hair.g1 * lw1) | 0;
    bb = Math.sqrt(hair.b * hair.b * lw + hair.b1 * hair.b1 * lw1) | 0;
    hair.css = "rgba("+rr+ ","+gg+","+bb+","+a+")";
}        
named mirrorCenter {
    hairsMirror.xo = 0;
    hairsMirror.yo = 0;
}
        
            
            
            
            