"use strict";
const layers = (() => {
    
    const layers = [];
    
    function Layer() {
        this.ids = new Map();
        this.items = [];
        
    }
    Layer.prototype = {
        
        
    };
    
    const API = {
        
        
        
    };
    Object.assign(API, Events(API));
    return API;
    
})();
