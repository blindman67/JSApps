/* This file has been split into extrasList.js,spriteList.js and mediaList.js. Just here as a backup. Will remove the next time I notice it */


"use strict";
const mediaList = (()=>{
    const buttonMap = new Map();
    const items = [];
    var index = 0;
    var listElement;
    var tabElement;
    var flasher;
    var index;
    var mediaSelected = Object.assign([],{
        each(cb) { index = 0; for (const media of this) { if( cb(media, index++) === true ) { return --index  } } },
        contains(media) { return this.each(m => media=== m) !== undefined },
        clear() {
            mediaSelected.each(media => media.selected = false);
            mediaSelected.length = 0;
        },
        add(media) {
            if(!this.contains(media)){
                this.push(media);
                media.selected = true;
            }
            return this;
        },
        remove(media) {
            if(this.contains(media)){
                media.selected = false;
                this.splice(index,1);
            }
            return this;
        },
    });
    const API = {
        each(cb, i = 0){
            index = i;
            for(const spr of items) { if( cb(spr, index++) === true ) { return --index } }
        },
        ready(pannel) {
            tabElement = pannel.titleElement;
            flasher = elementFlasher(tabElement, {newItem : "tabFlashNew"});
            listElement = buttonMap.get(commands.media).element;
        },
        command(commandId,button,event){
            if(commandId === commands.mediaSavePng){
                mediaSelected.each(media => {
                    var desc = media.desc;
                    media.desc = undefined;
                    saveImage(media, "P3Image" + getGUID());
                    media.desc = desc;
                    media.desc.dirty = false;
                });
                API.update();
            } else if (commandId === commands.mediaSaveJpg){
                mediaSelected.each(media => {
                    var desc = media.desc;
                    media.desc = undefined;
                    saveImage(media, "P3Image" + getGUID(),"jpg",settings.JPEGSaveQuality);
                    media.desc = desc;
                    media.desc.dirty = false;
                });
                API.update();
            }else if(commandId === commands.mediaLoadRecent){
                if(settings.recent.length > 0){
                    //media.create(settings.recent.shift());
                    var command;
                    settings.recent.forEach(item => log.command(command = "load " + item.split("/").pop(),command ));
                    log.flash(log.flashTypes.note);
                }else{
                    log.warn("Recent list is empty");
                }
            }else if(commandId === commands.mediaDeleteImage){
                for(var i = 0; i < items.length; i ++){
                    if(!sprites.hasMedia(items[i].media)){
                        media.remove(items[i].media);
                        listElement.remove(items[i].element);
                        items.splice(i--,1);
                    }else{
                        log.warn("Could not remove some media because it is being used.");
                    }
                };
                API.update();
            }else if(commandId === commands.mediaSelectAll){
                media.each(media => {
                    if(!media.selected){
                        mediaSelected.add(media);
                    }
                });
                API.update();
            }else if(commandId === commands.mediaSelectInvert){
                media.each(media => {
                    if(media.selected){
                        mediaSelected.remove(media);
                    }else{
                        mediaSelected.add(media);
                    }
                });
                API.update();
            }else if(commandId === commands.mediaAddToWorkspace){
                mediaSelected.each(media => {
                    var sprite = new Sprite(0, 0, media.w, media.h);
                    sprite.changeImage(media);
                    sprites.add(sprite);
                    view.centerOn(sprite.x, sprite.y);
                    selection.clear(true);
                    selection.add(sprite);
                });
            }else if(commandId === commands.mediaItem){
                var m = event.target.listItem.media;
                if(!m.selected){
                    if((mouse.oldButton & 4) !== 4){
                        mediaSelected.clear();
                    }
                    mediaSelected.add(m);
                }else {
                    mediaSelected.remove(m);
                }
                API.update();
            }
        },
        update(){
            this.each(listItem => {
                const item = listItem.media;
                const element = listItem.element;
                element.textContent = item.desc.toString();
                if(item.helpString){ element.title = item.helpString() }
                else { element.title = "" }
                element.textContent = item.desc.toString();
                if(item.selected){element.classList.add("itemSelected") }
                else { element.classList.remove("itemSelected") }
                if(selection.hasMedia(item)){element.classList.add("itemSelectedUsed") }
                else { element.classList.remove("itemSelectedUsed") }
                if(item.desc.dirty) { element.classList.add("itemDirty") }
                else { element.classList.remove("itemDirty") }
            });
           /* this.each(item => {
                const m = item.media;
                const e = item.element;
                e.textContent = m.desc.toString();
                if(m.selected){e.classList.add("itemSelected") }
                else { e.classList.remove("itemSelected") }
                if(selection.hasMedia(m)){e.classList.add("itemSelectedUsed") }
                else { e.classList.remove("itemSelectedUsed") }
                if(m.desc.dirty) { e.classList.add("itemDirty") }
                else { e.classList.remove("itemDirty") }
            });            */
            if(mediaSelected.length > 0){
                buttonMap.get(commands.mediaSavePng).enable();
                buttonMap.get(commands.mediaSaveJpg).enable();
                buttonMap.get(commands.mediaDeleteImage).enable();
                buttonMap.get(commands.mediaAddToWorkspace).enable();
            }else{
                buttonMap.get(commands.mediaSavePng).disable();
                buttonMap.get(commands.mediaSaveJpg).disable();
                buttonMap.get(commands.mediaDeleteImage).disable();
                buttonMap.get(commands.mediaAddToWorkspace).disable();
            }
        },
        getMediaItem(image){
            for(const item of items){
                if(item.media === image){
                    return item;
                }
            }
        },
        deleteMedia(media){
            for(var i = 0; i < items.length; i ++){
                if(items[i].media === media){
                    if(!sprites.hasMedia(items[i].media)){
                        media.remove(items[i].media);
                        listElement.remove(items[i].element);
                        items.splice(i--,1);
                        API.update();
                        break;
                    }
                }
            };
        },
        add(media){
            var item;
            items.push(item = { media : media, element : listElement.addItem(commands.mediaItem, media.desc.toString()) });
            item.element.listItem = item;
            API.update();
            flasher("newItem");
        },
        setButtons(buttons){
            for (const but of buttons) { buttonMap.set(but.command, but) }
            return buttons;
        }
    };
    return API;
})();
const spriteList = (()=>{
    var groupId = 0;
    const buttonMap = new Map();
    const items = [];
    const groups = [];
    function ungroup(){
        items.forEach(item => {
            if(item.item.isGroup){
                API.remove(item.item,true);
                item.item.items.forEach(item => API.add(item));
            }
        });
        API.order();
    }
    function createGroup(name){
        const group = {
            isGroup : true,
            name,
            guid : getGUID(),
            items : [],
            remove(guid){
                for(var i = 0; i < this.items.length; i++){
                    const item = this.items[i];
                    if(item.isGroup) {
                        item.remove(guid)
                        if(item.items.length === 0){
                            this.items.splice(i--,1);
                            log("removed group");
                        }
                    } else if(item.guid === guid){ this.items.splice(i--,1) }
                }
            },
            get index() {
                var max = -1;
                for(const item of this.items){
                    var ind = item.index;
                    if(ind > max){
                        max = ind;
                    }
                }
                return ind;
            },
            each(cb) {
                for(const item of this.items){
                    if(item.isGroup) { item.each(cb) }
                    else { cb(item) }
                }
            },
            get selected() {
                return this.items.some(item => item.selected === true);
            },
            toString() {
                return "Group " + name + " " + this.items.length + " items";
            }
        };
        [...items].forEach(item => {
            if(item.item.selected){
                API.remove(item.item,true);
                group.items.push(item.item);
            }
        });
        API.add(group);
        API.order();
        return group;
    }
    var listElement;
    var tabElement;
    var flasher;
    var index = 0;
    var selectedCallback;
    const API = {
        each(cb, i = 0){
            index = i;
            for(const item of items){ if( cb(item, index++) === true ) { return --index } }
        },
        ready(pannel) {
            tabElement = pannel.titleElement;
            flasher = elementFlasher(tabElement, {newItem : "tabFlashNew"});
            listElement = buttonMap.get(commands.sprites).element;
        },
        selectionCallback(cb) { selectedCallback = cb },
        command(commandId,button,event) {
            if(commandId === commands.spritesGroup){
                createGroup("Group " + (groupId ++));
                spriteList.update();
            }else  if(commandId === commands.spritesUngroup){
                ungroup();
                spriteList.update();
            }else  if(commandId === commands.spritesItem){
                const item = event.target.listItem.item;
                if(selectedCallback){
                    widget.selectionCallback();
                    const sel = selection.asArray();
                    selection.clear(true);
                    if(item.isGroup){ item.each(item => selection.add(item)) }
                    else { selection.add(item) }
                    if(selectedCallback){ selectedCallback(sel) }
                    return;
                }
                if ((mouse.oldButton & 4) === 4){
                    if (item.selected) {
                        if(item.isGroup){ item.each(item => selection.remove(item)) }
                        else { selection.remove(item) }
                    } else {
                        if(item.isGroup){ item.each(item => selection.add(item)) }
                        else { selection.add(item) }
                    }
                } else {
                    if (!item.selected) {
                        selection.clear(true);
                        if(item.isGroup){ item.each(item => selection.add(item)) }
                        else { selection.add(item) }
                    } else {
                        if(item.isGroup){ item.each(item => selection.remove(item)) }
                        else { selection.remove(item) }
                    }
                }
                spriteList.update();
            }else  if(commandId === commands.spritesToDrawable){
                selection.each(spr => {
                   if(spr.type.image){
                       if(!spr.image.isDrawable){
                           var mItem = mediaList.getMediaItem(spr.image);
                           var newM = media.toDrawable(spr.image);
                           sprites.each(s => {
                               if (s.type.image && s.image === mItem.media) { s.image = newM }
                           });
                           mItem.media = newM;
                           mItem.element.textContent = mItem.media.desc.toString();
                           API.update();
                       }
                   }
                });
            }else  if(commandId === commands.spritesToDrawOn){
                selection.each(spr => {
                    if(spr.type.image && !spr.type.pattern){
                        if((mouse.oldButton & 4) !== 4){
                            if(spr.image.isDrawable) {
                                spr.drawOn = true;
                            }
                        }else{
                            spr.drawOn = false;
                        }
                   }
                });
                API.update();
            }else  if(commandId === commands.spritesToDrawOff){
                selection.each(spr => {
                    if (spr.type.image && !spr.type.pattern) {spr.drawOn = false }
                });
                API.update();
            }else  if(commandId === commands.spritesSelectAll){
                selection.add(sprites.map(spr=>spr));
                API.update();
            }else  if(commandId === commands.spritesSelectInvert){
                const inv = sprites.filter(spr => !spr.selected);
                selection.clear();
                selection.add(inv);
                API.update();
            }
        },
        update() {
            this.each(listItem => {
                const item = listItem.item;
                const element = listItem.element;
                element.textContent = item.toString();
                if(item.helpString){ element.title = item.helpString() }
                else { element.title = "" }
                if (item.selected) { element.classList.add("itemSelected") }
                else { element.classList.remove("itemSelected") }
            });
            mediaList.update();
        },
        add(addItem) {
            var item;
            items.push(item = { item : addItem, element : listElement.addItem(commands.spritesItem, addItem.toString()),});
            item.element.listItem = item;
            flasher("newItem");
        },
        remove(removeItem, dontCheckGroups) {
            const i = this.each(item => {
                if(!dontCheckGroups && item.item.isGroup){
                    item.item.remove(removeItem.guid);
                    if(item.item.items.length === 0){
                        return true;
                    }
                }else if(removeItem.guid === item.item.guid){return true }
            });
            if(i !== undefined){
                listElement.remove(items[i].element);
                items.splice(i,1);
                flasher("newItem");
            }
        },
        order(){
            const oldList = [];
            this.each(item => oldList.push(item.item));
            this.clear();
            oldList.sort((a,b)=>a.index - b.index);
            oldList.forEach(API.add);
        },
        clear(){
            if(items.length) { flasher("newItem") }
            for(var i = 0;i < items.length; i++){
                listElement.remove(items[i].element);
                items.splice(i--,1);
            }
        },
        setButtons(buttons) {
            for (const but of buttons) { buttonMap.set(but.command, but) }
            return buttons;
        }
    };
    return API;
})();
const extrasList = (()=>{
    const FOLD_INDENT_SIZE = 15;
    const buttonMap = new Map();
    var index = 0;
    var tabElement;
    var flasher;
    var index;
    var indent = 0;
    var customCommandId;
    const fCommands = new Map();
    var lastOpen = null;
    function Fold() {};
    const buttonParts = {
        helpString() { return this.help },
        toString() { return this.name },
    }
    const API = {
        isAPI : true,
        each(cb) { for(const item of this.items) { cb(item) } },
        items : [],
        list : null,
        ready(pannel) {
            tabElement = pannel.titleElement;
            flasher = elementFlasher(tabElement, {newItem : "tabFlashNew"});
            this.list = buttonMap.get(commands.extras).element;
            customCommandId = commands.extrasCustom;
        },
        command(commandId,button,event){
            if(commandId === commands.extrasFold){
                event.target.listItem.toggle();
            }else if(commandId >= commands.extrasCustom){
                const commandCall = fCommands.get(commandId);
                if(typeof commandCall === "function") { commandCall() }
            }
        },
        update() {
            this.each(listItem => {
                const item = listItem.item;
                const element = listItem.element;
                if(listItem.isFold){ listItem.update() }
                const openClose = listItem.isFold ? (listItem.isOpen ? textIcons.triangleDown : textIcons.triangleRight) : "";
                element.textContent = openClose + item.toString();
                if(item.helpString){ element.title = item.helpString() }
                else { element.title = "" }
            });
        },
        updateByObjName(name, text){
            this.each(listItem => {
                const item = listItem.item;
                const element = listItem.element;
                if(listItem.isFold){ listItem.updateByObjName(name,text) }
                else if(item.objName === name) {
                    element.textContent = text
                }
            });
        },
        initBehaviour() {
            this.each(listItem => { if(listItem.isFold){ listItem.initBehaviour() }  });
            if(this.isFold && this.source && this.source.foldInfo.init) { this.source.foldInfo.init() }
        },
        setButtons(buttons){
            for (const but of buttons) { buttonMap.set(but.command, but) }
            return buttons;
        },
        addFoldObject(obj){
            const keys = Object.keys(obj);
            for(const name of keys) {
                if(name !== "foldInfo" && name !== "itemInfo"){
                    if(typeof obj[name].call === "function"){
                        fCommands.set(customCommandId,obj[name].call);
                        var item;
                        this.add(item = {
                            source : obj[name],
                            commandId : customCommandId,
                            objName : name,
                            name : objNameToHuman(name),
                            help : obj[name].help ? obj[name].help : "",
                            helpString : buttonParts.helpString,
                            toString :  buttonParts.toString,
                        });
                        item.source.owner = item;
                        customCommandId ++;
                    }else if(obj[name] !== null && typeof obj[name] === "object"){
                        const fold = this.addFold( {
                            name : objNameToHuman(name),
                            toString : buttonParts.toString,
                        });
                        if(obj[name].foldInfo){
                            fold.source = obj[name]
                            obj[name].foldInfo.fold = fold;
                            //if(obj[name].foldInfo.init) { obj[name].foldInfo.init() }
                        }
                        fold.addFoldObject(obj[name]);
                    } else  if(typeof obj[name] === "function"){
                        fCommands.set(customCommandId,obj[name]);
                        this.add( {
                            commandId : customCommandId,
                            name : objNameToHuman(name),
                            toString : buttonParts.toString,
                        });
                        customCommandId ++;
                    }
                }
            }
            if(this.isAPI) {
                //this.update();
            }
        },
        addFold(button){
            if(this.indent !== undefined){
                button.indent = this.indent + 1;
            }else{
                button.indent = 0;
            }
            button.commandId = commands.extrasFold;
            const fold = new Fold();
            fold.element = this.list.addFoldItem(button);
            if(button.indent > 0){ fold.element.classList.add("hideItem"); }
            fold.init(button);
            fold.owner = this.isAPI ? null : this;
            this.items.push(fold)
            fold.element.listItem = fold;
            flasher("newItem");
            return fold;
        },
        add(addItem){
            var item;
            this.items.push(item = { item : addItem, element : this.list.addItem(addItem.commandId, addItem.toString()),});
            if(this.isFold){ item.element.style.textIndent =  (this.indent + 1) * FOLD_INDENT_SIZE + "px" }
            item.element.listItem = item;
            item.element.classList.add("hideItem");
            flasher("newItem");
        }
    };
    Fold.prototype = {
        each(cb) { for(const item of this.items) { cb(item) } },
        hasFold(fold) {
            for(const item of this.items) {
                if(item.isFold && item.hasFold(fold)) { return true }
                if(item === fold) { return true }
            }
            return false
        },
        init(item) {
            item.owner = this;
            this.items = [];
            this.list = item.list;
            this.item = item;
            this.indent = item.indent;
            this.list.style.textIndent = this.indent * FOLD_INDENT_SIZE + "px";
        },
        close(){
            if(this.isOpen){
                //this.list.classList.add("foldClosed");
                this.each(item => {
                    if(item.isFold) { item.close() }
                    item.element.classList.add("hideItem");
                })
                this.isOpen = false;
                const openClose =this.isOpen ? textIcons.triangleDown : textIcons.triangleRight;
                this.element.textContent = openClose + this.item.toString();
            }
        },
        toggle() {
            if(this.isOpen) {
                this.close();
                lastOpen = null;
                return;
            }else {
                while(lastOpen !== null && lastOpen !== this){
                    if(lastOpen.hasFold(this)){ break }
                    lastOpen.close();
                    lastOpen = lastOpen.owner;
                }
                //this.list.classList.remove("foldClosed");
                this.each(item => item.element.classList.remove("hideItem"));
                this.isOpen = true;
                lastOpen = this;
            }
            const openClose =this.isOpen ? textIcons.triangleDown : textIcons.triangleRight;
            this.element.textContent = openClose + this.item.toString();
        },
        update : API.update,
        updateByObjName : API.updateByObjName,
        initBehaviour : API.initBehaviour,
        addFoldObject : API.addFoldObject,
        addFold : API.addFold,
        add : API.add,
        isOpen : false,
        isFold : true,
    }
    return API;
})();