"use strict";
const grid = (() => {  // The backgroud checker board is called the grid.
    var v, c;
    var patterns = [], ready = false;
    var gc1,gc2,gc3,gc4;
    const P_SIZE = 2;
    const P_SIZE_SCALE = 1;
    function createPatterns(){
        if(gc1 !== settings.gridColor1 ||gc2 !== settings.gridColor2 ||gc3 !== settings.gridColor3 ||gc4 !== settings.gridColor4){
            const ctx = $("canvas", {width : P_SIZE, height : P_SIZE}).getContext("2d");
            ctx.globalAlpha = settings.useGridWorkaround ? 0.2 : 1;
            ctx.fillStyle = settings.gridColor1;
            ctx.fillRect(0,0,P_SIZE,P_SIZE);
            ctx.fillStyle = settings.gridColor2;
            ctx.fillRect(0,0,P_SIZE/2,P_SIZE/2);
            ctx.fillRect(P_SIZE/2,P_SIZE/2,P_SIZE/2,P_SIZE/2);
            patterns[0] = ctx.createPattern(ctx.canvas, "repeat");
            ctx.fillStyle = settings.gridColor3;
            ctx.fillRect(0,0,P_SIZE,P_SIZE);
            ctx.fillStyle = settings.gridColor4;
            ctx.fillRect(0,0,P_SIZE/2,P_SIZE/2);
            ctx.fillRect(P_SIZE/2,P_SIZE/2,P_SIZE/2,P_SIZE/2);
            patterns[1] = ctx.createPattern(ctx.canvas, "repeat");
            gc1 = settings.gridColor1;
            gc2 = settings.gridColor2;
            gc3 = settings.gridColor3;
            gc4 = settings.gridColor4;
        }
    }
    settingsHandler.onchange = createPatterns;
    const API = {
        ready() {},
        setView(view) {
            v = view;
            c = view.context;
        },
        drawScaleBar() {
            const size = 2 ** Math.ceil(Math.log(512 * v.invScale));
            c.setTransform(1, 0, 0, 1, 0, 0);
            c.globalAlpha = 1;
            c.strokeStyle = c.fillStyle = "black";
            c.lineWidth = 1.5;
            const len = (size * v.scale + 0.5) | 0
            c.fillRect(3, c.canvas.height - 6, len + 2, 3);
            c.font = "12px arial";
            c.textAlign = "left";
            c.strokeText(size + "px", 4, c.canvas.height - 11);
            c.fillStyle = "white";
            c.fillRect(4, c.canvas.height - 5, len , 1);
            c.fillText(size + "px", 4, c.canvas.height - 12);
        },
        draw() {
            createPatterns(c);
            API.draw = API.drawReady;
        },
        drawReady() {
            var lStart, size, fade, patternIndex,  scale = v.scale,ss=1;
            size = Math.log(8 * scale);
            lStart = Math.ceil(size / 3) * 3;
            patternIndex = Math.abs(lStart / 3)
            fade = 1 - ((lStart - size) / 3);
            c.setTransform(1, 0, 0, 1, 0, 0);
            c.imageSmoothingEnabled = false;
            c.beginPath();
            c.rect(0, 0, c.canvas.width, c.canvas.height);
            v.apply();
            if (lStart > 6) { ss = 1 / 8; patternIndex = 0 }
            else if (lStart > 3) { ss = 1}
            else if (lStart > 0) { ss = 8}
            else if (lStart > -3) { ss = 64}
            c.scale(ss, ss);
            if (settings.useGridWorkaround) {
                c.globalAlpha = 1;
                c.fillStyle = patterns[(patternIndex++) % 2];
                c.fill()
                c.scale(8, 8);
                c.fillStyle = patterns[(patternIndex++) % 2];
                c.fill();
                c.scale(8, 8);
                c.fillStyle = patterns[(patternIndex++) % 2];
                c.fill();


            } else {
                c.globalAlpha = fade * (1 / 3);
                c.fillStyle = patterns[(patternIndex++) % 2];
                c.fill()
                c.scale(8, 8);
                c.fillStyle = patterns[(patternIndex++) % 2];
                c.globalAlpha = (1 / 3);
                c.fill();
                c.scale(8, 8);
                c.fillStyle = patterns[(patternIndex++) % 2];
                c.globalAlpha =(1 - fade) * (1 / 3);
                c.fill();
            }
            ss *= 1;
            v.apply();
            c.globalAlpha = 1;
            c.beginPath();
            c.strokeStyle = "#FFF8";
            c.lineWidth = 1 / scale;
            c.lineTo(0, -1000000);
            c.lineTo(0, 1000000);
            c.moveTo(-1000000, 0);
            c.lineTo(1000000, 0);
            c.stroke();
            c.scale(ss / 4, ss / 4);
            c.fillStyle = "#FFF3";
            c.font = "12px arial";
            c.textAlign = "left";
            c.fillText((8 * ss) + "px", 2, 10);



        }
    };
    return API;
}) ()