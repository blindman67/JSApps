"use strict";
const mouseClickTime = 250; // Sometimes a click will drag a little of the element. If the time stamps between down and up are less than appart the click is assumed to be for the element the down event occured on.
const mouse = {
    pause : false, // when true ignore all user generated mouse events
    captured : 0,
    clickId: 0, // unique Id for all events from mouse Down to but not including mouse Up. ID is 0 while not in a click event
    oldClickId: 0,
    eventDelay : 0, // Time between mouse event time stamp and system time via performance.now
    repeating : false,
    onCaptureReleaseData: undefined,
    releaseClick : undefined,
    shift: false,
    ctrl: false,
    ctrlB:  false,  // (when backquote is held down) currently only used in pen fill (trigger fill area)
    alt: false,
    repeatingState : {
        button : 0,
        ctrl : false,
        alt : false,
        shift : false,
    },
    addaptiveWheel : true,  // when true the wheel input uses the min recorded wheel delta and converts it to a standard wheel step of 120
    wheelMin : Infinity,    // used when above is true;
    wheelSelect : false, // some UI buttons alow the state to be toggled via the wheel. This is set true if that happens and returned to false after the event has been handled
    onbutton : null,     /* TO DO null needs to be replaced with undefined. There may be code that checks for null rather than falsey */
    onGlobalClick : null,
    onmove : null,
    onKeyboardFocus: undefined,
    keyboardFocus: undefined,
    onMouseFocus: undefined,
    mouseFocus: undefined,
    x : 0,
    y : 0,
    oldX : 0,
    oldY : 0,
    rx : 0,  // world coords (r is for real)
    ry : 0,
    page : { x : 0, y : 0},
    marked : utils.point,
    button : 0,
    oldButton : 0,
    buttonMask : 0b111,
    buttons : [1, 2, 4, 0b110, 0b101, 0b011, 0], // last item zero is event.which = 4 for fake even to clear all
    wheel : 0,
    bounds : null,
    downOn: null,
	eventTime: performance.now(),
	eventDelay: 0,
	frameCount: 100,
	frameCountUp: 100,
    inSavedState : false,
    cursor : "defualt",
    cursorName : "default",
    cursorAngle : undefined,
    requestCapture(id,element, onCaptureRelease, data){
        if(mouse.captured === 0){
            mouse.captured = id;
           // log("Mouse captured "+id);
            if(element){
                mouse.element = element;
                mouse.forElement(element);
            }
            mouse.onCaptureRelease = onCaptureRelease;
            mouse.onCaptureReleaseData = data;
            return true;
        }
        if(mouse.captured === id) {
            mouse.onCaptureRelease = onCaptureRelease;
            mouse.onCaptureReleaseData = data;
            return true
        }
        return false;
    },
    releaseOnClickFunction(id, func){
        if (id === mouse.captured) {  mouse.releaseClick = func; }
    },
    getCaptureReleaseData(id) { return mouse.captured === id ? mouse.onCaptureReleaseData : undefined },
    release(id, mouseUpHandled = false){
        if(mouse.captured === 0 || mouse.captured === id || id === -1){
            mouse.captured = 0;
            mouse.element = undefined;
            if(id === -1) {
                mouse.cancelButtons(mouse.captured);
                if(mouse.inSavedState){ mouse.restore() }
            }
            if(mouse.onCaptureRelease) {
                mouse.onCaptureRelease(id, mouse.onCaptureReleaseData);
                mouse.onCaptureReleaseData = undefined;
                mouse.onCaptureRelease = undefined;
            }
            mouseUpHandled && (mouse.downOn = null);
            return true;
        }
        return false;
    },
    cancelButtons(id){
        if(mouse.captured === 0 || mouse.captured === id){
            mouseEvents({type : "cancel"});
            mouse.requestCursor(0,"default");
        }
    },
    mark() { mouse.marked.as(mouse.x, mouse.y) },
    forElement(el = mouse.element){
        mouse.bounds = el.getBoundingClientRect();
        mouse.x = mouse.page.x - mouse.bounds.left - scrollX;
        mouse.y = mouse.page.y - mouse.bounds.top - scrollY;
        if(mouse.x < 0 || mouse.x >= mouse.bounds.width || mouse.y < 0 || mouse.y >= mouse.bounds.height){
            mouse.over = false;
        } else { mouse.over = true }
    },
    getPos(pos) { return (pos.x = mouse.x, pos.y = mouse.y, pos) },
    requestCursor(id,name,angle){
        if(mouse.captured === 0 || mouse.captured === id){
            if(name !== mouse.cursorName || angle !== mouse.cursorAngle){
                var cursor = mouse.cursorName = name;
                mouse.cursorAngle = angle;
                if(customCursors.cursors.nativeCursors[cursor] !== undefined){
                    var curs = customCursors.cursors.nativeCursors[cursor];
                    if(angle !== undefined){
                        if(curs.direction !== undefined){
                            var name = cursor.split("_");
                            name[1] = customCursors.cursors.getAngleName(angle, curs);
                            cursor = name.join("_");
                        }
                    }
                    var curs = customCursors.cursors.nativeCursors[cursor];
                    mouse.cursor = curs.name;
                }else if(customCursors.cursors[cursor] !== undefined){
                    var curs = customCursors.cursors[cursor];
                    if(angle !== undefined){
                        if(curs.direction !== undefined){
                            var name = cursor.split("_");
                            name[1] = customCursors.cursors.getAngleName(angle,curs);
                            cursor = name.join("_");
                        }
                    }
                    var curs = customCursors.cursors[cursor];
                    mouse.cursor = customCursors.cursors.encoding + curs.image + curs.center + " pointer";
                }else {
                    mouse.cursor = name;
                }
            }else {
                mouse.cursorName = name;
                mouse.cursor = name;
                mouse.cursorAngle = angle;
            }
        }
    },
    updateCursor(element){
        element.style.cursor = mouse.cursor;
    },
    savedState : {  x : 0, y : 0, button : 0, alt : false, ctrl : false, shift : false },
    savedModState : { alt : false, ctrl : false, shift : false },
    saveSetModState(ctrl, shift, alt) {
        mouse.savedModState.ctrl = mouse.ctrl;
        mouse.savedModState.alt = mouse.alt;
        mouse.savedModState.shift = mouse.shift;
        mouse.ctrl = ctrl;
        mouse.alt = alt;
        mouse.shift = shift;
    },
    restoreModState() {
        mouse.ctrl = mouse.savedModState.ctrl;
        mouse.alt = mouse.savedModState.alt;
        mouse.shift = mouse.savedModState.shift;
    },
    save(){
        mouse.savedState.x = mouse.x;
        mouse.savedState.y = mouse.y;
        mouse.savedState.oldButton = mouse.oldButton;
        mouse.savedState.button = mouse.button;
        mouse.savedState.ctrl = mouse.ctrl;
        mouse.savedState.alt = mouse.alt;
        mouse.savedState.shift = mouse.shift;
        mouse.inSavedState = true;
    },
    set state(stateObj){
        mouse.x = stateObj.x !== undefined ? stateObj.x : mouse.x;
        mouse.y = stateObj.y !== undefined ? stateObj.y : mouse.y;
        mouse.oldButton = stateObj.oldButton !== undefined ? stateObj.oldButton : 0;
        mouse.button = stateObj.button !== undefined ? stateObj.button : 0;
        mouse.ctrl = stateObj.ctrl === true;
        mouse.alt = stateObj.alt === true;
        mouse.shift = stateObj.shift === true;
    },
    restore(){
        if(mouse.inSavedState){
            mouse.x = mouse.savedState.x;
            mouse.y = mouse.savedState.y;
            mouse.oldButton = mouse.savedState.oldButton;
            mouse.button = mouse.savedState.button;
            mouse.ctrl = mouse.savedState.ctrl;
            mouse.alt = mouse.savedState.alt;
            mouse.shift = mouse.savedState.shift;
        }
        mouse.inSavedState = false;
    },
    fakeEventType : {
        mouseup(event){
            if(!isNaN(event.which) && event.which > 0 &&  event.which < 4){ return true }
            if(event.which === "all"){event.which = 4; return true }
            return false;
        },
        mousemove(event) { return true },
        mousedown(event){ return !(event.which === undefined || isNaN(event.which) || event.which < 1 || event.which > 3) },
        wheel(event){
            event.deltaY = isNaN(event.delta) ? 0 : Number(event.delta);
            return true;
        },
    },
    fakeEvent(id, event){  // only when not captured or if captured have the correct capture id will event be processed. return false if access is denied
        if((mouse.captured === 0 || mouse.captured === id) && mouse.fakeEventType[event.type]){
            if(mouse.fakeEventType[event.type](event)){
                const e = {};
                e.target = {};
                e.pageX = mouse.page.x;
                e.pageY = mouse.page.y;
                e.altKey = mouse.alt;
                e.shiftKey = mouse.shift;
                e.ctrlKey = mouse.ctrl;
                e.target = mouse.downOn;
                e.bypassPause = true;
                Object.assign(e,event);
                setTimeout(()=> {
                    //e.timeStamp = performance.now();
                    mouseEvents(e);
                }, 0);
                return true;
            }
        }
        return false;
    },
    startRepeater(target) {
        var rate = target.repeatRate;
        const fakeE = {target};
        mouse.repeatingState.button = mouse.button;
        mouse.repeatingState.ctrl = mouse.ctrl;
        mouse.repeatingState.alt = mouse.alt;
        mouse.repeatingState.shift = mouse.shift;
        function repeater() {
			mouse.eventDelay += 0;
			mouse.eventTime = performance.now();			
            mouse.repeating = true;
            mouse.onGlobalClick(fakeE);
            mouse.downOn = null;
			if (!target.constantRate) {
				if (rate > 17){ rate /= 2 }
				else { rate = 17 }
			}
            mouse.repeaterHandle = setTimeout(repeater,rate);
        }

        mouse.repeaterHandle = setTimeout(repeater,rate);
    },
    stopRepeater() {
        mouse.repeating = false;
        clearTimeout(mouse.repeaterHandle);
        mouse.repeaterHandle = null;
    },
    listen() {
        document.addEventListener("wheel", cancelableWheel, {passive: false});
        ["mouseup", "mousemove", "wheel"].forEach(name => document.addEventListener(name, mouseEvents, {passive: true}));
        ["mousedown"].forEach(name => document.addEventListener(name, mouseEvents, {passive: false}));
        document.addEventListener("contextmenu", (e) => {if (!e.target.dataset.allowContextMenu) { e.preventDefault() }});
    },
}
function mouseEvents(e) {  // This function will also handle DOM LIKE events
    var target, pathIdx, doit, wDelta;
    mouse.eventDelay += performance.now() - e.timeStamp;
    mouse.eventTime = e.timeStamp;
	mouse.frameCount = frameCount + 1;
    if (e.type === "cancel") {
        mouse.oldButton = mouse.button;
        mouse.button = 0;
        mouse.oldClickId = mouse.clickId;
        return;
    }
    if (mouse.pause && !e.bypassPause) { return }
    target = e.target;
    mouse.oldX = mouse.x;
    mouse.oldY = mouse.y;
    mouse.x = mouse.page.x = e.pageX;
    mouse.y = mouse.page.y = e.pageY;
    mouse.alt = e.altKey;
    mouse.shift = e.shiftKey;
    mouse.ctrl = e.ctrlKey;
    mouse.active = true;
    if (mouse.element) { mouse.forElement() }
    if (target.mouseFocus) {
        if (mouse.mouseFocus && mouse.onMouseFocus !== target.mouseFocus) {
            mouse.onMouseFocus(false);
            mouse.onMouseFocus = undefined;
            mouse.mouseFocus = false;
        }
        if (target.mouseFocus !== mouse.onMouseFocus && target.mouseFocus(true) === true) {
            mouse.onMouseFocus = target.mouseFocus
            mouse.mouseFocus = true;
        }
    } else if (mouse.mouseFocus) {
        mouse.onMouseFocus(false);
        mouse.onMouseFocus = undefined;
        mouse.mouseFocus = false;
    }
    if (target.focusKeyboard) {
        if (mouse.keyboardFocus && mouse.onKeyboardFocus !== target.focusKeyboard) {
            mouse.onKeyboardFocus(false);
            mouse.onKeyboardFocus = undefined;
            mouse.keyboardFocus = false;
        }
        mouse.onKeyboardFocus = target.focusKeyboard
        mouse.keyboardFocus = true;
        mouse.onKeyboardFocus(true);

    } else if (mouse.keyboardFocus) {
        mouse.onKeyboardFocus(false);
        mouse.onKeyboardFocus = undefined;
        mouse.keyboardFocus = false;
    }
    if (e.type === "mousemove") {
        if (mouse.mouseout && mouse.mouseout !== target) {
            mouse.mouseout.onMove(mouse, e, "out");
            mouse.mouseout = undefined;
        }
        if (mouse.onmove) { mouse.onmove(mouse,e) }
        else if (target.onMove && target.onMove(mouse,e)) { mouse.mouseout = target }
    }else if (e.type === "mousedown") {
		
        mouse.oldButton = mouse.button;
        mouse.button |= mouse.buttons[e.which-1];
        mouse.downOn = target;
		mouse.downOnEvent = e;
        mouse.clickId = mouse.clickId ? mouse.clickId : (mouse.oldClickId = mouse.clickId, mouse.eventTime); // all buttons down between click start and end has the same  click id
        if (target.repeater && mouse.captured === 0) {
            doit = true;
            if (target.repeaterCtrl !== undefined  && target.repeaterCtrl && mouse.ctrl === false) { doit = false }
            if (target.repeaterAlt !== undefined  && target.repeaterAlt && mouse.alt === false) { doit = false }
            if (target.repeaterShift !== undefined  && target.repeaterShift && mouse.shift === false) { doit = false }
            if (doit) { mouse.startRepeater(target) }
        }
        if (target.openSelection) { target.openSelection(mouse, e) }
        if (target.onDrag) { target.onDrag(mouse,e) }
        else if (mouse.onbutton) {  mouse.onbutton(mouse,e) }
    } else if (e.type === "mouseup") {
        if (mouse.repeaterHandle) { mouse.stopRepeater() }
        mouse.oldButton = mouse.button;
        mouse.button &= mouse.buttons[e.which + 2];
        if ((mouse.button & mouse.buttonMask) === 0) { mouse.oldClickId = mouse.clickId; mouse.clickId = 0 }
        if (mouse.onbutton) { mouse.onbutton(mouse,e) }
        if (mouse.captured === 0 && (mouse.downOn !== null && (mouse.downOn === target || (e.timeStamp - mouse.downOnEvent.timeStamp) < mouseClickTime))){
            if (mouse.onGlobalClick) { mouse.onGlobalClick(mouse.downOnEvent) }
            if (mouse.downOn.onButtonClick) { mouse.downOn.onButtonClick(mouse, mouse.downOnEvent) }
        }
        if (mouse.releaseClick && mouse.captured !== 0){
            if (mouse.releaseClick(e)) { mouse.releaseClick = undefined }
        }
        mouse.downOn  = null;
		mouse.downOnEvent = undefined;
		mouse.frameCountUp = frameCount + 1;
    } else if (e.type === "wheel") {
        if (mouse.shift) { e.preventDefault() }
        if (mouse.addaptiveWheel) {
            if (e.deltaY !== 0){  mouse.wheelMin = Math.min(Math.abs(e.deltaY), mouse.wheelMin) }
            mouse.wheel = wDelta = (-e.deltaY / mouse.wheelMin) * 120 | 0;
        } else {
            if (Math.abs(e.deltaY) < 100){  mouse.wheel += wDelta = -e.deltaY * 30 }
            else { mouse.wheel += wDelta = -e.deltaY }
        }
        if (target.updateWheel) { target.updateWheel(mouse,e) }
        else {
            pathIdx = 1;
            while (target.wheelNextTarget) { target = e.path[pathIdx++] }
            if (target.updateWheel) { target.updateWheel(mouse, {target}) }
        }
    }
    if (heartBeat.asleep) { setTimeout(() => mainCanvas.ctx.wakeUp(e.timeStamp), 0) }
}
function cancelableWheel(e) {
    e.preventDefault();
    if (event.target.wheelScroll) {
        mouse.active = true;

        if (mouse.addaptiveWheel) {
            if (e.deltaY !== 0) { mouse.wheelMin = Math.min(Math.abs(e.deltaY), mouse.wheelMin) }
            mouse.wheel = (-e.deltaY / mouse.wheelMin) * 120 | 0;
        } else {
            if (Math.abs(e.deltaY) < 100) { mouse.wheel += -e.deltaY * 30 }
            else { mouse.wheel += -e.deltaY }
        }
        event.target.wheelScroll(mouse.wheel);
    }
}

const keyboard = (()=>{
    const keys = { global: {} };
    var defaultMode;
    var globalMode = keys.global;
    var globalEscapeCommand;
    var activeMode;
    var activeModeName;
    var captureId = 0;
    var captureHandler;
    const API = {
        addMode (modeName) {
            if (keys[modeName] === undefined) { keys[modeName] = {} }
            if (defaultMode === undefined) { defaultMode = modeName }
        },
        set defaultMode(name) { defaultMode = name },
        get mode() { return activeModeName },
        set mode(name){
            if(name.toLowerCase() === "default"){ name = defaultMode }
            activeModeName = name;
            activeMode = keys[name];
        },
        mapKeyCommand(keyName, keyMods = {}, mode = activeModeName, command){
            if(keys[mode] === undefined){ API.addMode(mode); }
            const keyMode = keys[mode]
            const modName = "M" + (keyMods.alt ? "a" : "") + (keyMods.shift ? "s" : "") +  (keyMods.ctrl ? "c" : "");
            if(keyMode[keyName] === undefined){ keyMode[keyName] = {} }
            keyMode[keyName][modName] = {
                command,
                alt : keyMods.alt ? true : false,
                shift : keyMods.shift ? true : false,
                ctrl : keyMods.ctrl ? true : false,
                oldButton : keyMods.second ? 4 : 1,
                button : keyMods.second ? 4 : 1,
            }
        },
        get lastKey() { return lastKey; },
        set lastKey(val) { lastKey = val },
        getKeyMappingString() {
            const mappings = [];
            const modes = Object.keys(keys);
            for(const mode of modes){
                mappings.push("Mode : " + mode);
                const keyList = Object.keys(keys[mode]);
                for(const key of keyList){
                    const modList = Object.keys(keys[mode][key]);
                    for(const mod of modList){
                        const commandName = commandIdToString(keys[mode][key][mod].command);
                        const m = mod.replace("M","")
                            .replace("a","[Alt]")
                            .replace("c","[Ctrl]")
                            .replace("s","[Shift]");
                        mappings.push("[" + key + "]"+ m + " > " + commandName);
                    }
                }
            }
            return mappings;
        },
        release(id) {
            if (captureId === 0 || captureId === id || id === -1) {
                captureId = 0;
                captureHandler = undefined;
                return true;
            }
            return false;

        },
        requestCapture(id, handler) {
            if (captureId === 0 || captureId === id) {
                captureId = id;
                captureHandler = handler;
                return true;
            }
            return false;
        },
        set globalEscapeCommand(commandId) {  globalEscapeCommand = commandId },
    }
    var lastKey = undefined;
    function keyUpEvent(event) {
        mouse.eventTime = event.timeStamp;
		mouse.frameCount = frameCount + 1;
        if (event.type === "keyup") {
            if (event.code == "Backquote") {
                mouse.ctrlB = false;
            }
        }
    }
        
    function keyEvent(event){
        mouse.eventTime = event.timeStamp;
		mouse.frameCount = frameCount + 1;
        lastKey = event.code;
        if (event.type === "keydown") {
            if (event.code === "Escape") {
                API.release(-1);
                infoPannel.release();
                extraRenders.release(-1);
                globalEscapeCommand && issueCommand(globalEscapeCommand);
                globalEscape = true;
                mouse.release(-1);
                mouse.pause = false;
                return;
            }
            if (event.code == "Backquote") {
                mouse.ctrlB = true;
            }
            if (captureId === 0) {
                const modName = "M" + (event.altKey ? "a" : "") + (event.shiftKey ? "s" : "") +  (event.ctrlKey ? "c" : "");
                if (event.target.onKeyActions) {
                    if (event.target.onKeyActions(event.code, modName) === true) {
                        event.preventDefault();
                        return;
                    }
                }
                const key = activeMode[event.code]?.[modName] ?? globalMode[event.code]?.[modName];
                if (key) {
                    mouse.save();
                    mouse.state = key;
                    issuseCommand(key.command);
                    mouse.restore();
                    event.preventDefault();
                }

            } else if (captureHandler) {
                const modName = (event.altKey ? "a" : "") + (event.shiftKey ? "s" : "") +  (event.ctrlKey ? "c" : "");
                if (captureHandler(event.code, modName) === true) { event.preventDefault() }

            }
        }
    }
    document.addEventListener("keydown", keyEvent);
    document.addEventListener("keyup", keyUpEvent);
    return API;
})();