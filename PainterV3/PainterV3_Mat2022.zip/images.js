/* This file has been split into localProcessImage.js and media.js. Just here as a backup. Will remove the next time I notice it */

"use strict";
const localProcessImage = (()=>{
    var workingCanvas = CanvasGroover();
    var ctx = workingCanvas.ctx;
    function copyToWorking(image){
        workingCanvas.width = image.w;
        workingCanvas.height = image.h;
        ctx.drawImage(image,0,0);
    }
    function getCopyOfWorking(image){
        image.ctx.save();
        image.ctx.globalCompositeOperation = "copy";
        image.ctx.globalAlpha = 1;
        image.ctx.filter = "none";
        image.ctx.drawImage(workingCanvas,0,0);
        image.ctx.restore();
    }
    function getPixelData8Bit(image) {
        return image.ctx.getImageData(0,0,image.w,image.h);
    }
    function setPixelData(image, data){
        image.ctx.putImageData(data,0,0);
    }
    var pixelInFunc,pixelOutFunc
        
        
    const API = {
        borrowWorkingCanvas(){
            ctx.save();
            var wc = workingCanvas;
            workingCanvas = null;
            ctx = null
            return wc;
        },
        returnWorkingCanvas(canvas){
            workingCanvas = canvas;
            ctx = workingCanvas.ctx;
            ctx.restore();
        },
        halfSizeBitmap(img){
            var a1,a2,a3,a4,ch,cc;
            ch = [];
            if(img.isDrawable){
                var w = img.w;
                var h = img.h;
                var data = img.ctx.getImageData(0,0,w,h);
                var d = data.data;
                var x,y;
                var ww = w*4;
                var ww4 = ww+4;
                for(y = 0; y < h; y+=2){
                    for(x = 0; x < w; x+=2){
                        var id = y*ww+x*4;
                        var id1 = Math.floor(y/2)*ww+Math.floor(x/2)*4;
                        a1 = d[id+3];
                        a2 = d[id+7];
                        a3 = d[id+ww+3];
                        a4 = d[id+ww4+3];
                        if(a1 > 0 && a2 > 0 && a3 > 0 && a4 > 0){
                            d[id1] = Math.sqrt((d[id]*d[id]+d[id+4]*d[id+4]+d[id+ww]*d[id+ww]+d[id+ww4]*d[id+ww4])/4);
                            id += 1;
                            id1 += 1;
                            d[id1] = Math.sqrt((d[id]*d[id]+d[id+4]*d[id+4]+d[id+ww]*d[id+ww]+d[id+ww4]*d[id+ww4])/4);
                            id += 1;
                            id1 += 1;
                            d[id1] = Math.sqrt((d[id]*d[id]+d[id+4]*d[id+4]+d[id+ww]*d[id+ww]+d[id+ww4]*d[id+ww4])/4);
                            id += 1;
                            id1 += 1;
                            d[id1] = Math.sqrt((a1*a1+a2*a2+a3*a3+a4*a4)/4);
                        }else
                        if(a1 + a2 + a3 + a4 === 0){
                            d[id1++] = 0;
                            d[id1++] = 0;
                            d[id1++] = 0;
                            d[id1] = 0;
                        }else{
                            cc = 0;
                            ch[0] = ch[1] = ch[2] = 0;
                            if(a1 > 0){
                                ch[0] += d[id]   * d[id];
                                ch[1] += d[id + 1] * d[id + 1];
                                ch[2] += d[id + 2] * d[id + 2];
                                cc++;
                            }
                            if(a2 > 0){
                                ch[0] += d[id + 4] * d[id + 4];
                                ch[1] += d[id + 5] * d[id + 5];
                                ch[2] += d[id + 6] * d[id + 6];
                                cc++
                            }
                            if(a3 > 0){
                                ch[0] += d[id + ww    ] * d[id + ww];
                                ch[1] += d[id + ww + 1] * d[id + ww + 1];
                                ch[2] += d[id + ww + 2] * d[id + ww + 2];
                                cc++
                            }
                            if(a4 > 0){
                                ch[0] += d[id + ww + 4] * d[id + ww + 4];
                                ch[1] += d[id + ww + 5] * d[id + ww + 5];
                                ch[2] += d[id + ww + 6] * d[id + ww + 6];
                                cc++;
                            }
                            d[id1++] = Math.sqrt(ch[0]/cc);
                            d[id1++] = Math.sqrt(ch[1]/cc);
                            d[id1++] = Math.sqrt(ch[2]/cc);
                            d[id1] = Math.sqrt((a1*a1+a2*a2+a3*a3+a4*a4)/4);
                        }                    
                            
                    }
                }
                w = w / 2 | 0;
                h = h / 2 | 0;
                img.desc.mirror.width = w ;
                img.desc.mirror.height = h;
                img.w = img.width = w;
                img.h = img.height = h;
                img.ctx.putImageData(data,0,0);
                img.desc.mirror.ctx.drawImage(img,0,0);

                img.desc.dirty = true;
                img.lastAction = "High quality halved"; 
                img.desc.clippedTop = 0;
                img.desc.clippedLeft = 0;
                img.restore();
                


            }    
        },        
        pad(img,amount){
            if(img.isDrawable){
                amount |= 0;
                if(amount === 0){ return }
                var w = img.w;
                var h = img.h;
                const m = img.desc.mirror;
                m.width = w + amount * 2;
                m.height = h + amount * 2;
                m.ctx.drawImage(img,amount,amount);
                img.w = img.width = w + amount * 2;
                img.h = img.height = h + amount * 2;
                img.desc.dirty = true;
                img.lastAction = "Padded";  
                img.desc.clippedTop = -amount;
                img.desc.clippedLeft = -amount;
                img.restore();
                return true;
            }
        },
        autoClip(img){
            if(img.isDrawable){
                var w = img.w;
                var h = img.h;
                var data = img.ctx.getImageData(0,0,w,h);
                var d = data.data;
                var x,y;
                var ww = w*4;
                var ww4 = ww+4;
                var left = w
                var right = 0;
                var top;
                var bottom;
                for(y = 0; y < h; y+=1){
                    for(x = 0; x < w; x+=1){
                        var ind = y*ww+x*4;
                        var p = d[ind]+d[ind+1]+d[ind+2]+d[ind+3];
                        if(p > 0){
                            if (top === undefined) { top = y }
                            bottom = y;
                            if (x < left) { left = x }
                            if (x > right) { right = x }
                        }
                    }
                }
                right += 1;
                bottom += 1;
                w = Math.floor(right-left);
                h = Math.floor(bottom-top);
                if(w <= 0){
                    log.warn("Can not size image to 0px by 0px");
                    return;
                }
                img.desc.mirror.width = w;
                img.desc.mirror.height = h;
                img.desc.mirror.ctx.drawImage(img,left,top,w,h,0,0,w,h);
                img.w = img.width = w;
                img.h = img.height = h;
                img.desc.dirty = true;
                img.lastAction = "Auto clipped testtest steststakjskjhdkja ajhadkjhakjhdfas sdkjhdskjhsdkjadf";                
                img.desc.clippedTop = top;
                img.desc.clippedLeft = left;
                img.restore();
                return true;
            }
            return false;
        },
        fillTransparentWithColor(img, color){
            if(img.isDrawable){
                img.ctx.fillStyle = color;
                img.ctx.setTransform(1,0,0,1,0,0);
                img.ctx.globalCompositeOperation = "destination-over";
                img.ctx.fillRect(0,0,img.w, img.h);
                img.ctx.globalCompositeOperation = "source-over";
                img.processed = true;
                img.lastAction = "Filled transparent";
                
                img.update();
                return true;
            }
        },
        fillForegroundWithColor(img, color){
            if(img.isDrawable){
                img.ctx.fillStyle = color;
                img.ctx.setTransform(1,0,0,1,0,0);
                img.ctx.globalCompositeOperation = "source-atop";
                img.ctx.fillRect(0,0,img.w, img.h);
                img.ctx.globalCompositeOperation = "source-over";
                img.processed = true;
                img.lastAction = "Filled transparent";
                
                img.update();
                return true;
            }
        },
        fillWithColor(img, color){
            if(img.isDrawable){
                img.ctx.setTransform(1,0,0,1,0,0);
                img.ctx.fillStyle = color;
                img.ctx.fillRect(0,0,img.w, img.h);
                img.processed = true;
                img.lastAction = "Filled with color";

                img.update();
                return true;
            }
        },
        floodFill(img,x,y,tolerance,diagonal,alias,color){
            if(img.isDrawable){
                copyToWorking(img);
                ctx.floodFill(x,y,tolerance,diagonal,alias,{color,comp : img.ctx.globalCompositeOperation, alpha : img.ctx.globalAlpha});
                getCopyOfWorking(img);    
                img.processed = true;
                img.lastAction = "Flood fill";
                
                img.update();
                return true;                    
            }
        },
        floodFillOutline(img,x,y,tolerance,diagonal,edge,color){
            if(img.isDrawable){
                copyToWorking(img);
                ctx.edgeFill(x,y,tolerance,diagonal,edge,{color,comp : img.ctx.globalCompositeOperation, alpha : img.ctx.globalAlpha});
                getCopyOfWorking(img);    
                img.processed = true;
                img.lastAction = "Flood fill outline";
                img.update();
                return true;                    
            }
        },
        pixelFunctions : {
            none : null,
            invertRGB(pin,pout){
                pout[0] = 255-pin[0];
                pout[1] = 255-pin[1];
                pout[2] = 255-pin[2];
                return pout;
            },
            invertA(pin,pout){
                pout[3] = 255-pin[3];
                return pout;
            },            
            alphaDown(pin,pout){
                  pout[3] = ((pin[3] / 255) ** 2) * 255;
                  return pout;
            },
            alphaUp(pin,pout){
                  pout[3] = ((pin[3] / 255) ** 0.5) * 255;
                  return pout;
            },
            minRGB(pin,pout){
                pout[2] = pout[1] = pout[0] = Math.min(pin[0],pin[1],pin[2]);
            },
            maxRGB(pin,pout){
                pout[2] = pout[1] = pout[0] = Math.max(pin[0],pin[1],pin[2]);
            },
            meanLogRGB(pin,pout){
                pout[2] = pout[1] = pout[0] = Math.sqrt((pin[0] * pin[0] + pin[1] * pin[1] + pin[2] * pin[2]) / 3);
                return pout;
            },
            RGBRotate(pin,pout){
                const r = pin[0];
                pout[0] = pin[2];
                pout[2] = pin[1];
                pout[1] = r;
                return pout;
            },
            redToGreenBlue(pin,pout){
                pout[2] = pout[1] = pin[0];
                return pout;
            },
            greenToRedBlue(pin,pout){
                pout[2] = pout[0] = pin[1];
                return pout;
            },
            blueToRedGreen(pin,pout){
                pout[0] = pout[1] = pin[2];
                return pout;
            },
            preceptualMeanRGB(pin,pout){
                pout[2] = pout[1] = pout[0] = Math.sqrt(pin[0] * pin[0] * 0.2 + pin[1] * pin[1] * 0.7 + pin[2] * pin[2] * 0.1);
            },
            meanRGB(pin,pout) {
                pout[2] = pout[1] = pout[0] = (pin[0] + pin[1] + pin[2]) / 3;
                return pout;
            },
            invMeanRGB(pin,pout) {
                pout[2] = pout[1] = pout[0] = 255 - (pin[0] + pin[1] + pin[2]) / 3;
                return pout;
            },
            moveR2A(pin,pout){
                pout[3] = pin[0];
                return pout;
            },
            moveR2RGB(pin,pout){
                pout[0] = pin[0];
                pout[1] = pin[0];
                pout[2] = pin[0];
                return pout;
            },            
        },
        invertRGB(img){ API.channelCopy(img,API.pixelFunctions.none,API.pixelFunctions.invertRGB) },
        invertAlpha(img){ API.channelCopy(img,API.pixelFunctions.none,API.pixelFunctions.invertA) },
        channelCopy(img,getFunc,setFunc){
            if(img.isDrawable){
                const data = getPixelData8Bit(img);
                const dat = data.data;
                const pixelIn = new Uint8ClampedArray(4);
                const pixelOut = new Uint8ClampedArray(4);
                var i = 0;
                if(getFunc === null){
                    while(i < dat.length){
                        pixelIn[0] = dat[i];
                        pixelIn[1] = dat[i+1];
                        pixelIn[2] = dat[i+2];
                        pixelIn[3] = dat[i+3];
                        setFunc(pixelIn,pixelIn);
                        dat[i++] = pixelIn[0];
                        dat[i++] = pixelIn[1];
                        dat[i++] = pixelIn[2];
                        dat[i++] = pixelIn[3];
                    }
                } else {
                    while(i < dat.length){
                        pixelIn[0] = dat[i];
                        pixelIn[1] = dat[i+1];
                        pixelIn[2] = dat[i+2];
                        pixelIn[3] = dat[i+3];
                        setFunc(getFunc(pixelIn,pixelOut), pixelIn);
                        dat[i++] = pixelIn[0];
                        dat[i++] = pixelIn[1];
                        dat[i++] = pixelIn[2];
                        dat[i++] = pixelIn[3];
                    }
                }
                setPixelData(img,data);
                img.processed = true;
                img.lastAction = "Channel copy";
                img.update();
                return true;      
            }
        },
        
            
        
        
        get extras() {
            return {
                repeatLast : {
                    help : "Repeats the last processing job",
                    call() { utils.repeatProcessSelectedImages() }
                    
                },
                render : {
                    fillTransparent : {
                        help : "Fills all transparent pixels with current main color for selected drawable images.",
                        call(){  utils.processSelectedImages(API.fillTransparentWithColor, colours.current)   },
                    },
                    fillWithColor : {
                        help : "Fills all pixels with current main color for selected drawable images.",
                        call(){  utils.processSelectedImages(API.fillWithColor, colours.current)   },
                    },
                    rgbToAlpha : {
                        help : "Sets alpha to mean of RGB channel for selected drawable images",
                        call(){  utils.processSelectedImages(API.channelCopy, API.pixelFunctions.meanRGB, API.pixelFunctions.moveR2A )   },
                    },
                    invert_RGB : { 
                        help : "Inverts RGB channels for selected drawable images",
                        call(){  utils.processSelectedImages(API.invertRGB )   },
                    },                    
                    invertAlpha : { 
                        help : "Inverts Alpha channel for selected drawable images",
                        call(){  utils.processSelectedImages(API.invertAlpha )   },
                    },
                    channels : {
                        help : "Runs a batch that lets up modify channels of selected images",
                        call(){ setTimeout(()=>commandLine("run imageProcessing",true),0) }

                    },
                },                
                resize : {
                    clipTransparent : {
                        help : "Resizes image removing transparent edges to selected drawable images",
                        call(){ issuseCommand(commands.edSprClip) },
                    },
                    padTransparent : {
                        help : "Adds 25% to height and width as transparent pixels to selected drawable images",
                        call(){ issuseCommand(commands.edSprPad)  },
                    },
                    padPixelTransparent : {
                        help : "Adds 1 transparent pixel to each side of selected drawable images",
                        call(){ simulateCommand(commands.edSprPad, {oldButton : 4}) },
                    },
                    highQualityReduce : {
                        help : "Halves the image size using high quality algorthm of selected drawable images",
                        call(){ utils.processSelectedImages(API.halfSizeBitmap) }
                    },
                },      
            };           
        },
    }
    return API;
})();
const media = (()=>{
    const directories = [
        "http://localhost/MarksHome/GameEngine/Jan2018/",
        "http://localhost/MarksHome/GameEngine/July2015/",
        "http://localhost/MarksHome/GameEngine/june2013/",
    ];
    const items = [];
    function createImageMirror(can){
        const mirror = document.createElement("canvas");
        mirror.width = can.width;
        mirror.height = can.height;
        can.desc.mirror = mirror;
        mirror.ctx = mirror.getContext("2d");
        can.update = function(flagsOnly){
            if(!flagsOnly){
                mirror.ctx.clearRect(0,0,can.w,can.h);
                mirror.ctx.drawImage(can,0,0);
            }
            can.restored = false;
            can.desc.dirty = can.processed ? true : can.desc.dirty;
            can.processed = false;
            can.saved = !can.desc.dirty ? can.saved === true : false;
        }
        can.restore = function(){
            can.ctx.setTransform(1,0,0,1,0,0);
            can.ctx.globalAlpha = 1;
            can.ctx.filter = "none";
            can.ctx.shadowColor ="rgba(0,0,0,0)";
            can.ctx.globalCompositeOperation = "source-over";
            can.ctx.clearRect(0,0,can.w,can.h);
            can.ctx.drawImage(mirror,0,0);
            can.restored = true;
        }
        can.processed = true;
        can.restored = false;
        can.update();
    }
    function createDrawableExtras(can){

        const undoCan = document.createElement("canvas");
        undoCan.width = can.width;
        undoCan.height = can.height;
        can.desc.undoCan = undoCan;
        undoCan.ctx = undoCan.getContext("2d");     
    }        
    
    function createImageUtils(can){
        can.save = function(name = can.desc.name, type = "png", quality = 1){
            saveImage(can,name,type,quality);
            can.desc.dirty = false;
        }
        can.clear = function(andMirror = true){
            can.ctx.setTransform(1,0,0,1,0,0);
            can.ctx.globalAlpha = 1;
            can.ctx.globalCompositeOperation = "source-over";
            can.ctx.clearRect(0,0,can.w,can.h);
            can.processed = true;
            if (andMirror) { can.update() }
        }
        can.desc.toString = function(){
            return this.name + " " + textIcons.drawable + " " + 
                can.w + " * "  + can.h + "px " + 
                (can.desc.dirty ? "Dirty " : (can.saved ? "Saved" : "")) + 
                (can.lastAction ? " " + can.lastAction : "");
        }
        can.isDrawable = true;
    }
    const API = {
        each(cb) {
            for(const media of items) { cb(media) };
        },
        updateLists(){
            for(const item of items){
                mediaList.add(img);
            }
        },
        byName(name){
            for(const media of items){
                if(media.desc.name === name) { return media }
            }
        },
        remove(media){
            for(var i = 0; i < items.length; i ++){
                if(items[i] === media){
                    items.splice(i,1);
                    return;
                }
            }
        },
        replace(media,newMedia){
            for(var i = 0; i < items.length; i ++){
                if(items[i] === media){
                    items[i] = newMedia
                    return;
                }
            }
        },
        toDrawable(media){
            const can = document.createElement("canvas");
            can.desc = media.desc;
            can.w = can.width = media.w
            can.h = can.height = media.h;
            can.desc.status = "OK";
            can.desc.dirty = true;
            can.ctx = can.getContext("2d");
            can.ctx.drawImage(media,0,0);
            createImageUtils(can);
            createImageMirror(can);
            createDrawableExtras(can);
            API.replace(media,can);
            return can;
        },
        create(desc,callback){
            if(typeof desc === "string"){
                var busyId = busy("loading");
                var img;
                var isGif = false;
                if(desc.toLowerCase().indexOf(".gif") > 0){
                    img = GIFGroover();
                    isGif = true;
                    img.onprogress = (event) => {
                        busy.text = ((event.progress) | 0) + "%";
                    }
                }else{
                    img = new Image();
                }
                img.guid = getGUID();
                
                img.src = desc;
                desc = img.desc = {
                    name : img.src.split("/").pop(),
                    dir : 0,
                    status : "loading",
                    toString(){
                        return this.name + " IMG " + img.w + "by"  + img.h;
                    },
                }
                var prog = log.sys("Loading image '" + img.src + "' as " + desc.name);
                img.onload = ()=>{
                    if(isGif){
                        img.isGif = true;
                        img.onerror = img.onload = undefined;
                        img.w = img.width;
                        img.h = img.height;
                        log.sys("Loaded " + desc.name + " " + img.w + " by " + img.h);
                        prog = undefined;
                        items.push(img);
                        desc.status = "OK";
                        if(callback) { callback(img) }
                        mediaList.add(img);
                        
                        
                    }else{
                        img.w = img.naturalWidth;
                        img.h = img.naturalHeight;
                        log.sys("Loaded " + desc.name + " " + img.w + " by " + img.h);
                        img.onerror = img.onload = undefined;
                        prog = undefined;
                        items.push(img);
                        desc.status = "OK";
                        if(callback) { callback(img) }
                        mediaList.add(img);
                    }
                    addLoadedMedia(img.src);
                    if(/zoomRip/i.test(img.src)){
                        const time = new Date(Number(img.src.split(/zoomRip_/i)[1].split(".")[0]) * 1000);
                        log.sys("Ripped image date " + time.toLocaleString());
                        
                    }

                    busy.end(busyId);
                }
                img.onerror = ()=>{
                    if(desc.dir < directories.length){
                        img.src = directories[desc.dir++] + img.desc.name;
                        prog.textContent += "+";
                        busy.text = "Searching";

                    }else{
                        log.error("Could not load " + desc.name);
                        img.onerror = img.onload = undefined;
                        prog = undefined;
                        desc.status = "failed";
                        if(callback) { callback() }
                        appBusyText = "";
                        busy.end(busyId);
                    }
                }
            }else if(desc.type === "canvas"){
                const can = document.createElement("canvas");
                can.guid = getGUID();
                can.desc = desc;
                can.w = can.width = desc.width !== undefined ? desc.width | 0 : 256;
                can.h = can.height = desc.height !== undefined ? desc.height | 0 : 256;
                desc.name =  desc.name !== undefined ? desc.name : "canvas#" + getGUID();
                desc.status = "OK";
                desc.dirty = true;
                can.ctx = can.getContext("2d");
                createImageUtils(can);
                createImageMirror(can);
                createDrawableExtras(can);
                items.push(can);
                if (callback) { callback(can) }
                mediaList.add(can);
            }else if(desc.type === "copy"){
                const can = document.createElement("canvas");
                const copyOf = desc.of;
                desc.of = undefined;
                can.guid = getGUID();
                can.desc = desc;
                can.w = can.width = copyOf.w;
                can.h = can.height = copyOf.h;
                desc.name =  desc.name !== undefined ? desc.name : "copy#"+getGUID()+"Of" + copyOf.desc.name.replace(/copyOf/gi,"");
                desc.status = "OK";
                desc.dirty = true;
                can.ctx = can.getContext("2d");
                createImageUtils(can);
                can.clear(false); // Not needed but trying to fix slow renders for canvas that has not been touched by render
                can.ctx.drawImage(copyOf,0,0);
                createImageMirror(can);
                createDrawableExtras(can);
                items.push(can);
                if (callback) { callback(can) }
                mediaList.add(can);
            }
        }
    };
    return API;
})();